INSERT INTO Illness (Name,Severity) VALUES ('I1','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I2','High');

INSERT INTO Illness (Name,Severity) VALUES ('I3','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I4','High');

INSERT INTO Illness (Name,Severity) VALUES ('I5','High');

INSERT INTO Illness (Name,Severity) VALUES ('I6','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I7','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I8','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I9','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I10','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I11','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I12','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I13','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I14','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I15','High');

INSERT INTO Illness (Name,Severity) VALUES ('I16','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I17','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I18','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I19','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I20','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I21','High');

INSERT INTO Illness (Name,Severity) VALUES ('I22','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I23','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I24','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I25','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I26','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I27','High');

INSERT INTO Illness (Name,Severity) VALUES ('I28','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I29','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I30','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I31','High');

INSERT INTO Illness (Name,Severity) VALUES ('I32','High');

INSERT INTO Illness (Name,Severity) VALUES ('I33','High');

INSERT INTO Illness (Name,Severity) VALUES ('I34','High');

INSERT INTO Illness (Name,Severity) VALUES ('I35','High');

INSERT INTO Illness (Name,Severity) VALUES ('I36','High');

INSERT INTO Illness (Name,Severity) VALUES ('I37','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I38','High');

INSERT INTO Illness (Name,Severity) VALUES ('I39','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I40','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I41','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I42','High');

INSERT INTO Illness (Name,Severity) VALUES ('I43','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I44','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I45','High');

INSERT INTO Illness (Name,Severity) VALUES ('I46','High');

INSERT INTO Illness (Name,Severity) VALUES ('I47','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I48','High');

INSERT INTO Illness (Name,Severity) VALUES ('I49','High');

INSERT INTO Illness (Name,Severity) VALUES ('I50','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I51','High');

INSERT INTO Illness (Name,Severity) VALUES ('I52','High');

INSERT INTO Illness (Name,Severity) VALUES ('I53','High');

INSERT INTO Illness (Name,Severity) VALUES ('I54','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I55','High');

INSERT INTO Illness (Name,Severity) VALUES ('I56','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I57','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I58','High');

INSERT INTO Illness (Name,Severity) VALUES ('I59','High');

INSERT INTO Illness (Name,Severity) VALUES ('I60','High');

INSERT INTO Illness (Name,Severity) VALUES ('I61','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I62','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I63','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I64','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I65','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I66','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I67','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I68','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I69','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I70','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I71','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I72','High');

INSERT INTO Illness (Name,Severity) VALUES ('I73','High');

INSERT INTO Illness (Name,Severity) VALUES ('I74','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I75','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I76','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I77','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I78','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I79','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I80','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I81','High');

INSERT INTO Illness (Name,Severity) VALUES ('I82','High');

INSERT INTO Illness (Name,Severity) VALUES ('I83','High');

INSERT INTO Illness (Name,Severity) VALUES ('I84','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I85','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I86','High');

INSERT INTO Illness (Name,Severity) VALUES ('I87','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I88','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I89','High');

INSERT INTO Illness (Name,Severity) VALUES ('I90','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I91','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I92','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I93','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I94','High');

INSERT INTO Illness (Name,Severity) VALUES ('I95','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I96','High');

INSERT INTO Illness (Name,Severity) VALUES ('I97','High');

INSERT INTO Illness (Name,Severity) VALUES ('I98','High');

INSERT INTO Illness (Name,Severity) VALUES ('I99','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I100','High');

INSERT INTO Illness (Name,Severity) VALUES ('I101','High');

INSERT INTO Illness (Name,Severity) VALUES ('I102','High');

INSERT INTO Illness (Name,Severity) VALUES ('I103','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I104','High');

INSERT INTO Illness (Name,Severity) VALUES ('I105','High');

INSERT INTO Illness (Name,Severity) VALUES ('I106','High');

INSERT INTO Illness (Name,Severity) VALUES ('I107','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I108','High');

INSERT INTO Illness (Name,Severity) VALUES ('I109','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I110','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I111','High');

INSERT INTO Illness (Name,Severity) VALUES ('I112','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I113','High');

INSERT INTO Illness (Name,Severity) VALUES ('I114','High');

INSERT INTO Illness (Name,Severity) VALUES ('I115','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I116','High');

INSERT INTO Illness (Name,Severity) VALUES ('I117','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I118','High');

INSERT INTO Illness (Name,Severity) VALUES ('I119','High');

INSERT INTO Illness (Name,Severity) VALUES ('I120','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I121','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I122','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I123','High');

INSERT INTO Illness (Name,Severity) VALUES ('I124','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I125','High');

INSERT INTO Illness (Name,Severity) VALUES ('I126','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I127','High');

INSERT INTO Illness (Name,Severity) VALUES ('I128','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I129','High');

INSERT INTO Illness (Name,Severity) VALUES ('I130','High');

INSERT INTO Illness (Name,Severity) VALUES ('I131','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I132','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I133','High');

INSERT INTO Illness (Name,Severity) VALUES ('I134','High');

INSERT INTO Illness (Name,Severity) VALUES ('I135','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I136','High');

INSERT INTO Illness (Name,Severity) VALUES ('I137','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I138','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I139','High');

INSERT INTO Illness (Name,Severity) VALUES ('I140','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I141','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I142','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I143','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I144','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I145','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I146','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I147','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I148','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I149','High');

INSERT INTO Illness (Name,Severity) VALUES ('I150','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I151','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I152','High');

INSERT INTO Illness (Name,Severity) VALUES ('I153','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I154','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I155','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I156','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I157','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I158','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I159','High');

INSERT INTO Illness (Name,Severity) VALUES ('I160','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I161','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I162','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I163','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I164','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I165','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I166','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I167','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I168','High');

INSERT INTO Illness (Name,Severity) VALUES ('I169','High');

INSERT INTO Illness (Name,Severity) VALUES ('I170','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I171','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I172','High');

INSERT INTO Illness (Name,Severity) VALUES ('I173','High');

INSERT INTO Illness (Name,Severity) VALUES ('I174','High');

INSERT INTO Illness (Name,Severity) VALUES ('I175','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I176','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I177','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I178','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I179','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I180','High');

INSERT INTO Illness (Name,Severity) VALUES ('I181','High');

INSERT INTO Illness (Name,Severity) VALUES ('I182','High');

INSERT INTO Illness (Name,Severity) VALUES ('I183','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I184','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I185','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I186','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I187','High');

INSERT INTO Illness (Name,Severity) VALUES ('I188','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I189','High');

INSERT INTO Illness (Name,Severity) VALUES ('I190','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I191','High');

INSERT INTO Illness (Name,Severity) VALUES ('I192','High');

INSERT INTO Illness (Name,Severity) VALUES ('I193','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I194','High');

INSERT INTO Illness (Name,Severity) VALUES ('I195','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I196','High');

INSERT INTO Illness (Name,Severity) VALUES ('I197','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I198','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I199','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I200','High');

INSERT INTO Illness (Name,Severity) VALUES ('I201','High');

INSERT INTO Illness (Name,Severity) VALUES ('I202','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I203','High');

INSERT INTO Illness (Name,Severity) VALUES ('I204','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I205','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I206','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I207','High');

INSERT INTO Illness (Name,Severity) VALUES ('I208','High');

INSERT INTO Illness (Name,Severity) VALUES ('I209','High');

INSERT INTO Illness (Name,Severity) VALUES ('I210','High');

INSERT INTO Illness (Name,Severity) VALUES ('I211','High');

INSERT INTO Illness (Name,Severity) VALUES ('I212','High');

INSERT INTO Illness (Name,Severity) VALUES ('I213','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I214','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I215','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I216','High');

INSERT INTO Illness (Name,Severity) VALUES ('I217','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I218','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I219','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I220','High');

INSERT INTO Illness (Name,Severity) VALUES ('I221','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I222','High');

INSERT INTO Illness (Name,Severity) VALUES ('I223','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I224','High');

INSERT INTO Illness (Name,Severity) VALUES ('I225','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I226','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I227','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I228','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I229','High');

INSERT INTO Illness (Name,Severity) VALUES ('I230','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I231','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I232','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I233','High');

INSERT INTO Illness (Name,Severity) VALUES ('I234','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I235','High');

INSERT INTO Illness (Name,Severity) VALUES ('I236','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I237','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I238','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I239','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I240','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I241','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I242','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I243','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I244','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I245','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I246','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I247','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I248','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I249','High');

INSERT INTO Illness (Name,Severity) VALUES ('I250','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I251','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I252','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I253','High');

INSERT INTO Illness (Name,Severity) VALUES ('I254','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I255','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I256','High');

INSERT INTO Illness (Name,Severity) VALUES ('I257','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I258','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I259','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I260','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I261','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I262','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I263','High');

INSERT INTO Illness (Name,Severity) VALUES ('I264','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I265','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I266','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I267','High');

INSERT INTO Illness (Name,Severity) VALUES ('I268','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I269','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I270','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I271','High');

INSERT INTO Illness (Name,Severity) VALUES ('I272','High');

INSERT INTO Illness (Name,Severity) VALUES ('I273','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I274','High');

INSERT INTO Illness (Name,Severity) VALUES ('I275','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I276','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I277','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I278','High');

INSERT INTO Illness (Name,Severity) VALUES ('I279','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I280','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I281','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I282','High');

INSERT INTO Illness (Name,Severity) VALUES ('I283','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I284','High');

INSERT INTO Illness (Name,Severity) VALUES ('I285','High');

INSERT INTO Illness (Name,Severity) VALUES ('I286','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I287','High');

INSERT INTO Illness (Name,Severity) VALUES ('I288','High');

INSERT INTO Illness (Name,Severity) VALUES ('I289','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I290','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I291','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I292','High');

INSERT INTO Illness (Name,Severity) VALUES ('I293','High');

INSERT INTO Illness (Name,Severity) VALUES ('I294','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I295','High');

INSERT INTO Illness (Name,Severity) VALUES ('I296','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I297','High');

INSERT INTO Illness (Name,Severity) VALUES ('I298','High');

INSERT INTO Illness (Name,Severity) VALUES ('I299','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I300','High');

INSERT INTO Illness (Name,Severity) VALUES ('I301','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I302','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I303','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I304','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I305','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I306','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I307','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I308','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I309','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I310','High');

INSERT INTO Illness (Name,Severity) VALUES ('I311','High');

INSERT INTO Illness (Name,Severity) VALUES ('I312','High');

INSERT INTO Illness (Name,Severity) VALUES ('I313','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I314','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I315','High');

INSERT INTO Illness (Name,Severity) VALUES ('I316','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I317','High');

INSERT INTO Illness (Name,Severity) VALUES ('I318','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I319','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I320','High');

INSERT INTO Illness (Name,Severity) VALUES ('I321','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I322','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I323','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I324','High');

INSERT INTO Illness (Name,Severity) VALUES ('I325','High');

INSERT INTO Illness (Name,Severity) VALUES ('I326','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I327','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I328','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I329','High');

INSERT INTO Illness (Name,Severity) VALUES ('I330','High');

INSERT INTO Illness (Name,Severity) VALUES ('I331','High');

INSERT INTO Illness (Name,Severity) VALUES ('I332','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I333','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I334','High');

INSERT INTO Illness (Name,Severity) VALUES ('I335','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I336','High');

INSERT INTO Illness (Name,Severity) VALUES ('I337','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I338','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I339','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I340','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I341','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I342','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I343','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I344','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I345','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I346','High');

INSERT INTO Illness (Name,Severity) VALUES ('I347','High');

INSERT INTO Illness (Name,Severity) VALUES ('I348','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I349','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I350','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I351','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I352','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I353','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I354','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I355','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I356','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I357','High');

INSERT INTO Illness (Name,Severity) VALUES ('I358','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I359','High');

INSERT INTO Illness (Name,Severity) VALUES ('I360','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I361','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I362','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I363','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I364','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I365','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I366','High');

INSERT INTO Illness (Name,Severity) VALUES ('I367','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I368','High');

INSERT INTO Illness (Name,Severity) VALUES ('I369','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I370','High');

INSERT INTO Illness (Name,Severity) VALUES ('I371','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I372','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I373','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I374','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I375','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I376','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I377','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I378','High');

INSERT INTO Illness (Name,Severity) VALUES ('I379','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I380','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I381','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I382','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I383','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I384','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I385','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I386','High');

INSERT INTO Illness (Name,Severity) VALUES ('I387','High');

INSERT INTO Illness (Name,Severity) VALUES ('I388','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I389','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I390','High');

INSERT INTO Illness (Name,Severity) VALUES ('I391','High');

INSERT INTO Illness (Name,Severity) VALUES ('I392','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I393','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I394','High');

INSERT INTO Illness (Name,Severity) VALUES ('I395','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I396','High');

INSERT INTO Illness (Name,Severity) VALUES ('I397','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I398','High');

INSERT INTO Illness (Name,Severity) VALUES ('I399','High');

INSERT INTO Illness (Name,Severity) VALUES ('I400','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I401','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I402','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I403','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I404','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I405','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I406','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I407','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I408','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I409','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I410','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I411','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I412','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I413','High');

INSERT INTO Illness (Name,Severity) VALUES ('I414','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I415','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I416','High');

INSERT INTO Illness (Name,Severity) VALUES ('I417','High');

INSERT INTO Illness (Name,Severity) VALUES ('I418','High');

INSERT INTO Illness (Name,Severity) VALUES ('I419','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I420','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I421','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I422','High');

INSERT INTO Illness (Name,Severity) VALUES ('I423','High');

INSERT INTO Illness (Name,Severity) VALUES ('I424','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I425','High');

INSERT INTO Illness (Name,Severity) VALUES ('I426','High');

INSERT INTO Illness (Name,Severity) VALUES ('I427','High');

INSERT INTO Illness (Name,Severity) VALUES ('I428','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I429','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I430','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I431','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I432','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I433','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I434','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I435','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I436','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I437','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I438','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I439','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I440','High');

INSERT INTO Illness (Name,Severity) VALUES ('I441','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I442','High');

INSERT INTO Illness (Name,Severity) VALUES ('I443','High');

INSERT INTO Illness (Name,Severity) VALUES ('I444','High');

INSERT INTO Illness (Name,Severity) VALUES ('I445','High');

INSERT INTO Illness (Name,Severity) VALUES ('I446','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I447','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I448','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I449','High');

INSERT INTO Illness (Name,Severity) VALUES ('I450','High');

INSERT INTO Illness (Name,Severity) VALUES ('I451','High');

INSERT INTO Illness (Name,Severity) VALUES ('I452','High');

INSERT INTO Illness (Name,Severity) VALUES ('I453','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I454','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I455','High');

INSERT INTO Illness (Name,Severity) VALUES ('I456','High');

INSERT INTO Illness (Name,Severity) VALUES ('I457','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I458','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I459','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I460','High');

INSERT INTO Illness (Name,Severity) VALUES ('I461','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I462','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I463','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I464','High');

INSERT INTO Illness (Name,Severity) VALUES ('I465','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I466','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I467','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I468','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I469','High');

INSERT INTO Illness (Name,Severity) VALUES ('I470','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I471','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I472','High');

INSERT INTO Illness (Name,Severity) VALUES ('I473','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I474','High');

INSERT INTO Illness (Name,Severity) VALUES ('I475','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I476','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I477','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I478','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I479','High');

INSERT INTO Illness (Name,Severity) VALUES ('I480','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I481','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I482','High');

INSERT INTO Illness (Name,Severity) VALUES ('I483','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I484','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I485','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I486','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I487','High');

INSERT INTO Illness (Name,Severity) VALUES ('I488','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I489','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I490','High');

INSERT INTO Illness (Name,Severity) VALUES ('I491','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I492','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I493','High');

INSERT INTO Illness (Name,Severity) VALUES ('I494','High');

INSERT INTO Illness (Name,Severity) VALUES ('I495','High');

INSERT INTO Illness (Name,Severity) VALUES ('I496','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I497','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I498','High');

INSERT INTO Illness (Name,Severity) VALUES ('I499','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I500','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I501','High');

INSERT INTO Illness (Name,Severity) VALUES ('I502','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I503','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I504','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I505','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I506','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I507','High');

INSERT INTO Illness (Name,Severity) VALUES ('I508','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I509','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I510','High');

INSERT INTO Illness (Name,Severity) VALUES ('I511','High');

INSERT INTO Illness (Name,Severity) VALUES ('I512','High');

INSERT INTO Illness (Name,Severity) VALUES ('I513','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I514','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I515','High');

INSERT INTO Illness (Name,Severity) VALUES ('I516','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I517','High');

INSERT INTO Illness (Name,Severity) VALUES ('I518','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I519','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I520','High');

INSERT INTO Illness (Name,Severity) VALUES ('I521','High');

INSERT INTO Illness (Name,Severity) VALUES ('I522','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I523','High');

INSERT INTO Illness (Name,Severity) VALUES ('I524','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I525','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I526','High');

INSERT INTO Illness (Name,Severity) VALUES ('I527','High');

INSERT INTO Illness (Name,Severity) VALUES ('I528','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I529','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I530','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I531','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I532','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I533','High');

INSERT INTO Illness (Name,Severity) VALUES ('I534','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I535','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I536','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I537','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I538','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I539','High');

INSERT INTO Illness (Name,Severity) VALUES ('I540','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I541','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I542','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I543','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I544','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I545','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I546','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I547','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I548','High');

INSERT INTO Illness (Name,Severity) VALUES ('I549','High');

INSERT INTO Illness (Name,Severity) VALUES ('I550','High');

INSERT INTO Illness (Name,Severity) VALUES ('I551','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I552','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I553','High');

INSERT INTO Illness (Name,Severity) VALUES ('I554','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I555','High');

INSERT INTO Illness (Name,Severity) VALUES ('I556','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I557','High');

INSERT INTO Illness (Name,Severity) VALUES ('I558','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I559','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I560','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I561','High');

INSERT INTO Illness (Name,Severity) VALUES ('I562','High');

INSERT INTO Illness (Name,Severity) VALUES ('I563','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I564','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I565','High');

INSERT INTO Illness (Name,Severity) VALUES ('I566','High');

INSERT INTO Illness (Name,Severity) VALUES ('I567','High');

INSERT INTO Illness (Name,Severity) VALUES ('I568','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I569','High');

INSERT INTO Illness (Name,Severity) VALUES ('I570','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I571','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I572','High');

INSERT INTO Illness (Name,Severity) VALUES ('I573','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I574','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I575','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I576','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I577','High');

INSERT INTO Illness (Name,Severity) VALUES ('I578','High');

INSERT INTO Illness (Name,Severity) VALUES ('I579','High');

INSERT INTO Illness (Name,Severity) VALUES ('I580','High');

INSERT INTO Illness (Name,Severity) VALUES ('I581','High');

INSERT INTO Illness (Name,Severity) VALUES ('I582','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I583','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I584','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I585','High');

INSERT INTO Illness (Name,Severity) VALUES ('I586','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I587','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I588','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I589','High');

INSERT INTO Illness (Name,Severity) VALUES ('I590','High');

INSERT INTO Illness (Name,Severity) VALUES ('I591','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I592','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I593','High');

INSERT INTO Illness (Name,Severity) VALUES ('I594','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I595','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I596','High');

INSERT INTO Illness (Name,Severity) VALUES ('I597','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I598','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I599','High');

INSERT INTO Illness (Name,Severity) VALUES ('I600','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I601','High');

INSERT INTO Illness (Name,Severity) VALUES ('I602','High');

INSERT INTO Illness (Name,Severity) VALUES ('I603','High');

INSERT INTO Illness (Name,Severity) VALUES ('I604','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I605','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I606','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I607','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I608','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I609','High');

INSERT INTO Illness (Name,Severity) VALUES ('I610','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I611','High');

INSERT INTO Illness (Name,Severity) VALUES ('I612','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I613','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I614','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I615','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I616','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I617','High');

INSERT INTO Illness (Name,Severity) VALUES ('I618','High');

INSERT INTO Illness (Name,Severity) VALUES ('I619','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I620','High');

INSERT INTO Illness (Name,Severity) VALUES ('I621','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I622','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I623','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I624','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I625','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I626','High');

INSERT INTO Illness (Name,Severity) VALUES ('I627','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I628','High');

INSERT INTO Illness (Name,Severity) VALUES ('I629','High');

INSERT INTO Illness (Name,Severity) VALUES ('I630','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I631','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I632','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I633','High');

INSERT INTO Illness (Name,Severity) VALUES ('I634','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I635','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I636','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I637','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I638','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I639','High');

INSERT INTO Illness (Name,Severity) VALUES ('I640','High');

INSERT INTO Illness (Name,Severity) VALUES ('I641','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I642','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I643','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I644','High');

INSERT INTO Illness (Name,Severity) VALUES ('I645','High');

INSERT INTO Illness (Name,Severity) VALUES ('I646','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I647','High');

INSERT INTO Illness (Name,Severity) VALUES ('I648','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I649','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I650','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I651','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I652','High');

INSERT INTO Illness (Name,Severity) VALUES ('I653','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I654','High');

INSERT INTO Illness (Name,Severity) VALUES ('I655','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I656','High');

INSERT INTO Illness (Name,Severity) VALUES ('I657','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I658','High');

INSERT INTO Illness (Name,Severity) VALUES ('I659','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I660','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I661','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I662','High');

INSERT INTO Illness (Name,Severity) VALUES ('I663','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I664','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I665','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I666','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I667','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I668','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I669','High');

INSERT INTO Illness (Name,Severity) VALUES ('I670','High');

INSERT INTO Illness (Name,Severity) VALUES ('I671','High');

INSERT INTO Illness (Name,Severity) VALUES ('I672','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I673','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I674','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I675','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I676','High');

INSERT INTO Illness (Name,Severity) VALUES ('I677','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I678','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I679','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I680','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I681','High');

INSERT INTO Illness (Name,Severity) VALUES ('I682','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I683','High');

INSERT INTO Illness (Name,Severity) VALUES ('I684','High');

INSERT INTO Illness (Name,Severity) VALUES ('I685','High');

INSERT INTO Illness (Name,Severity) VALUES ('I686','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I687','High');

INSERT INTO Illness (Name,Severity) VALUES ('I688','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I689','High');

INSERT INTO Illness (Name,Severity) VALUES ('I690','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I691','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I692','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I693','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I694','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I695','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I696','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I697','High');

INSERT INTO Illness (Name,Severity) VALUES ('I698','High');

INSERT INTO Illness (Name,Severity) VALUES ('I699','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I700','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I701','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I702','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I703','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I704','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I705','High');

INSERT INTO Illness (Name,Severity) VALUES ('I706','High');

INSERT INTO Illness (Name,Severity) VALUES ('I707','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I708','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I709','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I710','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I711','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I712','High');

INSERT INTO Illness (Name,Severity) VALUES ('I713','High');

INSERT INTO Illness (Name,Severity) VALUES ('I714','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I715','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I716','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I717','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I718','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I719','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I720','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I721','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I722','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I723','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I724','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I725','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I726','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I727','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I728','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I729','High');

INSERT INTO Illness (Name,Severity) VALUES ('I730','High');

INSERT INTO Illness (Name,Severity) VALUES ('I731','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I732','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I733','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I734','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I735','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I736','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I737','High');

INSERT INTO Illness (Name,Severity) VALUES ('I738','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I739','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I740','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I741','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I742','High');

INSERT INTO Illness (Name,Severity) VALUES ('I743','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I744','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I745','High');

INSERT INTO Illness (Name,Severity) VALUES ('I746','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I747','High');

INSERT INTO Illness (Name,Severity) VALUES ('I748','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I749','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I750','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I751','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I752','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I753','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I754','High');

INSERT INTO Illness (Name,Severity) VALUES ('I755','High');

INSERT INTO Illness (Name,Severity) VALUES ('I756','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I757','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I758','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I759','High');

INSERT INTO Illness (Name,Severity) VALUES ('I760','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I761','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I762','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I763','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I764','High');

INSERT INTO Illness (Name,Severity) VALUES ('I765','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I766','High');

INSERT INTO Illness (Name,Severity) VALUES ('I767','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I768','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I769','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I770','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I771','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I772','High');

INSERT INTO Illness (Name,Severity) VALUES ('I773','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I774','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I775','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I776','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I777','High');

INSERT INTO Illness (Name,Severity) VALUES ('I778','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I779','High');

INSERT INTO Illness (Name,Severity) VALUES ('I780','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I781','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I782','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I783','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I784','High');

INSERT INTO Illness (Name,Severity) VALUES ('I785','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I786','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I787','High');

INSERT INTO Illness (Name,Severity) VALUES ('I788','High');

INSERT INTO Illness (Name,Severity) VALUES ('I789','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I790','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I791','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I792','High');

INSERT INTO Illness (Name,Severity) VALUES ('I793','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I794','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I795','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I796','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I797','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I798','High');

INSERT INTO Illness (Name,Severity) VALUES ('I799','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I800','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I801','High');

INSERT INTO Illness (Name,Severity) VALUES ('I802','High');

INSERT INTO Illness (Name,Severity) VALUES ('I803','High');

INSERT INTO Illness (Name,Severity) VALUES ('I804','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I805','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I806','High');

INSERT INTO Illness (Name,Severity) VALUES ('I807','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I808','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I809','High');

INSERT INTO Illness (Name,Severity) VALUES ('I810','High');

INSERT INTO Illness (Name,Severity) VALUES ('I811','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I812','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I813','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I814','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I815','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I816','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I817','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I818','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I819','High');

INSERT INTO Illness (Name,Severity) VALUES ('I820','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I821','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I822','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I823','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I824','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I825','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I826','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I827','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I828','High');

INSERT INTO Illness (Name,Severity) VALUES ('I829','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I830','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I831','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I832','High');

INSERT INTO Illness (Name,Severity) VALUES ('I833','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I834','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I835','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I836','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I837','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I838','High');

INSERT INTO Illness (Name,Severity) VALUES ('I839','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I840','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I841','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I842','High');

INSERT INTO Illness (Name,Severity) VALUES ('I843','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I844','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I845','High');

INSERT INTO Illness (Name,Severity) VALUES ('I846','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I847','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I848','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I849','High');

INSERT INTO Illness (Name,Severity) VALUES ('I850','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I851','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I852','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I853','High');

INSERT INTO Illness (Name,Severity) VALUES ('I854','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I855','High');

INSERT INTO Illness (Name,Severity) VALUES ('I856','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I857','High');

INSERT INTO Illness (Name,Severity) VALUES ('I858','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I859','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I860','High');

INSERT INTO Illness (Name,Severity) VALUES ('I861','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I862','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I863','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I864','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I865','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I866','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I867','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I868','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I869','High');

INSERT INTO Illness (Name,Severity) VALUES ('I870','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I871','High');

INSERT INTO Illness (Name,Severity) VALUES ('I872','High');

INSERT INTO Illness (Name,Severity) VALUES ('I873','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I874','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I875','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I876','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I877','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I878','High');

INSERT INTO Illness (Name,Severity) VALUES ('I879','High');

INSERT INTO Illness (Name,Severity) VALUES ('I880','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I881','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I882','High');

INSERT INTO Illness (Name,Severity) VALUES ('I883','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I884','High');

INSERT INTO Illness (Name,Severity) VALUES ('I885','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I886','High');

INSERT INTO Illness (Name,Severity) VALUES ('I887','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I888','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I889','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I890','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I891','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I892','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I893','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I894','High');

INSERT INTO Illness (Name,Severity) VALUES ('I895','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I896','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I897','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I898','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I899','High');

INSERT INTO Illness (Name,Severity) VALUES ('I900','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I901','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I902','High');

INSERT INTO Illness (Name,Severity) VALUES ('I903','High');

INSERT INTO Illness (Name,Severity) VALUES ('I904','High');

INSERT INTO Illness (Name,Severity) VALUES ('I905','High');

INSERT INTO Illness (Name,Severity) VALUES ('I906','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I907','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I908','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I909','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I910','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I911','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I912','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I913','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I914','High');

INSERT INTO Illness (Name,Severity) VALUES ('I915','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I916','High');

INSERT INTO Illness (Name,Severity) VALUES ('I917','High');

INSERT INTO Illness (Name,Severity) VALUES ('I918','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I919','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I920','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I921','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I922','High');

INSERT INTO Illness (Name,Severity) VALUES ('I923','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I924','High');

INSERT INTO Illness (Name,Severity) VALUES ('I925','High');

INSERT INTO Illness (Name,Severity) VALUES ('I926','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I927','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I928','High');

INSERT INTO Illness (Name,Severity) VALUES ('I929','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I930','High');

INSERT INTO Illness (Name,Severity) VALUES ('I931','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I932','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I933','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I934','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I935','High');

INSERT INTO Illness (Name,Severity) VALUES ('I936','High');

INSERT INTO Illness (Name,Severity) VALUES ('I937','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I938','High');

INSERT INTO Illness (Name,Severity) VALUES ('I939','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I940','High');

INSERT INTO Illness (Name,Severity) VALUES ('I941','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I942','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I943','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I944','High');

INSERT INTO Illness (Name,Severity) VALUES ('I945','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I946','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I947','High');

INSERT INTO Illness (Name,Severity) VALUES ('I948','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I949','High');

INSERT INTO Illness (Name,Severity) VALUES ('I950','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I951','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I952','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I953','High');

INSERT INTO Illness (Name,Severity) VALUES ('I954','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I955','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I956','High');

INSERT INTO Illness (Name,Severity) VALUES ('I957','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I958','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I959','High');

INSERT INTO Illness (Name,Severity) VALUES ('I960','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I961','High');

INSERT INTO Illness (Name,Severity) VALUES ('I962','High');

INSERT INTO Illness (Name,Severity) VALUES ('I963','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I964','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I965','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I966','High');

INSERT INTO Illness (Name,Severity) VALUES ('I967','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I968','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I969','High');

INSERT INTO Illness (Name,Severity) VALUES ('I970','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I971','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I972','High');

INSERT INTO Illness (Name,Severity) VALUES ('I973','High');

INSERT INTO Illness (Name,Severity) VALUES ('I974','High');

INSERT INTO Illness (Name,Severity) VALUES ('I975','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I976','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I977','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I978','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I979','High');

INSERT INTO Illness (Name,Severity) VALUES ('I980','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I981','High');

INSERT INTO Illness (Name,Severity) VALUES ('I982','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I983','High');

INSERT INTO Illness (Name,Severity) VALUES ('I984','High');

INSERT INTO Illness (Name,Severity) VALUES ('I985','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I986','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I987','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I988','High');

INSERT INTO Illness (Name,Severity) VALUES ('I989','High');

INSERT INTO Illness (Name,Severity) VALUES ('I990','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I991','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I992','High');

INSERT INTO Illness (Name,Severity) VALUES ('I993','High');

INSERT INTO Illness (Name,Severity) VALUES ('I994','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I995','High');

INSERT INTO Illness (Name,Severity) VALUES ('I996','High');

INSERT INTO Illness (Name,Severity) VALUES ('I997','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I998','Low');

INSERT INTO Illness (Name,Severity) VALUES ('I999','Medium');

INSERT INTO Illness (Name,Severity) VALUES ('I1000','Medium');

