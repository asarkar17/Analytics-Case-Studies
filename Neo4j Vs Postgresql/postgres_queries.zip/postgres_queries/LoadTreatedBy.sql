INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P10');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P11');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P12');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P13');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P14');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P15');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P16');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P17');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P18');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P19');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P20');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P21');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P22');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P23');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P24');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P25');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P26');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P27');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P28');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P29');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P30');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P31');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P32');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P33');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P34');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P35');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P36');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P37');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P38');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P39');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P40');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P41');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P42');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P43');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P44');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P45');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P46');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P47');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P48');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P49');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P50');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P51');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P52');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P53');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P54');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P55');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P56');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P57');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P58');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P59');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P60');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P61');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P62');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P63');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P64');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P65');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P66');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P67');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P68');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P69');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P70');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P71');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P72');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P73');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P74');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P75');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P76');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P77');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P78');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P79');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P80');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P81');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P82');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P83');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P84');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P85');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P86');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P87');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P88');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P89');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P90');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P91');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P92');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P93');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P94');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P95');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P96');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P97');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P98');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P99');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1000');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1001');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1002');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1003');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1004');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1005');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1006');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1007');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1008');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1009');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1010');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1011');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1012');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1013');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1014');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1015');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1016');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1017');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1018');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1019');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1020');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1021');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1022');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1023');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1024');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1025');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1026');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1027');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1028');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1029');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1030');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1031');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1032');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1033');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1034');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1035');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1036');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1037');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1038');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1039');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1040');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1041');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1042');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1043');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1044');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1045');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1046');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1047');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1048');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1049');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1050');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1051');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1052');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1053');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1054');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1055');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1056');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1057');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1058');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1059');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1060');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1061');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1062');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1063');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1064');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1065');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1066');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1067');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1068');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1069');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1070');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1071');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1072');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1073');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1074');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1075');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1076');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1077');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1078');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1079');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1080');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1081');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1082');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1083');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1084');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1085');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1086');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1087');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1088');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1089');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1090');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1091');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1092');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1093');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1094');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1095');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1096');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1097');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1098');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1099');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P1900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P1901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P1902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P1903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P1904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P1905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P1906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P1907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P1908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P1909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P1910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P1911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P1912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P1913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P1914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P1915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P1916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P1917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P1918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P1919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P1920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P1921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P1922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P1923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P1924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P1925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P1926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P1927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P1928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P1929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P1930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P1931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P1932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P1933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P1934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P1935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P1936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P1937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P1938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P1939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P1940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P1941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P1942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P1943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P1944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P1945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P1946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P1947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P1948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P1949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P1950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P1951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P1952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P1953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P1954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P1955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P1956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P1957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P1958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P1959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P1960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P1961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P1962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P1963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P1964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P1965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P1966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P1967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P1968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P1969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P1970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P1971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P1972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P1973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P1974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P1975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P1976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P1977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P1978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P1979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P1980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P1981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P1982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P1983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P1984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P1985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P1986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P1987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P1988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P1989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P1990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P1991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P1992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P1993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P1994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P1995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P1996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P1997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P1998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P1999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2000');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2001');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2002');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2003');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2004');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2005');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2006');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2007');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2008');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2009');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2010');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2011');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2012');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2013');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2014');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2015');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2016');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2017');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2018');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2019');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2020');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2021');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2022');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2023');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2024');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2025');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2026');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2027');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2028');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2029');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2030');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2031');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2032');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2033');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2034');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2035');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2036');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2037');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2038');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2039');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2040');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2041');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2042');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2043');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2044');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2045');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2046');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2047');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2048');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2049');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2050');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2051');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2052');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2053');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2054');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2055');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2056');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2057');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2058');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2059');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2060');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2061');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2062');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2063');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2064');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2065');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2066');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2067');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2068');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2069');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2070');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2071');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2072');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2073');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2074');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2075');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2076');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2077');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2078');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2079');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2080');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2081');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2082');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2083');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2084');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2085');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2086');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2087');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2088');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2089');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2090');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2091');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2092');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2093');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2094');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2095');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2096');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2097');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2098');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2099');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P2900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P2901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P2902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P2903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P2904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P2905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P2906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P2907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P2908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P2909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P2910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P2911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P2912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P2913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P2914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P2915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P2916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P2917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P2918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P2919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P2920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P2921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P2922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P2923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P2924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P2925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P2926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P2927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P2928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P2929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P2930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P2931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P2932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P2933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P2934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P2935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P2936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P2937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P2938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P2939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P2940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P2941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P2942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P2943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P2944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P2945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P2946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P2947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P2948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P2949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P2950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P2951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P2952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P2953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P2954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P2955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P2956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P2957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P2958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P2959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P2960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P2961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P2962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P2963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P2964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P2965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P2966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P2967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P2968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P2969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P2970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P2971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P2972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P2973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P2974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P2975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P2976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P2977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P2978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P2979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P2980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P2981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P2982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P2983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P2984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P2985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P2986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P2987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P2988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P2989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P2990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P2991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P2992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P2993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P2994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P2995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P2996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P2997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P2998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P2999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3000');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3001');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3002');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3003');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3004');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3005');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3006');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3007');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3008');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3009');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3010');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3011');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3012');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3013');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3014');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3015');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3016');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3017');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3018');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3019');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3020');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3021');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3022');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3023');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3024');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3025');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3026');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3027');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3028');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3029');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3030');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3031');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3032');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3033');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3034');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3035');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3036');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3037');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3038');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3039');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3040');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3041');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3042');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3043');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3044');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3045');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3046');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3047');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3048');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3049');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3050');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3051');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3052');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3053');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3054');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3055');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3056');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3057');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3058');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3059');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3060');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3061');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3062');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3063');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3064');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3065');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3066');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3067');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3068');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3069');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3070');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3071');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3072');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3073');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3074');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3075');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3076');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3077');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3078');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3079');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3080');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3081');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3082');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3083');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3084');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3085');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3086');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3087');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3088');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3089');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3090');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3091');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3092');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3093');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3094');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3095');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3096');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3097');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3098');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3099');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P3900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P3901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P3902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P3903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P3904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P3905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P3906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P3907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P3908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P3909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P3910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P3911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P3912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P3913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P3914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P3915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P3916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P3917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P3918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P3919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P3920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P3921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P3922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P3923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P3924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P3925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P3926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P3927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P3928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P3929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P3930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P3931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P3932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P3933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P3934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P3935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P3936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P3937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P3938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P3939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P3940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P3941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P3942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P3943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P3944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P3945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P3946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P3947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P3948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P3949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P3950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P3951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P3952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P3953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P3954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P3955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P3956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P3957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P3958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P3959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P3960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P3961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P3962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P3963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P3964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P3965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P3966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P3967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P3968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P3969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P3970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P3971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P3972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P3973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P3974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P3975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P3976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P3977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P3978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P3979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P3980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P3981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P3982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P3983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P3984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P3985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P3986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P3987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P3988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P3989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P3990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P3991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P3992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P3993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P3994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P3995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P3996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P3997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P3998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P3999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4000');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4001');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4002');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4003');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4004');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4005');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4006');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4007');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4008');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4009');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4010');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4011');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4012');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4013');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4014');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4015');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4016');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4017');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4018');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4019');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4020');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4021');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4022');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4023');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4024');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4025');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4026');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4027');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4028');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4029');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4030');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4031');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4032');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4033');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4034');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4035');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4036');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4037');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4038');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4039');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4040');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4041');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4042');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4043');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4044');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4045');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4046');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4047');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4048');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4049');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4050');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4051');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4052');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4053');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4054');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4055');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4056');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4057');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4058');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4059');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4060');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4061');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4062');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4063');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4064');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4065');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4066');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4067');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4068');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4069');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4070');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4071');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4072');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4073');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4074');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4075');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4076');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4077');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4078');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4079');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4080');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4081');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4082');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4083');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4084');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4085');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4086');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4087');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4088');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4089');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4090');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4091');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4092');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4093');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4094');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4095');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4096');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4097');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4098');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4099');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P4900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P4901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P4902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P4903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P4904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P4905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P4906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P4907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P4908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P4909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P4910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P4911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P4912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P4913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P4914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P4915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P4916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P4917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P4918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P4919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P4920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P4921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P4922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P4923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P4924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P4925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P4926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P4927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P4928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P4929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P4930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P4931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P4932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P4933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P4934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P4935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P4936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P4937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P4938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P4939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P4940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P4941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P4942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P4943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P4944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P4945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P4946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P4947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P4948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P4949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P4950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P4951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P4952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P4953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P4954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P4955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P4956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P4957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P4958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P4959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P4960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P4961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P4962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P4963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P4964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P4965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P4966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P4967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P4968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P4969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P4970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P4971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P4972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P4973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P4974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P4975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P4976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P4977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P4978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P4979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P4980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P4981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P4982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P4983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P4984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P4985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P4986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P4987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P4988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P4989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P4990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P4991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P4992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P4993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P4994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P4995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P4996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P4997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P4998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P4999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5000');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5001');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5002');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5003');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5004');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5005');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5006');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5007');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5008');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5009');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5010');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5011');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5012');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5013');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5014');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5015');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5016');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5017');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5018');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5019');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5020');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5021');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5022');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5023');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5024');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5025');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5026');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5027');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5028');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5029');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5030');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5031');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5032');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5033');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5034');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5035');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5036');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5037');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5038');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5039');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5040');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5041');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5042');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5043');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5044');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5045');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5046');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5047');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5048');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5049');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5050');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5051');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5052');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5053');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5054');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5055');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5056');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5057');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5058');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5059');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5060');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5061');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5062');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5063');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5064');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5065');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5066');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5067');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5068');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5069');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5070');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5071');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5072');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5073');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5074');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5075');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5076');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5077');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5078');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5079');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5080');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5081');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5082');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5083');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5084');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5085');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5086');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5087');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5088');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5089');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5090');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5091');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5092');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5093');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5094');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5095');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5096');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5097');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5098');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5099');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P5900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P5901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P5902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P5903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P5904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P5905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P5906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P5907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P5908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P5909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P5910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P5911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P5912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P5913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P5914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P5915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P5916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P5917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P5918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P5919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P5920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P5921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P5922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P5923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P5924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P5925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P5926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P5927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P5928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P5929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P5930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P5931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P5932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P5933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P5934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P5935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P5936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P5937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P5938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P5939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P5940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P5941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P5942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P5943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P5944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P5945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P5946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P5947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P5948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P5949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P5950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P5951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P5952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P5953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P5954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P5955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P5956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P5957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P5958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P5959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P5960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P5961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P5962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P5963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P5964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P5965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P5966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P5967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P5968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P5969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P5970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P5971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P5972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P5973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P5974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P5975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P5976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P5977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P5978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P5979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P5980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P5981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P5982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P5983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P5984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P5985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P5986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P5987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P5988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P5989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P5990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P5991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P5992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P5993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P5994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P5995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P5996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P5997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P5998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P5999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6000');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6001');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6002');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6003');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6004');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6005');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6006');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6007');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6008');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6009');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6010');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6011');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6012');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6013');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6014');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6015');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6016');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6017');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6018');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6019');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6020');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6021');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6022');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6023');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6024');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6025');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6026');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6027');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6028');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6029');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6030');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6031');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6032');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6033');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6034');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6035');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6036');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6037');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6038');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6039');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6040');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6041');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6042');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6043');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6044');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6045');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6046');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6047');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6048');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6049');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6050');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6051');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6052');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6053');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6054');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6055');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6056');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6057');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6058');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6059');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6060');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6061');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6062');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6063');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6064');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6065');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6066');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6067');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6068');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6069');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6070');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6071');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6072');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6073');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6074');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6075');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6076');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6077');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6078');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6079');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6080');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6081');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6082');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6083');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6084');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6085');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6086');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6087');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6088');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6089');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6090');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6091');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6092');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6093');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6094');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6095');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6096');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6097');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6098');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6099');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P6900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P6901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P6902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P6903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P6904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P6905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P6906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P6907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P6908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P6909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P6910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P6911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P6912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P6913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P6914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P6915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P6916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P6917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P6918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P6919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P6920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P6921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P6922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P6923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P6924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P6925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P6926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P6927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P6928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P6929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P6930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P6931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P6932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P6933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P6934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P6935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P6936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P6937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P6938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P6939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P6940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P6941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P6942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P6943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P6944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P6945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P6946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P6947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P6948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P6949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P6950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P6951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P6952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P6953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P6954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P6955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P6956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P6957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P6958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P6959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P6960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P6961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P6962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P6963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P6964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P6965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P6966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P6967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P6968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P6969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P6970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P6971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P6972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P6973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P6974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P6975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P6976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P6977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P6978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P6979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P6980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P6981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P6982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P6983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P6984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P6985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P6986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P6987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P6988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P6989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P6990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P6991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P6992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P6993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P6994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P6995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P6996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P6997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P6998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P6999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7000');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7001');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7002');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7003');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7004');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7005');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7006');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7007');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7008');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7009');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7010');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7011');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7012');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7013');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7014');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7015');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7016');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7017');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7018');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7019');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7020');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7021');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7022');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7023');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7024');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7025');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7026');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7027');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7028');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7029');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7030');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7031');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7032');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7033');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7034');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7035');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7036');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7037');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7038');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7039');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7040');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7041');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7042');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7043');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7044');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7045');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7046');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7047');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7048');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7049');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7050');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7051');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7052');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7053');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7054');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7055');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7056');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7057');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7058');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7059');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7060');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7061');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7062');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7063');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7064');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7065');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7066');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7067');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7068');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7069');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7070');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7071');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7072');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7073');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7074');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7075');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7076');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7077');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7078');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7079');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7080');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7081');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7082');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7083');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7084');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7085');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7086');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7087');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7088');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7089');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7090');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7091');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7092');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7093');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7094');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7095');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7096');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7097');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7098');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7099');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P7900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P7901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P7902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P7903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P7904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P7905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P7906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P7907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P7908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P7909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P7910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P7911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P7912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P7913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P7914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P7915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P7916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P7917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P7918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P7919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P7920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P7921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P7922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P7923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P7924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P7925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P7926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P7927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P7928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P7929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P7930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P7931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P7932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P7933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P7934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P7935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P7936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P7937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P7938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P7939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P7940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P7941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P7942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P7943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P7944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P7945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P7946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P7947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P7948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P7949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P7950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P7951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P7952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P7953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P7954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P7955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P7956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P7957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P7958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P7959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P7960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P7961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P7962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P7963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P7964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P7965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P7966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P7967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P7968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P7969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P7970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P7971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P7972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P7973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P7974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P7975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P7976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P7977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P7978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P7979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P7980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P7981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P7982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P7983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P7984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P7985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P7986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P7987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P7988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P7989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P7990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P7991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P7992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P7993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P7994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P7995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P7996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P7997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P7998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P7999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8000');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8001');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8002');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8003');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8004');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8005');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8006');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8007');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8008');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8009');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8010');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8011');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8012');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8013');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8014');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8015');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8016');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8017');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8018');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8019');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8020');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8021');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8022');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8023');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8024');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8025');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8026');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8027');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8028');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8029');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8030');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8031');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8032');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8033');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8034');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8035');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8036');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8037');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8038');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8039');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8040');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8041');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8042');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8043');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8044');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8045');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8046');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8047');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8048');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8049');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8050');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8051');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8052');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8053');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8054');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8055');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8056');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8057');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8058');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8059');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8060');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8061');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8062');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8063');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8064');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8065');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8066');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8067');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8068');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8069');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8070');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8071');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8072');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8073');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8074');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8075');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8076');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8077');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8078');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8079');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8080');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8081');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8082');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8083');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8084');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8085');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8086');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8087');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8088');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8089');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8090');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8091');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8092');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8093');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8094');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8095');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8096');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8097');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8098');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8099');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P8900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P8901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P8902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P8903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P8904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P8905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P8906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P8907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P8908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P8909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P8910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P8911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P8912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P8913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P8914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P8915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P8916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P8917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P8918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P8919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P8920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P8921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P8922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P8923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P8924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P8925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P8926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P8927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P8928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P8929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P8930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P8931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P8932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P8933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P8934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P8935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P8936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P8937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P8938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P8939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P8940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P8941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P8942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P8943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P8944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P8945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P8946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P8947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P8948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P8949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P8950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P8951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P8952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P8953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P8954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P8955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P8956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P8957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P8958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P8959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P8960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P8961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P8962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P8963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P8964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P8965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P8966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P8967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P8968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P8969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P8970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P8971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P8972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P8973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P8974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P8975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P8976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P8977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P8978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P8979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P8980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P8981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P8982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P8983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P8984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P8985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P8986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P8987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P8988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P8989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P8990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P8991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P8992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P8993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P8994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P8995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P8996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P8997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P8998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P8999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9000');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9001');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9002');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9003');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9004');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9005');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9006');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9007');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9008');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9009');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9010');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9011');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9012');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9013');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9014');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9015');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9016');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9017');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9018');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9019');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9020');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9021');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9022');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9023');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9024');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9025');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9026');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9027');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9028');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9029');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9030');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9031');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9032');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9033');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9034');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9035');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9036');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9037');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9038');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9039');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9040');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9041');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9042');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9043');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9044');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9045');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9046');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9047');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9048');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9049');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9050');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9051');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9052');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9053');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9054');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9055');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9056');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9057');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9058');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9059');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9060');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9061');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9062');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9063');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9064');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9065');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9066');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9067');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9068');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9069');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9070');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9071');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9072');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9073');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9074');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9075');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9076');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9077');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9078');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9079');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9080');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9081');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9082');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9083');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9084');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9085');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9086');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9087');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9088');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9089');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9090');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9091');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9092');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9093');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9094');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9095');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9096');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9097');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9098');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9099');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9100');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9101');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9102');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9103');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9104');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9105');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9106');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9107');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9108');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9109');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9110');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9111');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9112');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9113');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9114');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9115');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9116');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9117');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9118');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9119');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9120');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9121');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9122');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9123');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9124');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9125');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9126');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9127');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9128');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9129');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9130');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9131');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9132');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9133');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9134');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9135');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9136');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9137');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9138');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9139');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9140');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9141');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9142');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9143');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9144');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9145');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9146');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9147');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9148');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9149');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9150');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9151');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9152');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9153');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9154');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9155');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9156');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9157');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9158');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9159');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9160');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9161');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9162');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9163');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9164');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9165');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9166');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9167');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9168');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9169');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9170');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9171');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9172');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9173');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9174');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9175');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9176');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9177');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9178');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9179');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9180');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9181');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9182');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9183');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9184');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9185');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9186');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9187');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9188');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9189');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9190');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9191');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9192');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9193');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9194');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9195');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9196');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9197');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9198');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9199');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9200');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9201');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9202');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9203');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9204');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9205');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9206');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9207');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9208');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9209');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9210');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9211');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9212');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9213');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9214');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9215');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9216');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9217');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9218');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9219');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9220');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9221');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9222');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9223');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9224');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9225');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9226');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9227');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9228');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9229');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9230');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9231');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9232');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9233');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9234');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9235');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9236');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9237');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9238');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9239');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9240');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9241');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9242');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9243');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9244');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9245');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9246');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9247');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9248');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9249');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9250');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9251');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9252');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9253');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9254');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9255');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9256');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9257');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9258');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9259');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9260');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9261');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9262');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9263');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9264');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9265');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9266');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9267');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9268');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9269');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9270');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9271');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9272');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9273');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9274');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9275');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9276');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9277');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9278');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9279');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9280');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9281');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9282');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9283');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9284');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9285');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9286');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9287');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9288');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9289');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9290');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9291');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9292');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9293');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9294');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9295');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9296');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9297');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9298');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9299');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9300');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9301');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9302');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9303');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9304');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9305');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9306');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9307');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9308');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9309');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9310');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9311');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9312');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9313');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9314');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9315');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9316');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9317');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9318');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9319');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9320');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9321');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9322');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9323');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9324');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9325');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9326');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9327');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9328');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9329');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9330');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9331');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9332');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9333');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9334');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9335');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9336');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9337');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9338');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9339');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9340');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9341');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9342');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9343');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9344');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9345');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9346');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9347');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9348');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9349');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9350');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9351');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9352');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9353');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9354');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9355');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9356');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9357');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9358');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9359');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9360');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9361');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9362');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9363');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9364');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9365');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9366');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9367');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9368');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9369');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9370');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9371');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9372');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9373');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9374');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9375');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9376');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9377');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9378');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9379');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9380');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9381');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9382');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9383');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9384');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9385');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9386');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9387');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9388');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9389');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9390');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9391');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9392');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9393');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9394');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9395');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9396');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9397');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9398');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9399');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9400');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9401');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9402');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9403');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9404');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9405');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9406');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9407');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9408');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9409');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9410');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9411');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9412');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9413');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9414');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9415');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9416');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9417');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9418');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9419');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9420');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9421');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9422');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9423');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9424');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9425');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9426');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9427');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9428');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9429');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9430');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9431');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9432');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9433');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9434');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9435');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9436');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9437');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9438');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9439');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9440');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9441');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9442');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9443');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9444');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9445');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9446');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9447');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9448');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9449');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9450');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9451');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9452');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9453');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9454');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9455');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9456');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9457');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9458');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9459');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9460');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9461');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9462');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9463');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9464');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9465');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9466');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9467');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9468');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9469');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9470');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9471');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9472');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9473');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9474');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9475');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9476');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9477');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9478');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9479');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9480');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9481');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9482');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9483');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9484');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9485');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9486');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9487');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9488');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9489');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9490');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9491');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9492');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9493');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9494');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9495');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9496');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9497');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9498');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9499');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9500');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9501');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9502');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9503');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9504');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9505');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9506');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9507');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9508');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9509');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9510');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9511');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9512');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9513');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9514');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9515');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9516');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9517');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9518');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9519');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9520');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9521');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9522');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9523');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9524');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9525');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9526');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9527');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9528');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9529');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9530');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9531');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9532');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9533');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9534');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9535');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9536');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9537');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9538');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9539');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9540');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9541');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9542');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9543');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9544');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9545');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9546');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9547');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9548');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9549');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9550');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9551');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9552');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9553');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9554');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9555');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9556');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9557');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9558');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9559');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9560');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9561');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9562');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9563');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9564');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9565');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9566');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9567');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9568');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9569');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9570');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9571');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9572');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9573');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9574');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9575');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9576');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9577');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9578');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9579');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9580');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9581');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9582');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9583');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9584');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9585');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9586');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9587');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9588');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9589');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9590');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9591');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9592');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9593');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9594');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9595');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9596');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9597');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9598');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9599');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9600');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9601');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9602');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9603');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9604');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9605');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9606');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9607');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9608');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9609');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9610');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9611');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9612');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9613');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9614');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9615');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9616');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9617');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9618');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9619');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9620');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9621');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9622');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9623');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9624');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9625');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9626');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9627');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9628');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9629');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9630');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9631');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9632');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9633');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9634');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9635');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9636');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9637');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9638');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9639');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9640');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9641');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9642');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9643');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9644');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9645');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9646');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9647');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9648');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9649');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9650');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9651');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9652');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9653');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9654');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9655');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9656');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9657');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9658');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9659');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9660');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9661');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9662');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9663');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9664');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9665');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9666');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9667');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9668');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9669');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9670');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9671');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9672');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9673');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9674');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9675');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9676');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9677');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9678');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9679');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9680');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9681');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9682');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9683');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9684');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9685');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9686');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9687');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9688');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9689');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9690');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9691');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9692');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9693');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9694');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9695');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9696');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9697');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9698');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9699');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9700');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9701');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9702');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9703');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9704');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9705');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9706');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9707');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9708');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9709');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9710');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9711');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9712');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9713');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9714');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9715');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9716');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9717');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9718');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9719');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9720');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9721');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9722');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9723');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9724');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9725');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9726');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9727');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9728');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9729');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9730');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9731');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9732');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9733');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9734');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9735');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9736');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9737');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9738');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9739');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9740');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9741');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9742');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9743');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9744');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9745');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9746');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9747');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9748');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9749');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9750');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9751');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9752');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9753');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9754');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9755');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9756');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9757');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9758');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9759');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9760');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9761');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9762');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9763');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9764');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9765');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9766');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9767');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9768');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9769');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9770');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9771');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9772');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9773');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9774');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9775');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9776');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9777');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9778');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9779');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9780');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9781');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9782');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9783');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9784');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9785');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9786');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9787');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9788');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9789');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9790');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9791');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9792');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9793');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9794');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9795');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9796');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9797');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9798');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9799');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9800');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9801');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9802');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9803');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9804');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9805');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9806');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9807');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9808');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9809');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9810');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9811');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9812');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9813');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9814');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9815');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9816');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9817');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9818');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9819');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9820');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9821');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9822');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9823');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9824');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9825');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9826');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9827');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9828');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9829');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9830');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9831');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9832');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9833');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9834');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9835');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9836');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9837');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9838');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9839');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9840');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9841');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9842');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9843');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9844');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9845');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9846');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9847');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9848');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9849');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9850');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9851');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9852');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9853');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9854');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9855');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9856');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9857');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9858');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9859');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9860');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9861');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9862');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9863');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9864');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9865');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9866');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9867');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9868');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9869');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9870');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9871');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9872');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9873');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9874');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9875');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9876');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9877');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9878');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9879');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9880');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9881');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9882');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9883');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9884');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9885');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9886');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9887');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9888');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9889');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9890');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9891');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9892');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9893');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9894');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9895');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9896');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9897');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9898');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9899');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P9900');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','P9901');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','P9902');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','P9903');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','P9904');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','P9905');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','P9906');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','P9907');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','P9908');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','P9909');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','P9910');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','P9911');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','P9912');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','P9913');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','P9914');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','P9915');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','P9916');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','P9917');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','P9918');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','P9919');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','P9920');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','P9921');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','P9922');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','P9923');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','P9924');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','P9925');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','P9926');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','P9927');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','P9928');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','P9929');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','P9930');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','P9931');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','P9932');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','P9933');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','P9934');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','P9935');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D36','P9936');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D37','P9937');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D38','P9938');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D39','P9939');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D40','P9940');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D41','P9941');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D42','P9942');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D43','P9943');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D44','P9944');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D45','P9945');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D46','P9946');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D47','P9947');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D48','P9948');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D49','P9949');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D50','P9950');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D51','P9951');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D52','P9952');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D53','P9953');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D54','P9954');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D55','P9955');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D56','P9956');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D57','P9957');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D58','P9958');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D59','P9959');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D60','P9960');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D61','P9961');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D62','P9962');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D63','P9963');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D64','P9964');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D65','P9965');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D66','P9966');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D67','P9967');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D68','P9968');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D69','P9969');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D70','P9970');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D71','P9971');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D72','P9972');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D73','P9973');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D74','P9974');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D75','P9975');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D76','P9976');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D77','P9977');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D78','P9978');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D79','P9979');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D80','P9980');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D81','P9981');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D82','P9982');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D83','P9983');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D84','P9984');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D85','P9985');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D86','P9986');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D87','P9987');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D88','P9988');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D89','P9989');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D90','P9990');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D91','P9991');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D92','P9992');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D93','P9993');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D94','P9994');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D95','P9995');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D96','P9996');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D97','P9997');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D98','P9998');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D99','P9999');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D100','P10000');

