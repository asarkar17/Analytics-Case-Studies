INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (11,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (12,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (13,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (14,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (15,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (16,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (17,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (18,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (19,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (20,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (21,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (22,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (23,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (24,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (25,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (26,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (27,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (28,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (29,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (30,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (31,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (32,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (33,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (34,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (35,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (36,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (37,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (38,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (39,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (40,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (41,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (42,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (43,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (44,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (45,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (46,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (47,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (48,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (49,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (50,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (51,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (52,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (53,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (54,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (55,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (56,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (57,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (58,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (59,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (60,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (61,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (62,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (63,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (64,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (65,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (66,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (67,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (68,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (69,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (70,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (71,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (72,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (73,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (74,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (75,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (76,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (77,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (78,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (79,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (80,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (81,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (82,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (83,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (84,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (85,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (86,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (87,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (88,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (89,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (90,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (91,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (92,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (93,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (94,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (95,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (96,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (97,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (98,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (99,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1035,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1036,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1037,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1038,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1039,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1040,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1041,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1042,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1043,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1044,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1045,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1046,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1047,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1048,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1049,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1050,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1051,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1052,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1053,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1054,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1055,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1056,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1057,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1058,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1059,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1060,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1061,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1062,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1063,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1064,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1065,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1066,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1067,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1068,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1069,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1070,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1071,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1072,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1073,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1074,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1075,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1076,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1077,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1078,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1079,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1080,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1081,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1082,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1083,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1084,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1085,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1086,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1087,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1088,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1089,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1090,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1091,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1092,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1093,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1094,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1095,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1096,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1097,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1098,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1099,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (1999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2035,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2036,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2037,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2038,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2039,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2040,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2041,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2042,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2043,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2044,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2045,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2046,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2047,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2048,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2049,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2050,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2051,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2052,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2053,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2054,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2055,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2056,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2057,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2058,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2059,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2060,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2061,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2062,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2063,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2064,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2065,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2066,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2067,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2068,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2069,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2070,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2071,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2072,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2073,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2074,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2075,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2076,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2077,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2078,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2079,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2080,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2081,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2082,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2083,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2084,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2085,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2086,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2087,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2088,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2089,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2090,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2091,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2092,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2093,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2094,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2095,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2096,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2097,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2098,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2099,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (2999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3035,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3036,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3037,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3038,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3039,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3040,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3041,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3042,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3043,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3044,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3045,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3046,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3047,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3048,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3049,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3050,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3051,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3052,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3053,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3054,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3055,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3056,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3057,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3058,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3059,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3060,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3061,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3062,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3063,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3064,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3065,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3066,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3067,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3068,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3069,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3070,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3071,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3072,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3073,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3074,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3075,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3076,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3077,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3078,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3079,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3080,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3081,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3082,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3083,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3084,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3085,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3086,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3087,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3088,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3089,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3090,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3091,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3092,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3093,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3094,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3095,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3096,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3097,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3098,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3099,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (3999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4035,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4036,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4037,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4038,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4039,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4040,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4041,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4042,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4043,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4044,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4045,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4046,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4047,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4048,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4049,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4050,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4051,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4052,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4053,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4054,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4055,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4056,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4057,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4058,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4059,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4060,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4061,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4062,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4063,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4064,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4065,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4066,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4067,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4068,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4069,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4070,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4071,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4072,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4073,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4074,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4075,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4076,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4077,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4078,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4079,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4080,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4081,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4082,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4083,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4084,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4085,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4086,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4087,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4088,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4089,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4090,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4091,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4092,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4093,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4094,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4095,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4096,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4097,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4098,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4099,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (4999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5035,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5036,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5037,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5038,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5039,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5040,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5041,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5042,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5043,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5044,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5045,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5046,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5047,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5048,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5049,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5050,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5051,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5052,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5053,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5054,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5055,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5056,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5057,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5058,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5059,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5060,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5061,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5062,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5063,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5064,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5065,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5066,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5067,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5068,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5069,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5070,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5071,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5072,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5073,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5074,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5075,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5076,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5077,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5078,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5079,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5080,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5081,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5082,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5083,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5084,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5085,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5086,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5087,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5088,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5089,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5090,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5091,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5092,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5093,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5094,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5095,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5096,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5097,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5098,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5099,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (5999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6035,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6036,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6037,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6038,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6039,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6040,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6041,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6042,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6043,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6044,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6045,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6046,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6047,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6048,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6049,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6050,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6051,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6052,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6053,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6054,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6055,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6056,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6057,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6058,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6059,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6060,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6061,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6062,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6063,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6064,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6065,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6066,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6067,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6068,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6069,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6070,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6071,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6072,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6073,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6074,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6075,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6076,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6077,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6078,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6079,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6080,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6081,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6082,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6083,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6084,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6085,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6086,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6087,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6088,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6089,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6090,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6091,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6092,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6093,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6094,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6095,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6096,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6097,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6098,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6099,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (6999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7035,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7036,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7037,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7038,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7039,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7040,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7041,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7042,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7043,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7044,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7045,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7046,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7047,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7048,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7049,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7050,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7051,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7052,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7053,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7054,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7055,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7056,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7057,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7058,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7059,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7060,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7061,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7062,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7063,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7064,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7065,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7066,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7067,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7068,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7069,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7070,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7071,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7072,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7073,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7074,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7075,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7076,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7077,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7078,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7079,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7080,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7081,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7082,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7083,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7084,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7085,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7086,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7087,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7088,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7089,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7090,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7091,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7092,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7093,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7094,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7095,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7096,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7097,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7098,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7099,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (7999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8035,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8036,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8037,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8038,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8039,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8040,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8041,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8042,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8043,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8044,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8045,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8046,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8047,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8048,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8049,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8050,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8051,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8052,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8053,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8054,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8055,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8056,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8057,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8058,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8059,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8060,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8061,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8062,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8063,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8064,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8065,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8066,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8067,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8068,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8069,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8070,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8071,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8072,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8073,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8074,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8075,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8076,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8077,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8078,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8079,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8080,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8081,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8082,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8083,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8084,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8085,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8086,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8087,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8088,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8089,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8090,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8091,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8092,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8093,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8094,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8095,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8096,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8097,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8098,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8099,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (8999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9035,35);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9036,36);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9037,37);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9038,38);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9039,39);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9040,40);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9041,41);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9042,42);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9043,43);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9044,44);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9045,45);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9046,46);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9047,47);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9048,48);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9049,49);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9050,50);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9051,51);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9052,52);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9053,53);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9054,54);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9055,55);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9056,56);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9057,57);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9058,58);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9059,59);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9060,60);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9061,61);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9062,62);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9063,63);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9064,64);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9065,65);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9066,66);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9067,67);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9068,68);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9069,69);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9070,70);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9071,71);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9072,72);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9073,73);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9074,74);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9075,75);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9076,76);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9077,77);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9078,78);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9079,79);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9080,80);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9081,81);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9082,82);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9083,83);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9084,84);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9085,85);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9086,86);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9087,87);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9088,88);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9089,89);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9090,90);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9091,91);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9092,92);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9093,93);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9094,94);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9095,95);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9096,96);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9097,97);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9098,98);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9099,99);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9100,100);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9101,101);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9102,102);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9103,103);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9104,104);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9105,105);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9106,106);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9107,107);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9108,108);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9109,109);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9110,110);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9111,111);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9112,112);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9113,113);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9114,114);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9115,115);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9116,116);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9117,117);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9118,118);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9119,119);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9120,120);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9121,121);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9122,122);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9123,123);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9124,124);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9125,125);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9126,126);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9127,127);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9128,128);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9129,129);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9130,130);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9131,131);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9132,132);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9133,133);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9134,134);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9135,135);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9136,136);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9137,137);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9138,138);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9139,139);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9140,140);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9141,141);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9142,142);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9143,143);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9144,144);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9145,145);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9146,146);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9147,147);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9148,148);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9149,149);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9150,150);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9151,151);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9152,152);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9153,153);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9154,154);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9155,155);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9156,156);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9157,157);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9158,158);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9159,159);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9160,160);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9161,161);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9162,162);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9163,163);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9164,164);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9165,165);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9166,166);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9167,167);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9168,168);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9169,169);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9170,170);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9171,171);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9172,172);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9173,173);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9174,174);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9175,175);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9176,176);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9177,177);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9178,178);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9179,179);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9180,180);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9181,181);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9182,182);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9183,183);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9184,184);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9185,185);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9186,186);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9187,187);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9188,188);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9189,189);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9190,190);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9191,191);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9192,192);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9193,193);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9194,194);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9195,195);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9196,196);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9197,197);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9198,198);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9199,199);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9200,200);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9201,201);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9202,202);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9203,203);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9204,204);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9205,205);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9206,206);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9207,207);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9208,208);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9209,209);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9210,210);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9211,211);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9212,212);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9213,213);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9214,214);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9215,215);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9216,216);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9217,217);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9218,218);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9219,219);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9220,220);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9221,221);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9222,222);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9223,223);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9224,224);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9225,225);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9226,226);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9227,227);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9228,228);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9229,229);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9230,230);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9231,231);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9232,232);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9233,233);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9234,234);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9235,235);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9236,236);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9237,237);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9238,238);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9239,239);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9240,240);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9241,241);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9242,242);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9243,243);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9244,244);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9245,245);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9246,246);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9247,247);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9248,248);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9249,249);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9250,250);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9251,251);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9252,252);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9253,253);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9254,254);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9255,255);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9256,256);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9257,257);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9258,258);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9259,259);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9260,260);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9261,261);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9262,262);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9263,263);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9264,264);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9265,265);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9266,266);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9267,267);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9268,268);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9269,269);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9270,270);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9271,271);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9272,272);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9273,273);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9274,274);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9275,275);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9276,276);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9277,277);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9278,278);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9279,279);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9280,280);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9281,281);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9282,282);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9283,283);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9284,284);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9285,285);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9286,286);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9287,287);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9288,288);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9289,289);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9290,290);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9291,291);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9292,292);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9293,293);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9294,294);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9295,295);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9296,296);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9297,297);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9298,298);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9299,299);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9300,300);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9301,301);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9302,302);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9303,303);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9304,304);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9305,305);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9306,306);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9307,307);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9308,308);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9309,309);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9310,310);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9311,311);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9312,312);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9313,313);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9314,314);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9315,315);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9316,316);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9317,317);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9318,318);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9319,319);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9320,320);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9321,321);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9322,322);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9323,323);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9324,324);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9325,325);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9326,326);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9327,327);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9328,328);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9329,329);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9330,330);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9331,331);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9332,332);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9333,333);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9334,334);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9335,335);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9336,336);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9337,337);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9338,338);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9339,339);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9340,340);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9341,341);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9342,342);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9343,343);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9344,344);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9345,345);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9346,346);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9347,347);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9348,348);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9349,349);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9350,350);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9351,351);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9352,352);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9353,353);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9354,354);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9355,355);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9356,356);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9357,357);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9358,358);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9359,359);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9360,360);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9361,361);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9362,362);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9363,363);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9364,364);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9365,365);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9366,366);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9367,367);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9368,368);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9369,369);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9370,370);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9371,371);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9372,372);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9373,373);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9374,374);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9375,375);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9376,376);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9377,377);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9378,378);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9379,379);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9380,380);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9381,381);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9382,382);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9383,383);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9384,384);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9385,385);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9386,386);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9387,387);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9388,388);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9389,389);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9390,390);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9391,391);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9392,392);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9393,393);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9394,394);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9395,395);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9396,396);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9397,397);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9398,398);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9399,399);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9400,400);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9401,401);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9402,402);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9403,403);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9404,404);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9405,405);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9406,406);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9407,407);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9408,408);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9409,409);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9410,410);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9411,411);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9412,412);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9413,413);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9414,414);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9415,415);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9416,416);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9417,417);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9418,418);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9419,419);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9420,420);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9421,421);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9422,422);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9423,423);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9424,424);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9425,425);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9426,426);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9427,427);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9428,428);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9429,429);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9430,430);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9431,431);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9432,432);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9433,433);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9434,434);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9435,435);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9436,436);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9437,437);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9438,438);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9439,439);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9440,440);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9441,441);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9442,442);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9443,443);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9444,444);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9445,445);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9446,446);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9447,447);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9448,448);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9449,449);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9450,450);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9451,451);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9452,452);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9453,453);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9454,454);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9455,455);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9456,456);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9457,457);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9458,458);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9459,459);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9460,460);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9461,461);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9462,462);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9463,463);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9464,464);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9465,465);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9466,466);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9467,467);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9468,468);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9469,469);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9470,470);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9471,471);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9472,472);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9473,473);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9474,474);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9475,475);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9476,476);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9477,477);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9478,478);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9479,479);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9480,480);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9481,481);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9482,482);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9483,483);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9484,484);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9485,485);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9486,486);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9487,487);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9488,488);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9489,489);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9490,490);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9491,491);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9492,492);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9493,493);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9494,494);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9495,495);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9496,496);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9497,497);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9498,498);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9499,499);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9500,500);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9501,501);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9502,502);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9503,503);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9504,504);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9505,505);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9506,506);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9507,507);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9508,508);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9509,509);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9510,510);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9511,511);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9512,512);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9513,513);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9514,514);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9515,515);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9516,516);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9517,517);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9518,518);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9519,519);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9520,520);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9521,521);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9522,522);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9523,523);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9524,524);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9525,525);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9526,526);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9527,527);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9528,528);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9529,529);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9530,530);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9531,531);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9532,532);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9533,533);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9534,534);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9535,535);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9536,536);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9537,537);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9538,538);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9539,539);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9540,540);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9541,541);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9542,542);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9543,543);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9544,544);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9545,545);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9546,546);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9547,547);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9548,548);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9549,549);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9550,550);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9551,551);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9552,552);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9553,553);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9554,554);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9555,555);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9556,556);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9557,557);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9558,558);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9559,559);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9560,560);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9561,561);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9562,562);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9563,563);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9564,564);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9565,565);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9566,566);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9567,567);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9568,568);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9569,569);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9570,570);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9571,571);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9572,572);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9573,573);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9574,574);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9575,575);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9576,576);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9577,577);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9578,578);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9579,579);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9580,580);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9581,581);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9582,582);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9583,583);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9584,584);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9585,585);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9586,586);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9587,587);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9588,588);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9589,589);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9590,590);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9591,591);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9592,592);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9593,593);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9594,594);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9595,595);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9596,596);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9597,597);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9598,598);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9599,599);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9600,600);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9601,601);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9602,602);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9603,603);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9604,604);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9605,605);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9606,606);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9607,607);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9608,608);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9609,609);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9610,610);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9611,611);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9612,612);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9613,613);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9614,614);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9615,615);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9616,616);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9617,617);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9618,618);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9619,619);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9620,620);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9621,621);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9622,622);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9623,623);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9624,624);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9625,625);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9626,626);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9627,627);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9628,628);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9629,629);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9630,630);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9631,631);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9632,632);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9633,633);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9634,634);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9635,635);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9636,636);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9637,637);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9638,638);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9639,639);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9640,640);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9641,641);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9642,642);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9643,643);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9644,644);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9645,645);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9646,646);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9647,647);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9648,648);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9649,649);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9650,650);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9651,651);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9652,652);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9653,653);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9654,654);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9655,655);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9656,656);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9657,657);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9658,658);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9659,659);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9660,660);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9661,661);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9662,662);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9663,663);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9664,664);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9665,665);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9666,666);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9667,667);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9668,668);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9669,669);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9670,670);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9671,671);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9672,672);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9673,673);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9674,674);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9675,675);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9676,676);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9677,677);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9678,678);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9679,679);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9680,680);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9681,681);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9682,682);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9683,683);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9684,684);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9685,685);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9686,686);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9687,687);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9688,688);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9689,689);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9690,690);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9691,691);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9692,692);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9693,693);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9694,694);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9695,695);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9696,696);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9697,697);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9698,698);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9699,699);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9700,700);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9701,701);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9702,702);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9703,703);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9704,704);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9705,705);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9706,706);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9707,707);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9708,708);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9709,709);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9710,710);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9711,711);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9712,712);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9713,713);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9714,714);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9715,715);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9716,716);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9717,717);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9718,718);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9719,719);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9720,720);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9721,721);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9722,722);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9723,723);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9724,724);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9725,725);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9726,726);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9727,727);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9728,728);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9729,729);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9730,730);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9731,731);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9732,732);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9733,733);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9734,734);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9735,735);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9736,736);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9737,737);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9738,738);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9739,739);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9740,740);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9741,741);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9742,742);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9743,743);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9744,744);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9745,745);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9746,746);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9747,747);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9748,748);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9749,749);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9750,750);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9751,751);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9752,752);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9753,753);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9754,754);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9755,755);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9756,756);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9757,757);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9758,758);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9759,759);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9760,760);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9761,761);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9762,762);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9763,763);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9764,764);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9765,765);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9766,766);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9767,767);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9768,768);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9769,769);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9770,770);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9771,771);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9772,772);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9773,773);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9774,774);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9775,775);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9776,776);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9777,777);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9778,778);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9779,779);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9780,780);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9781,781);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9782,782);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9783,783);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9784,784);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9785,785);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9786,786);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9787,787);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9788,788);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9789,789);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9790,790);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9791,791);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9792,792);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9793,793);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9794,794);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9795,795);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9796,796);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9797,797);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9798,798);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9799,799);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9800,800);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9801,801);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9802,802);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9803,803);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9804,804);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9805,805);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9806,806);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9807,807);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9808,808);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9809,809);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9810,810);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9811,811);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9812,812);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9813,813);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9814,814);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9815,815);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9816,816);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9817,817);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9818,818);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9819,819);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9820,820);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9821,821);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9822,822);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9823,823);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9824,824);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9825,825);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9826,826);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9827,827);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9828,828);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9829,829);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9830,830);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9831,831);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9832,832);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9833,833);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9834,834);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9835,835);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9836,836);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9837,837);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9838,838);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9839,839);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9840,840);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9841,841);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9842,842);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9843,843);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9844,844);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9845,845);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9846,846);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9847,847);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9848,848);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9849,849);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9850,850);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9851,851);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9852,852);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9853,853);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9854,854);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9855,855);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9856,856);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9857,857);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9858,858);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9859,859);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9860,860);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9861,861);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9862,862);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9863,863);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9864,864);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9865,865);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9866,866);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9867,867);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9868,868);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9869,869);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9870,870);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9871,871);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9872,872);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9873,873);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9874,874);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9875,875);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9876,876);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9877,877);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9878,878);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9879,879);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9880,880);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9881,881);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9882,882);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9883,883);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9884,884);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9885,885);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9886,886);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9887,887);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9888,888);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9889,889);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9890,890);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9891,891);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9892,892);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9893,893);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9894,894);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9895,895);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9896,896);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9897,897);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9898,898);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9899,899);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9900,900);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9901,901);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9902,902);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9903,903);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9904,904);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9905,905);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9906,906);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9907,907);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9908,908);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9909,909);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9910,910);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9911,911);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9912,912);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9913,913);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9914,914);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9915,915);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9916,916);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9917,917);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9918,918);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9919,919);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9920,920);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9921,921);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9922,922);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9923,923);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9924,924);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9925,925);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9926,926);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9927,927);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9928,928);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9929,929);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9930,930);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9931,931);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9932,932);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9933,933);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9934,934);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9935,935);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9936,936);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9937,937);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9938,938);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9939,939);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9940,940);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9941,941);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9942,942);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9943,943);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9944,944);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9945,945);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9946,946);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9947,947);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9948,948);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9949,949);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9950,950);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9951,951);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9952,952);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9953,953);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9954,954);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9955,955);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9956,956);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9957,957);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9958,958);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9959,959);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9960,960);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9961,961);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9962,962);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9963,963);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9964,964);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9965,965);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9966,966);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9967,967);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9968,968);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9969,969);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9970,970);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9971,971);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9972,972);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9973,973);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9974,974);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9975,975);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9976,976);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9977,977);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9978,978);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9979,979);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9980,980);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9981,981);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9982,982);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9983,983);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9984,984);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9985,985);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9986,986);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9987,987);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9988,988);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9989,989);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9990,990);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9991,991);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9992,992);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9993,993);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9994,994);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9995,995);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9996,996);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9997,997);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9998,998);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (9999,999);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10000,1000);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10001,1);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10002,2);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10003,3);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10004,4);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10005,5);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10006,6);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10007,7);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10008,8);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10009,9);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10010,10);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10011,11);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10012,12);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10013,13);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10014,14);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10015,15);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10016,16);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10017,17);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10018,18);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10019,19);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10020,20);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10021,21);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10022,22);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10023,23);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10024,24);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10025,25);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10026,26);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10027,27);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10028,28);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10029,29);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10030,30);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10031,31);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10032,32);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10033,33);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10034,34);

INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES (10035,35);

