INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D1','D51');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D2','D52');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D3','D53');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D4','D54');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D5','D55');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D6','D56');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D7','D57');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D8','D58');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D9','D59');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D10','D60');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D11','D61');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D12','D62');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D13','D63');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D14','D64');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D15','D65');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D16','D66');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D17','D67');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D18','D68');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D19','D69');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D20','D70');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D21','D71');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D22','D72');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D23','D73');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D24','D74');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D25','D75');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D26','D76');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D27','D77');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D28','D78');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D29','D79');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D30','D80');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D31','D81');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D32','D82');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D33','D83');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D34','D84');

INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('D35','D85');

