SELECT 'Doctor' as Table,COUNT(*) as Total_Count FROM Doctor UNION
SELECT 'Patient' as Table,COUNT(*) as Total_Count FROM Patient UNION
SELECT 'TreatedBy' as Table,COUNT(*) as Total_Count FROM TreatedBy UNION
SELECT 'Illness' as Table,COUNT(*) as Total_Count FROM Illness UNION
SELECT 'SufferingFrom' as Table,COUNT(*) as Total_Count FROM SufferingFrom UNION
SELECT 'Treatment' as Table,COUNT(*) as Total_Count FROM Treatment UNION
SELECT 'TreatmentPlan' as Table,COUNT(*) as Total_Count FROM TreatmentPlan UNION
SELECT 'IllnessTreatmentMapping' as Table,COUNT(*) as Total_Count FROM IllnessTreatmentMapping ;