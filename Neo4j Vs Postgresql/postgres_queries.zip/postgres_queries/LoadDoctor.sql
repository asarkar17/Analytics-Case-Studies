INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D1','MEDICAL GENETICS','matthewjackson@collins.org','Victoria','Martinez','591.235.9314x843','079 Sara Rapids Apt. 733','Suite 385','Johnshire','Minnesota','20026');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D1','OPHTHALMOLOGY','andrewfernandez@gmail.com','Cameron','Reyes','001-910-452-8229x4476','496 Juarez Ford Apt. 903','Apt. 185','South Dustin','Arkansas','80802');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D2','ANESTHESIOLOGY','catherinepaul@gmail.com','Joel','Ortiz','030.794.3774','055 Vega Rapids Apt. 816','Apt. 425','Michaelshire','Ohio','36717');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D3','ANESTHESIOLOGY','allenmark@hotmail.com','Micheal','Williams','001-187-947-3719x6885','4081 Kathleen Port','Suite 995','Haneytown','New York','38073');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D4','INTERNAL MEDICINE','jessica44@jones-romero.com','Terrence','Snyder','031.694.4179x9538','26928 Garcia Rapid','Suite 648','West Shelby','Arizona','68049');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D5','PSYCHIATRY','hfoster@salinas.net','William','Owen','+1-198-442-3803x01122','0410 Ernest Mission','Suite 960','Lake Jodiland','Arizona','82846');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D6','UROLOGY','michellecarr@moore.com','Wayne','Gay','001-485-589-9414x6109','791 Christopher Dam','Apt. 486','South Perry','Illinois','88398');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D7','PATHOLOGY','gregmartin@gmail.com','Alexandra','Lamb','462-196-1408x91889','723 Benjamin Light Apt. 056','Apt. 643','South Kaitlynshire','Rhode Island','96878');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D8','MEDICAL GENETICS','sballard@gmail.com','Chelsea','Clark','033.763.6908x3351','0381 Burke Grove Suite 272','Apt. 741','Tracifurt','Vermont','19758');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D9','NUCLEAR MEDICINE','anthony19@gmail.com','James','Floyd','001-492-210-1535','0259 Jennifer Centers','Apt. 760','West Andreafurt','Wyoming','96848');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D10','PEDIATRICS','john21@hotmail.com','Ashley','Waters','072.925.4523','14357 Alexander Landing','Apt. 622','Rogersstad','Kentucky','28706');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D11','OBSTETRICS AND GYNECOLOGY','jenniferbryant@davenport-bean.net','Jose','Gill','335-815-8069','8759 Palmer Extension Suite 284','Suite 502','Dianafort','Alaska','01975');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D12','OBSTETRICS AND GYNECOLOGY','bushcorey@nichols-gutierrez.net','William','Lopez','320.909.1420','6545 Garrison Mount','Apt. 352','Beckershire','North Dakota','99857');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D13','NUCLEAR MEDICINE','sabrinafisher@rose-decker.net','Melissa','Curry','+1-972-815-5064','6709 Megan Prairie Apt. 571','Apt. 888','West James','West Virginia','59583');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D14','MEDICAL GENETICS','cookjoseph@carrillo-figueroa.info','Colleen','Jones','4406377182','20343 Mcmahon Alley','Suite 470','Michellefurt','Florida','36125');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D15','OBSTETRICS AND GYNECOLOGY','joe86@wise.org','Valerie','Smith','052-842-8061x5348','812 Green Road Apt. 804','Suite 625','Richardmouth','West Virginia','20012');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D16','PSYCHIATRY','jakediaz@ramirez.net','Michael','Watkins','(134)736-8498','56949 Matthew Roads Suite 456','Suite 874','North Seanchester','Wisconsin','06304');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D17','DIAGNOSTIC RADIOLOGY','stephanie23@hotmail.com','Barbara','Nichols','001-297-148-0398x32611','964 Scott Neck','Apt. 919','Suttonshire','Mississippi','36446');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D18','ALLERGY & IMMUNOLOGY','smithgail@gonzalez-moore.com','Michael','Leonard','(223)996-0099','89743 Erica Mill','Suite 325','South Kim','Kansas','31754');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D19','PATHOLOGY','owenerik@yahoo.com','John','Miller','576.037.2729x5426','477 Coleman Key','Suite 614','East Brittanyhaven','Pennsylvania','56383');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D20','ANESTHESIOLOGY','janderson@suarez.com','Audrey','Wallace','+1-017-140-6379x90003','52401 Lynn Ridges','Suite 551','Bishoptown','Maine','85587');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D21','DERMATOLOGY','matthewzamora@hotmail.com','Elizabeth','Craig','001-320-373-4870x5684','1227 Gregory Shoals','Apt. 597','West Katherinechester','North Dakota','56276');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D22','EMERGENCY MEDICINE','marthaellis@hotmail.com','Nicole','Anderson','001-633-175-3284x543','68158 Stephen Plains Suite 062','Apt. 921','Lake Ryan','Delaware','99828');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D23','RADIATION ONCOLOGY','elizabethhammond@ramos-kidd.biz','Holly','Butler','195.405.7061','63961 Bennett Dale','Apt. 811','Carrollton','Pennsylvania','02939');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D24','OBSTETRICS AND GYNECOLOGY','tlewis@hotmail.com','Jonathan','Lucas','926.485.0494x7465','64644 Johnson Extensions','Suite 527','Richardburgh','Oregon','06027');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D25','SURGERY','jstrickland@jones.net','Richard','Baker','001-872-510-5120x16139','724 Ann Crescent','Suite 552','Lake Jason','Michigan','97058');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D26','UROLOGY','williamskathryn@mendez-leonard.com','Danielle','Carpenter','933-972-9664x212','093 Jay Radial Suite 023','Apt. 902','Mirandaton','Colorado','83467');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D27','PSYCHIATRY','zgross@yahoo.com','Sharon','Stewart','001-526-621-4113x54430','18363 Peterson Views Apt. 652','Apt. 248','Markview','Delaware','81330');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D28','MEDICAL GENETICS','katrina03@black.com','Stephen','Tyler','1536288038','5686 Guerrero Bridge','Suite 012','Michaelville','Arizona','07979');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D29','RADIATION ONCOLOGY','susan45@hotmail.com','Brian','Johnson','001-843-929-7062x93792','89758 Herrera Lodge','Apt. 076','New Matthewberg','New Jersey','88915');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D30','PATHOLOGY','fwilliams@gmail.com','Luke','Brown','+1-072-864-0123x16023','69292 Malik Knoll Suite 211','Apt. 123','Brooksburgh','Alaska','41424');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D31','RADIATION ONCOLOGY','hernandezbrian@ellis.org','Angela','Ho','079.093.1845x9165','433 Kelsey Street','Suite 732','South Brandi','Florida','29538');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D32','DERMATOLOGY','awatkins@hebert.com','Kelly','Martinez','1849791665','9746 Christopher Brooks','Apt. 975','Port Joshualand','Tennessee','06390');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D33','UROLOGY','tcampbell@yahoo.com','Joshua','Peterson','+1-666-839-8274x76213','4729 Jacobs Lights','Suite 894','Joseton','Ohio','19780');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D34','FAMILY MEDICINE','yking@yahoo.com','Jason','Ruiz','373.309.9162','80524 David Pines','Apt. 002','Port Amandafurt','Utah','53035');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D35','PEDIATRICS','michelle17@gmail.com','Jennifer','Mayer','974.705.9887x667','5760 Deborah Trafficway','Suite 347','West Angelaville','Wyoming','43286');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D36','DERMATOLOGY','regina58@johnson-jackson.com','Jason','Wiley','(783)033-4287x5207','76926 Brown Creek Apt. 675','Apt. 415','North Sarahport','Ohio','71025');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D37','RADIATION ONCOLOGY','kathleenfernandez@hotmail.com','Abigail','Rivas','+1-538-513-3678x6003','25076 Dorothy Plaza Apt. 500','Apt. 498','Gallowayside','Michigan','33085');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D38','ANESTHESIOLOGY','warrenjeffrey@mercer.com','Jerry','Haley','(755)623-7651x1567','0682 Palmer Crest','Apt. 286','Port Catherineview','New Jersey','02817');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D39','DIAGNOSTIC RADIOLOGY','buchananelizabeth@little-yu.info','Linda','Thompson','224-495-0976x5818','76051 Theresa Haven','Apt. 636','East Ashleyville','Arkansas','49303');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D40','UROLOGY','vaughandaniel@mendoza.biz','Robert','Miles','(642)564-7524x174','331 Steven Drive','Suite 434','Michaelfurt','West Virginia','64332');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D41','MEDICAL GENETICS','ewade@rodriguez-morris.com','Jennifer','Smith','+1-463-543-2778x085','43321 Emily Mission Suite 829','Suite 438','Cartershire','Nevada','42447');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D42','RADIATION ONCOLOGY','whitejoshua@yahoo.com','Mary','Flores','728-819-0608x58222','91082 Archer Estate Apt. 079','Suite 669','West Christian','Oklahoma','82825');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D43','SURGERY','kiara11@hotmail.com','Karen','Clark','001-226-688-3014x9467','6526 Paul Forest Apt. 934','Apt. 268','Williamfurt','South Dakota','83433');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D44','PATHOLOGY','carolanderson@hotmail.com','Hunter','Stevens','284.757.8640x290','79231 Brad Trafficway','Suite 752','Anthonyton','Connecticut','73301');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D45','PSYCHIATRY','gjohnson@gmail.com','Madeline','Lawson','(113)310-5432x290','93134 Melissa Shore Apt. 865','Suite 152','New Michael','Georgia','40015');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D46','EMERGENCY MEDICINE','jamesmata@yahoo.com','Samantha','Carpenter','566.060.2625','0546 Amber Terrace','Apt. 612','Davisfurt','Hawaii','80961');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D47','MEDICAL GENETICS','kimedward@spencer-walton.net','Tonya','Cruz','564-392-7383','88764 Christopher Plaza Apt. 899','Suite 822','East Paul','Nevada','29389');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D48','SURGERY','davidsontammy@cortez.com','Melinda','Butler','001-761-527-9771','931 Eric Union','Apt. 764','West Michaelton','Kentucky','03736');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D49','ALLERGY & IMMUNOLOGY','richard62@gmail.com','David','Burgess','(866)621-9432x092','9070 Nicole Mission','Apt. 570','Samanthamouth','Pennsylvania','60055');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D50','PSYCHIATRY','robertmartinez@gmail.com','John','Carlson','(143)876-6392x878','6081 Mary Summit','Suite 515','Conradville','Maine','08649');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D51','OBSTETRICS AND GYNECOLOGY','jasoncobb@briggs-cowan.net','Zachary','Carroll','001-022-334-2847x55005','1002 Allison Shores Suite 496','Suite 199','Robinsonborough','Iowa','89155');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D52','PEDIATRICS','millerjulia@cruz-nunez.com','Max','Nelson','205-936-3374','633 Huynh Island Apt. 660','Apt. 536','New Erinshire','New York','73152');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D53','EMERGENCY MEDICINE','jenniferbryant@hotmail.com','Kristen','Gay','6193796047','678 Crawford Key','Apt. 318','Lopezburgh','North Dakota','36742');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D54','PREVENTIVE MEDICINE','dalegates@williams.com','Michelle','Williams','001-268-523-4341x56787','82299 Sellers Center Apt. 065','Apt. 932','North Anthonybury','Louisiana','47514');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D55','EMERGENCY MEDICINE','johnnykelley@wood-miller.biz','James','Wade','(573)166-6279','8569 Tiffany Corner Suite 213','Apt. 141','Jefferyton','California','84479');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D56','EMERGENCY MEDICINE','liustephanie@yahoo.com','Amber','Tapia','(289)417-3853x5880','93134 Stone Spur Apt. 032','Suite 766','Smithberg','Colorado','19904');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D57','OBSTETRICS AND GYNECOLOGY','crystalclark@yahoo.com','Angela','Lewis','001-772-783-0575x722','1374 Robinson Loaf Suite 206','Apt. 423','Lake Wesleyport','Florida','04226');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D58','NUCLEAR MEDICINE','mdoyle@gmail.com','Alison','Munoz','(541)104-1691','240 Charles Mission Suite 347','Suite 198','Kathleenport','Alaska','84482');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D59','INTERNAL MEDICINE','uharrison@yahoo.com','Michael','Richardson','001-830-166-3572x8382','29435 Mark Pine','Suite 187','Timothyborough','Rhode Island','30100');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D60','DIAGNOSTIC RADIOLOGY','michaelgriffith@yahoo.com','Christopher','Gonzalez','+1-040-652-7677x37945','63791 Jennings Locks Apt. 055','Apt. 795','Kimberlyside','Rhode Island','50409');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D61','ANESTHESIOLOGY','philipalexander@hotmail.com','William','Hernandez','651-518-7685x9063','5103 Heather Ville','Suite 769','New Johnstad','Arizona','20331');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D62','RADIATION ONCOLOGY','jackhall@hotmail.com','Oscar','Burns','001-688-839-9199','04242 Jake Lights Apt. 738','Apt. 374','Schultztown','Arkansas','51699');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D63','EMERGENCY MEDICINE','stanleyjennifer@richardson-palmer.com','Maria','Ryan','+1-713-177-6993','6085 Ferguson Harbor','Suite 100','North Kristina','Texas','06141');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D64','OBSTETRICS AND GYNECOLOGY','guerrachristopher@jackson.info','Cindy','Fletcher','(851)281-1796x98458','413 Perez Glen Suite 334','Suite 454','East Leon','Massachusetts','32984');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D65','UROLOGY','psmith@hotmail.com','Linda','Lee','584-192-1431','06481 Eric Field','Suite 694','Stewartberg','Idaho','15230');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D66','OPHTHALMOLOGY','robert80@gmail.com','Daniel','Hughes','500-984-6621x7526','165 Gibbs Drive','Apt. 652','Lake Aaronview','Tennessee','99865');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D67','OPHTHALMOLOGY','jacquelinetorres@brown.biz','Pamela','Roy','+1-620-091-4516x431','7930 Mark Tunnel Apt. 173','Apt. 420','Stevenfurt','Texas','96787');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D68','PATHOLOGY','vsilva@gmail.com','William','Wolf','111.144.2189','26102 Robin Track Apt. 080','Suite 388','East Sierrastad','Montana','84513');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D69','PEDIATRICS','arobinson@harvey-harris.com','Susan','Barrett','174-775-9582','8239 Mary Forge Apt. 499','Suite 450','New Matthew','Nebraska','85582');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D70','PEDIATRICS','nelsonmegan@hotmail.com','Heather','Thompson','001-538-900-3012x94418','67132 Anderson Creek','Suite 440','Edwardport','Colorado','96868');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D71','FAMILY MEDICINE','donald42@gmail.com','Kimberly','Bullock','352.395.7149','9026 Davis Wall','Apt. 401','New Erikaberg','Nebraska','84178');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D72','PREVENTIVE MEDICINE','jphillips@franklin.info','Jill','Park','419-800-6835x64526','8201 Rodney Via Suite 252','Suite 492','Benderland','Indiana','67463');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D73','ANESTHESIOLOGY','johnnybenjamin@smith.com','Maria','Hanson','643.735.9877x1710','81203 David Village','Apt. 116','South Jennifer','Nevada','54318');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D74','OBSTETRICS AND GYNECOLOGY','ashley36@hotmail.com','Alicia','May','7951896309','3181 Barbara Brooks Apt. 854','Apt. 186','North Vincent','Iowa','06022');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D75','INTERNAL MEDICINE','hdavid@washington-harris.com','Kim','Manning','120.281.6917x3925','02262 Daniel Bypass Suite 417','Suite 640','Chungstad','Rhode Island','49598');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D76','MEDICAL GENETICS','qowens@scott.com','Kyle','Watkins','+1-855-957-5720x14925','087 Pearson Land Apt. 787','Apt. 935','South Davidville','Wyoming','59351');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D77','PREVENTIVE MEDICINE','bkennedy@yahoo.com','Sarah','Erickson','924-566-4049x3131','4435 Marks Forest','Apt. 569','West Bryan','North Carolina','29945');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D78','EMERGENCY MEDICINE','robert25@brown.com','Elizabeth','Baird','001-067-418-4225x69138','3343 Harris Inlet Suite 840','Suite 567','New Michael','Virginia','03333');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D79','NUCLEAR MEDICINE','dominiquewillis@yahoo.com','Henry','Gordon','970-429-0020','48576 Elizabeth Mount','Suite 237','New Taylor','North Dakota','65695');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D80','PEDIATRICS','mbanks@watson-bennett.net','Robin','Shaw','169-308-8753','7122 Susan Orchard Apt. 559','Apt. 197','Markberg','Vermont','97359');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D81','ALLERGY & IMMUNOLOGY','joshuamartinez@hill.net','Mary','Ibarra','+1-322-431-7445x23409','38642 Holloway Locks','Suite 598','West Russellbury','Massachusetts','32860');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D82','OPHTHALMOLOGY','elizabethzamora@yahoo.com','Timothy','White','(605)499-9076','053 Daniel Ports','Suite 469','East Heather','Oregon','27107');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D83','UROLOGY','fburke@perkins.com','Mary','Williams','909.520.9901x97647','833 Watson Harbor Suite 171','Apt. 011','North Lisaberg','Florida','68013');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D84','PSYCHIATRY','bryantrobert@hotmail.com','Steven','Pierce','660-265-2844','446 Steven Pike Suite 441','Apt. 772','Lake Danielshire','Indiana','49290');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D85','DIAGNOSTIC RADIOLOGY','joshuamurillo@gmail.com','David','Davis','102.712.9113x800','02487 Gary Lock','Apt. 780','Lake Davidview','Connecticut','20041');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D86','ALLERGY & IMMUNOLOGY','devin60@anderson.com','Vanessa','Johnson','6177747889','8763 Morgan Grove Suite 726','Apt. 764','Weeksville','New Jersey','27291');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D87','NEUROLOGY','sayala@perry.com','Veronica','Lutz','511-684-6253x91079','424 Paul Glens Apt. 586','Suite 103','Port Angelaton','Alabama','95621');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D88','OBSTETRICS AND GYNECOLOGY','myersbarbara@yahoo.com','Travis','Marks','+1-078-720-3300x52562','6653 Lynn Forges','Apt. 828','Lauraport','Rhode Island','02868');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D89','NUCLEAR MEDICINE','vwood@graham.org','Brian','Gonzalez','550.664.7278','19947 Castillo Street Suite 052','Apt. 053','West Brendaview','Texas','73045');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D90','PHYSICAL MEDICINE & REHABILITATION','williamscharles@yahoo.com','Kyle','Williamson','(738)879-9921x26960','607 Nolan Glens','Suite 155','Nathanport','Hawaii','29295');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D91','PREVENTIVE MEDICINE','sanderscheryl@graves.com','Kathy','Jackson','001-247-760-3045','6916 Cruz Fork Suite 654','Suite 258','Port Laurashire','Oregon','42373');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D92','INTERNAL MEDICINE','katienichols@hotmail.com','Anthony','Stewart','2508482516','26907 Turner Passage','Apt. 176','East Morgan','South Carolina','53775');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D93','INTERNAL MEDICINE','rogersrandy@collins-barry.com','Angela','Rojas','(541)404-7702x52447','1758 Jonathan Estates','Suite 851','Lake Michael','Wisconsin','97379');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D94','DIAGNOSTIC RADIOLOGY','amanda57@huffman.com','Rebecca','Valenzuela','+1-804-146-3499','923 Ashley Route','Suite 541','Brownfort','Colorado','27850');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D95','UROLOGY','jprice@mason.com','Mark','Ruiz','+1-475-125-9266x175','30594 Garcia Corner Suite 178','Suite 629','Port Nicholasmouth','West Virginia','05208');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D96','NUCLEAR MEDICINE','luis57@gmail.com','Kimberly','Martinez','001-428-599-8592x50585','3234 Melissa Ford','Suite 645','Shannonside','Connecticut','37311');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D97','NUCLEAR MEDICINE','thomas45@gmail.com','Taylor','Roberts','+1-644-005-5400','3599 Faith Cove Apt. 604','Suite 868','West Joantown','Connecticut','47674');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D98','PEDIATRICS','landerson@yahoo.com','Emily','Ochoa','+1-424-519-7166','3411 Glenda Stravenue Apt. 909','Apt. 134','Edwardsmouth','Michigan','82804');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D99','DERMATOLOGY','linda70@yahoo.com','Brittany','Russo','785-726-5106x20474','73959 Isaac Village Apt. 594','Apt. 740','Franklinhaven','Florida','25895');

INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('D100','UROLOGY','sabrina58@hotmail.com','Corey','Thompson','5241263434','013 Garcia Flats','Apt. 866','Alexanderhaven','Massachusetts','89291');

