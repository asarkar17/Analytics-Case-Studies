

CREATE TABLE Doctor ( 
DoctorKey VARCHAR(100) PRIMARY KEY,
AreaOfMedicine VARCHAR(200) NOT NULL,
EmailAddress VARCHAR(150) NOT NULL,
FirstName VARCHAR(100)NOT NULL,
LastName VARCHAR(100) NOT NULL,
PhoneNumber VARCHAR(50) NOT NULL,
AddressLine1 VARCHAR(250) NOT NULL,
AddressLine2 VARCHAR(250),
City VARCHAR(50) NOT NULL,
State VARCHAR(50) NOT NULL,
Zip VARCHAR(9) NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp);

CREATE TABLE Patient
(
PatientKey VARCHAR(100) PRIMARY KEY,
EmailAddress VARCHAR(150) NOT NULL,
FirstName VARCHAR(100)NOT NULL,
LastName VARCHAR(100) NOT NULL,
PhoneNumber VARCHAR(50) NOT NULL,
AddressLine1 VARCHAR(255) NOT NULL,
AddressLine2 VARCHAR(255),
City VARCHAR(50) NOT NULL,
State VARCHAR(50) NOT NULL,
Zip VARCHAR(9) NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE TreatedBy
(
LineNumber SERIAL PRIMARY KEY,
DoctorKey VARCHAR(100) NOT NULL,
PatientMasterID VARCHAR(100) NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp,
FOREIGN KEY (DoctorKey) REFERENCES Doctor(DoctorKey) MATCH FULL,
CHECK (DoctorKey <> PatientMasterID),
UNIQUE(DoctorKey,PatientMasterID)
);

CREATE OR REPLACE FUNCTION reject_not_existing_id()
    RETURNS "trigger" AS
    $BODY$
        BEGIN
            IF NEW.PatientMasterID NOT IN (SELECT DoctorKey FROM Doctor UNION SELECT PatientKey FROM Patient) THEN
                RAISE EXCEPTION 'Invalid Patient ID: %', NEW.PatientMasterID;
            END IF;
            RETURN NEW;
        END;
    $BODY$
        LANGUAGE 'plpgsql' VOLATILE;

CREATE TRIGGER tr_before_insert_or_update
    BEFORE INSERT OR UPDATE OF PatientMasterID
    ON TreatedBy
    FOR EACH ROW
    EXECUTE PROCEDURE reject_not_existing_id();

CREATE OR REPLACE FUNCTION max_patient_doc_check()
    RETURNS "trigger" AS
    $BODY$
        BEGIN
            IF EXISTS
			(SELECT PatientMasterID, COUNT(DoctorKey) FROM TreatedBy WHERE  PatientMasterID=NEW.PatientMasterID GROUP BY PatientMasterID HAVING COUNT(PatientMasterID)>5) THEN
                RAISE EXCEPTION 'Limit for Doctors mapped to the patient has exceeded: %', NEW.PatientMasterID;
            END IF;
            RETURN NEW;
        END;
    $BODY$
        LANGUAGE 'plpgsql' VOLATILE;

CREATE TRIGGER tr_before_insert_or_update_2
    BEFORE INSERT OR UPDATE OF PatientMasterID
    ON TreatedBy
    FOR EACH ROW
    EXECUTE PROCEDURE max_patient_doc_check();
	
CREATE TABLE Illness
(
IllnessKey SERIAL PRIMARY KEY,
Name VARCHAR(150) NOT NULL,
Severity VARCHAR(150) NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE Treatment
(
TreatmentKey SERIAL PRIMARY KEY,
Name VARCHAR(150) NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE IllnessTreatmentMapping
(
LineNumber SERIAL PRIMARY KEY,
TreatmentKey INTEGER NOT NULL,
IllnessKey INTEGER NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp,
FOREIGN KEY (TreatmentKey) REFERENCES Treatment(TreatmentKey) MATCH FULL,
FOREIGN KEY (IllnessKey) REFERENCES Illness(IllnessKey) MATCH FULL,
UNIQUE(TreatmentKey,IllnessKey)
);

CREATE TABLE SufferingFrom
(
LineNumber SERIAL PRIMARY KEY,
TBLineNumber INTEGER NOT NULL,
IllnessKey INTEGER NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp,
FOREIGN KEY (TBLineNumber) REFERENCES TreatedBy(LineNumber) MATCH FULL,
FOREIGN KEY (IllnessKey) REFERENCES Illness(IllnessKey) MATCH FULL,
UNIQUE(TBLineNumber,IllnessKey)
);

CREATE OR REPLACE FUNCTION insert_treatment_plan()
  RETURNS trigger AS
$BODY$
 BEGIN
     INSERT INTO TreatmentPlan(SFLineNumber,TreatmentKey)
     SELECT NEW.LineNumber, T2.TreatmentKey 
	 FROM IllnessTreatmentMapping T2
	 WHERE T2.IllnessKey = NEW.IllnessKey;
     RETURN NEW;
 END;
$BODY$
        LANGUAGE 'plpgsql' VOLATILE;
		
CREATE TRIGGER tr_after_insert
    AFTER INSERT
    ON SufferingFrom
    FOR EACH ROW
    EXECUTE PROCEDURE insert_treatment_plan();

CREATE TABLE TreatmentPlan
(
LineNumber SERIAL PRIMARY KEY,
SFLineNumber INTEGER NOT NULL,
TreatmentKey INTEGER NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp,
FOREIGN KEY (SFLineNumber) REFERENCES SufferingFrom(LineNumber) MATCH FULL,
FOREIGN KEY (TreatmentKey) REFERENCES Treatment(TreatmentKey) MATCH FULL,
UNIQUE(SFLineNumber,TreatmentKey)
);

