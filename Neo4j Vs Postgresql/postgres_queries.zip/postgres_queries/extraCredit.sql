
--How many doctors are treating doctors?

select count(*) as TotalCount
from treatedby
where substring(PatientMasterID for 1)='D' ; 


--What's the count of how many patients have each kind of illness?

select t3.Name as Illness,count(t2.PatientMasterID) as Total_Patients
from SufferingFrom t1 inner join Treatedby t2 on t1.TBLineNumber=t2.LineNumber
inner join illness t3 on t1.IllnessKey=t3.IllnessKey
GROUP BY t3.Name;


--What's the doctor with the most patients?

select CONCAT(t2.FirstName,' ',t2.LastName) as Doctor,count(PatientMasterID) as Total_Patients
from Treatedby t1 inner join Doctor t2 on t1.doctorkey=t2.doctorkey
group by CONCAT(t2.FirstName,' ',t2.LastName)
having count(PatientMasterID) =
(
select max(SQ.TC) from (
select count(PatientMasterID) over (partition by DoctorKey) as TC
from Treatedby) as SQ
);


--Which doctor is treating the largest number of unique illnesses?

SELECT CONCAT(T2.FirstName,' ',T2.LastName) as Dcotor, count(T7.Name) as IllnessCounts
FROM 
TreatedBy T1 INNER JOIN Doctor T2 ON T1.DoctorKey = T2.DoctorKey
INNER JOIN 
( SELECT DoctorKey AS PatientKey, CONCAT(FirstName,' ',LastName) AS PatientName FROM Doctor UNION 
SELECT PatientKey,CONCAT(FirstName,' ',LastName) AS PatientName FROM Patient ) T3 
ON T1.PatientMasterID = T3.PatientKey
INNER JOIN SufferingFrom T4 ON T4.TBLineNumber = T1.LineNumber
INNER JOIN TreatmentPlan T5 ON T4.LineNumber = T5.SFLineNumber
INNER JOIN IllnessTreatmentMapping T6 ON T6.TreatmentKey = T5.TreatmentKey AND T4.IllnessKey = T6.IllnessKey
INNER JOIN Illness T7 ON T7.IllnessKey = T6.IllnessKey
INNER JOIN Treatment T8 ON T8.TreatmentKey = T6.TreatmentKey
group by CONCAT(T2.FirstName,' ',T2.LastName)
having count(T7.Name) = (
select max(SQ.TC) from (
SELECT count(T7.Name) over (partition by CONCAT(T2.FirstName,' ',T2.LastName))  as TC
FROM 
TreatedBy T1 INNER JOIN Doctor T2 ON T1.DoctorKey = T2.DoctorKey
INNER JOIN 
( SELECT DoctorKey AS PatientKey, CONCAT(FirstName,' ',LastName) AS PatientName FROM Doctor UNION 
SELECT PatientKey,CONCAT(FirstName,' ',LastName) AS PatientName FROM Patient ) T3 
ON T1.PatientMasterID = T3.PatientKey
INNER JOIN SufferingFrom T4 ON T4.TBLineNumber = T1.LineNumber
INNER JOIN TreatmentPlan T5 ON T4.LineNumber = T5.SFLineNumber
INNER JOIN IllnessTreatmentMapping T6 ON T6.TreatmentKey = T5.TreatmentKey AND T4.IllnessKey = T6.IllnessKey
INNER JOIN Illness T7 ON T7.IllnessKey = T6.IllnessKey
INNER JOIN Treatment T8 ON T8.TreatmentKey = T6.TreatmentKey
) AS SQ
);


--What illness is being treated with the largest number of unique treatments?

SELECT T7.Name as Illness, count(T8.Name) as TreatmentCounts
FROM 
TreatedBy T1 INNER JOIN Doctor T2 ON T1.DoctorKey = T2.DoctorKey
INNER JOIN 
( SELECT DoctorKey AS PatientKey, CONCAT(FirstName,' ',LastName) AS PatientName FROM Doctor UNION 
SELECT PatientKey,CONCAT(FirstName,' ',LastName) AS PatientName FROM Patient ) T3 
ON T1.PatientMasterID = T3.PatientKey
INNER JOIN SufferingFrom T4 ON T4.TBLineNumber = T1.LineNumber
INNER JOIN TreatmentPlan T5 ON T4.LineNumber = T5.SFLineNumber
INNER JOIN IllnessTreatmentMapping T6 ON T6.TreatmentKey = T5.TreatmentKey AND T4.IllnessKey = T6.IllnessKey
INNER JOIN Illness T7 ON T7.IllnessKey = T6.IllnessKey
INNER JOIN Treatment T8 ON T8.TreatmentKey = T6.TreatmentKey
group by T7.Name
having count(T8.Name) = (
select max(SQ.TC) from (
SELECT count(T8.Name) over (partition by T7.Name)  as TC
FROM 
TreatedBy T1 INNER JOIN Doctor T2 ON T1.DoctorKey = T2.DoctorKey
INNER JOIN 
( SELECT DoctorKey AS PatientKey, CONCAT(FirstName,' ',LastName) AS PatientName FROM Doctor UNION 
SELECT PatientKey,CONCAT(FirstName,' ',LastName) AS PatientName FROM Patient ) T3 
ON T1.PatientMasterID = T3.PatientKey
INNER JOIN SufferingFrom T4 ON T4.TBLineNumber = T1.LineNumber
INNER JOIN TreatmentPlan T5 ON T4.LineNumber = T5.SFLineNumber
INNER JOIN IllnessTreatmentMapping T6 ON T6.TreatmentKey = T5.TreatmentKey AND T4.IllnessKey = T6.IllnessKey
INNER JOIN Illness T7 ON T7.IllnessKey = T6.IllnessKey
INNER JOIN Treatment T8 ON T8.TreatmentKey = T6.TreatmentKey
) AS SQ
);