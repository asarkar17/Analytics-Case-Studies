
# coding: utf-8

# In[3]:


# coding: utf-8
# ## Initiating required libraries

import pandas as pd
import os, codecs
import random
from faker import Faker
fake = Faker()

#Chaning Working Directory
os.chdir("C:/Users/ayans/OneDrive/Desktop/nosql-db-ayansarkar/projects/project02/postgres")


# In[4]:


# ## Generating data for table: Doctor

AreaOfMedicine =['ALLERGY & IMMUNOLOGY','ANESTHESIOLOGY','DERMATOLOGY','DIAGNOSTIC RADIOLOGY','EMERGENCY MEDICINE','FAMILY MEDICINE','INTERNAL MEDICINE','MEDICAL GENETICS','NEUROLOGY','NUCLEAR MEDICINE','OBSTETRICS AND GYNECOLOGY','OPHTHALMOLOGY','PATHOLOGY','PEDIATRICS','PHYSICAL MEDICINE & REHABILITATION','PREVENTIVE MEDICINE','PSYCHIATRY','RADIATION ONCOLOGY','SURGERY','UROLOGY']

for x in range(100):
    print("INSERT INTO Doctor (DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('"+"D"+str(x+1)+"','"+random.choice(AreaOfMedicine)+"','"+fake.email()+"','"+fake.first_name()+"','"+fake.last_name()+"','"+fake.phone_number()+"','"+fake.street_address()+"','"+fake.secondary_address()+"','"+fake.city()+"','"+fake.state()+"','"+fake.zipcode_in_state(state_abbr=None)+"');\r\n",file=open('LoadDoctor.sql', 'a+',encoding = 'latin1', errors='ignore'))


# In[6]:


# ## Generating data for table: Patient

for x in range(10000):
    print("INSERT INTO Patient (PatientKey,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('"+"P"+str(x+1)+"','"+fake.email()+"','"+fake.first_name()+"','"+fake.last_name()+"','"+fake.phone_number()+"','"+fake.street_address()+"','"+fake.secondary_address()+"','"+fake.city()+"','"+fake.state()+"','"+fake.zipcode_in_state(state_abbr=None)+"');\r\n",file=open('LoadPatient.sql', 'a+',encoding = 'latin1', errors='ignore'))


# In[25]:


# ## Generating data for table: TreatedBy

# Populating records where Doctors are themselves patients
for x in range(1,36):
    print("INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('"+"D"+str(x)+"','"+"D"+str(x+50)+"');\r\n",file=open('LoadTreatedBy_Dcotors.sql', 'a+',encoding = 'latin1', errors='ignore'))
    
# Populating records where the patients are regular patients
d = [i for i in range(1,101)]
incr = 0
for p in range(1,10001):
    print("INSERT INTO TreatedBy (DoctorKey,PatientMasterID) VALUES ('"+"D"+str(d[incr])+"','"+"P"+str(p)+"');\r\n",file=open('LoadTreatedBy.sql', 'a+',encoding = 'latin1', errors='ignore'))
    if incr <= 98:
        incr = incr + 1
    else:
        incr = 0
    
    


# In[11]:


# ## Generating data for table: Illness

Severity =['Low','High','Medium']

for x in range(1,1001):
    print("INSERT INTO Illness (Name,Severity) VALUES ('"+"I"+str(x)+"','"+random.choice(Severity)+"');\r\n",file=open('LoadIllness.sql', 'a+',encoding = 'latin1', errors='ignore'))


# In[12]:


# ## Generating data for table: Treatment

for x in range(1,751):
    print("INSERT INTO Treatment (Name) VALUES ('"+"T"+str(x)+"');\r\n",file=open('LoadTreatment.sql', 'a+',encoding = 'latin1', errors='ignore'))


# In[23]:


# ## Generating data for table: IllnessTreatmentMapping

incr = 1
for x in range(1,1001):
    print("INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES ("+str(incr)+","+str(x)+");\r\n",file=open('LoadITMapping.sql', 'a+',encoding = 'latin1', errors='ignore'))
    if incr <= 249:
        incr = incr + 1
    elif incr >= 250 and  incr <= 449:
        incr = incr + 1
    elif incr >= 500 and  incr <= 749:
        incr = incr + 1  
    else:
        incr = 1


# In[26]:


## Generating data for table: SufferingFrom

incr = 1
for x in range(1,10036):
    print("INSERT INTO SufferingFrom (TBLineNumber,IllnessKey) VALUES ("+str(x)+","+str(incr)+");\r\n",file=open('LoadSufferingFrom.sql', 'a+',encoding = 'latin1', errors='ignore'))
    if incr <= 999:
        incr = incr + 1
    else:
        incr = 1

