INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (1,1);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (2,2);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (3,3);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (4,4);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (5,5);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (6,6);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (7,7);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (8,8);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (9,9);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (10,10);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (11,11);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (12,12);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (13,13);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (14,14);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (15,15);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (16,16);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (17,17);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (18,18);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (19,19);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (20,20);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (21,21);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (22,22);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (23,23);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (24,24);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (25,25);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (26,26);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (27,27);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (28,28);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (29,29);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (30,30);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (31,31);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (32,32);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (33,33);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (34,34);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (35,35);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (36,36);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (37,37);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (38,38);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (39,39);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (40,40);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (41,41);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (42,42);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (43,43);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (44,44);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (45,45);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (46,46);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (47,47);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (48,48);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (49,49);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (50,50);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (51,51);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (52,52);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (53,53);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (54,54);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (55,55);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (56,56);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (57,57);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (58,58);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (59,59);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (60,60);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (61,61);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (62,62);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (63,63);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (64,64);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (65,65);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (66,66);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (67,67);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (68,68);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (69,69);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (70,70);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (71,71);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (72,72);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (73,73);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (74,74);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (75,75);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (76,76);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (77,77);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (78,78);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (79,79);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (80,80);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (81,81);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (82,82);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (83,83);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (84,84);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (85,85);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (86,86);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (87,87);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (88,88);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (89,89);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (90,90);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (91,91);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (92,92);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (93,93);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (94,94);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (95,95);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (96,96);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (97,97);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (98,98);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (99,99);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (100,100);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (101,101);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (102,102);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (103,103);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (104,104);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (105,105);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (106,106);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (107,107);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (108,108);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (109,109);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (110,110);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (111,111);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (112,112);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (113,113);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (114,114);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (115,115);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (116,116);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (117,117);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (118,118);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (119,119);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (120,120);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (121,121);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (122,122);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (123,123);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (124,124);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (125,125);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (126,126);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (127,127);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (128,128);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (129,129);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (130,130);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (131,131);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (132,132);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (133,133);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (134,134);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (135,135);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (136,136);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (137,137);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (138,138);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (139,139);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (140,140);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (141,141);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (142,142);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (143,143);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (144,144);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (145,145);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (146,146);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (147,147);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (148,148);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (149,149);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (150,150);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (151,151);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (152,152);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (153,153);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (154,154);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (155,155);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (156,156);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (157,157);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (158,158);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (159,159);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (160,160);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (161,161);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (162,162);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (163,163);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (164,164);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (165,165);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (166,166);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (167,167);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (168,168);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (169,169);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (170,170);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (171,171);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (172,172);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (173,173);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (174,174);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (175,175);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (176,176);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (177,177);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (178,178);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (179,179);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (180,180);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (181,181);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (182,182);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (183,183);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (184,184);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (185,185);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (186,186);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (187,187);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (188,188);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (189,189);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (190,190);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (191,191);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (192,192);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (193,193);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (194,194);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (195,195);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (196,196);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (197,197);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (198,198);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (199,199);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (200,200);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (201,201);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (202,202);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (203,203);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (204,204);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (205,205);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (206,206);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (207,207);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (208,208);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (209,209);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (210,210);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (211,211);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (212,212);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (213,213);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (214,214);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (215,215);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (216,216);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (217,217);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (218,218);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (219,219);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (220,220);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (221,221);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (222,222);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (223,223);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (224,224);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (225,225);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (226,226);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (227,227);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (228,228);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (229,229);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (230,230);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (231,231);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (232,232);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (233,233);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (234,234);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (235,235);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (236,236);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (237,237);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (238,238);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (239,239);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (240,240);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (241,241);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (242,242);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (243,243);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (244,244);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (245,245);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (246,246);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (247,247);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (248,248);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (249,249);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (250,250);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (251,251);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (252,252);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (253,253);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (254,254);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (255,255);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (256,256);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (257,257);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (258,258);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (259,259);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (260,260);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (261,261);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (262,262);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (263,263);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (264,264);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (265,265);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (266,266);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (267,267);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (268,268);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (269,269);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (270,270);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (271,271);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (272,272);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (273,273);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (274,274);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (275,275);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (276,276);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (277,277);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (278,278);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (279,279);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (280,280);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (281,281);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (282,282);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (283,283);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (284,284);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (285,285);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (286,286);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (287,287);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (288,288);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (289,289);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (290,290);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (291,291);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (292,292);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (293,293);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (294,294);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (295,295);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (296,296);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (297,297);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (298,298);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (299,299);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (300,300);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (301,301);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (302,302);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (303,303);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (304,304);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (305,305);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (306,306);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (307,307);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (308,308);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (309,309);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (310,310);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (311,311);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (312,312);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (313,313);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (314,314);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (315,315);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (316,316);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (317,317);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (318,318);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (319,319);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (320,320);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (321,321);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (322,322);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (323,323);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (324,324);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (325,325);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (326,326);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (327,327);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (328,328);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (329,329);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (330,330);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (331,331);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (332,332);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (333,333);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (334,334);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (335,335);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (336,336);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (337,337);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (338,338);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (339,339);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (340,340);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (341,341);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (342,342);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (343,343);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (344,344);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (345,345);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (346,346);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (347,347);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (348,348);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (349,349);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (350,350);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (351,351);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (352,352);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (353,353);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (354,354);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (355,355);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (356,356);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (357,357);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (358,358);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (359,359);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (360,360);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (361,361);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (362,362);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (363,363);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (364,364);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (365,365);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (366,366);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (367,367);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (368,368);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (369,369);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (370,370);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (371,371);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (372,372);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (373,373);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (374,374);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (375,375);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (376,376);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (377,377);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (378,378);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (379,379);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (380,380);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (381,381);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (382,382);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (383,383);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (384,384);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (385,385);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (386,386);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (387,387);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (388,388);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (389,389);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (390,390);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (391,391);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (392,392);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (393,393);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (394,394);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (395,395);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (396,396);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (397,397);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (398,398);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (399,399);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (400,400);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (401,401);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (402,402);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (403,403);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (404,404);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (405,405);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (406,406);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (407,407);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (408,408);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (409,409);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (410,410);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (411,411);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (412,412);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (413,413);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (414,414);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (415,415);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (416,416);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (417,417);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (418,418);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (419,419);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (420,420);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (421,421);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (422,422);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (423,423);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (424,424);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (425,425);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (426,426);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (427,427);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (428,428);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (429,429);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (430,430);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (431,431);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (432,432);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (433,433);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (434,434);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (435,435);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (436,436);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (437,437);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (438,438);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (439,439);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (440,440);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (441,441);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (442,442);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (443,443);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (444,444);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (445,445);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (446,446);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (447,447);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (448,448);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (449,449);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (450,450);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (1,451);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (2,452);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (3,453);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (4,454);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (5,455);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (6,456);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (7,457);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (8,458);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (9,459);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (10,460);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (11,461);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (12,462);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (13,463);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (14,464);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (15,465);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (16,466);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (17,467);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (18,468);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (19,469);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (20,470);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (21,471);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (22,472);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (23,473);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (24,474);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (25,475);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (26,476);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (27,477);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (28,478);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (29,479);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (30,480);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (31,481);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (32,482);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (33,483);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (34,484);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (35,485);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (36,486);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (37,487);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (38,488);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (39,489);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (40,490);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (41,491);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (42,492);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (43,493);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (44,494);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (45,495);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (46,496);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (47,497);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (48,498);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (49,499);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (50,500);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (51,501);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (52,502);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (53,503);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (54,504);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (55,505);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (56,506);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (57,507);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (58,508);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (59,509);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (60,510);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (61,511);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (62,512);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (63,513);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (64,514);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (65,515);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (66,516);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (67,517);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (68,518);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (69,519);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (70,520);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (71,521);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (72,522);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (73,523);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (74,524);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (75,525);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (76,526);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (77,527);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (78,528);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (79,529);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (80,530);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (81,531);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (82,532);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (83,533);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (84,534);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (85,535);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (86,536);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (87,537);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (88,538);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (89,539);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (90,540);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (91,541);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (92,542);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (93,543);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (94,544);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (95,545);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (96,546);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (97,547);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (98,548);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (99,549);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (100,550);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (101,551);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (102,552);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (103,553);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (104,554);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (105,555);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (106,556);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (107,557);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (108,558);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (109,559);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (110,560);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (111,561);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (112,562);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (113,563);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (114,564);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (115,565);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (116,566);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (117,567);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (118,568);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (119,569);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (120,570);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (121,571);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (122,572);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (123,573);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (124,574);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (125,575);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (126,576);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (127,577);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (128,578);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (129,579);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (130,580);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (131,581);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (132,582);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (133,583);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (134,584);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (135,585);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (136,586);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (137,587);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (138,588);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (139,589);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (140,590);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (141,591);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (142,592);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (143,593);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (144,594);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (145,595);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (146,596);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (147,597);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (148,598);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (149,599);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (150,600);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (151,601);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (152,602);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (153,603);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (154,604);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (155,605);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (156,606);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (157,607);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (158,608);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (159,609);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (160,610);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (161,611);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (162,612);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (163,613);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (164,614);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (165,615);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (166,616);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (167,617);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (168,618);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (169,619);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (170,620);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (171,621);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (172,622);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (173,623);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (174,624);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (175,625);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (176,626);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (177,627);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (178,628);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (179,629);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (180,630);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (181,631);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (182,632);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (183,633);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (184,634);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (185,635);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (186,636);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (187,637);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (188,638);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (189,639);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (190,640);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (191,641);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (192,642);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (193,643);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (194,644);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (195,645);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (196,646);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (197,647);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (198,648);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (199,649);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (200,650);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (201,651);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (202,652);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (203,653);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (204,654);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (205,655);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (206,656);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (207,657);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (208,658);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (209,659);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (210,660);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (211,661);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (212,662);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (213,663);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (214,664);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (215,665);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (216,666);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (217,667);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (218,668);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (219,669);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (220,670);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (221,671);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (222,672);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (223,673);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (224,674);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (225,675);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (226,676);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (227,677);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (228,678);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (229,679);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (230,680);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (231,681);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (232,682);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (233,683);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (234,684);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (235,685);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (236,686);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (237,687);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (238,688);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (239,689);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (240,690);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (241,691);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (242,692);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (243,693);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (244,694);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (245,695);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (246,696);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (247,697);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (248,698);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (249,699);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (250,700);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (251,701);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (252,702);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (253,703);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (254,704);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (255,705);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (256,706);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (257,707);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (258,708);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (259,709);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (260,710);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (261,711);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (262,712);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (263,713);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (264,714);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (265,715);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (266,716);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (267,717);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (268,718);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (269,719);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (270,720);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (271,721);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (272,722);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (273,723);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (274,724);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (275,725);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (276,726);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (277,727);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (278,728);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (279,729);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (280,730);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (281,731);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (282,732);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (283,733);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (284,734);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (285,735);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (286,736);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (287,737);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (288,738);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (289,739);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (290,740);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (291,741);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (292,742);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (293,743);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (294,744);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (295,745);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (296,746);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (297,747);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (298,748);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (299,749);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (300,750);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (301,751);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (302,752);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (303,753);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (304,754);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (305,755);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (306,756);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (307,757);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (308,758);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (309,759);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (310,760);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (311,761);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (312,762);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (313,763);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (314,764);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (315,765);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (316,766);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (317,767);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (318,768);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (319,769);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (320,770);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (321,771);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (322,772);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (323,773);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (324,774);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (325,775);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (326,776);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (327,777);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (328,778);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (329,779);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (330,780);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (331,781);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (332,782);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (333,783);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (334,784);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (335,785);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (336,786);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (337,787);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (338,788);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (339,789);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (340,790);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (341,791);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (342,792);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (343,793);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (344,794);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (345,795);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (346,796);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (347,797);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (348,798);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (349,799);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (350,800);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (351,801);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (352,802);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (353,803);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (354,804);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (355,805);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (356,806);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (357,807);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (358,808);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (359,809);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (360,810);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (361,811);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (362,812);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (363,813);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (364,814);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (365,815);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (366,816);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (367,817);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (368,818);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (369,819);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (370,820);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (371,821);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (372,822);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (373,823);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (374,824);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (375,825);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (376,826);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (377,827);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (378,828);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (379,829);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (380,830);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (381,831);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (382,832);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (383,833);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (384,834);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (385,835);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (386,836);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (387,837);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (388,838);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (389,839);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (390,840);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (391,841);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (392,842);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (393,843);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (394,844);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (395,845);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (396,846);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (397,847);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (398,848);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (399,849);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (400,850);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (401,851);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (402,852);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (403,853);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (404,854);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (405,855);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (406,856);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (407,857);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (408,858);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (409,859);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (410,860);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (411,861);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (412,862);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (413,863);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (414,864);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (415,865);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (416,866);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (417,867);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (418,868);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (419,869);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (420,870);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (421,871);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (422,872);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (423,873);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (424,874);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (425,875);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (426,876);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (427,877);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (428,878);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (429,879);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (430,880);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (431,881);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (432,882);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (433,883);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (434,884);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (435,885);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (436,886);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (437,887);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (438,888);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (439,889);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (440,890);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (441,891);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (442,892);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (443,893);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (444,894);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (445,895);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (446,896);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (447,897);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (448,898);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (449,899);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (450,900);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (1,901);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (2,902);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (3,903);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (4,904);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (5,905);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (6,906);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (7,907);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (8,908);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (9,909);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (10,910);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (11,911);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (12,912);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (13,913);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (14,914);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (15,915);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (16,916);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (17,917);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (18,918);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (19,919);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (20,920);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (21,921);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (22,922);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (23,923);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (24,924);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (25,925);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (26,926);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (27,927);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (28,928);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (29,929);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (30,930);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (31,931);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (32,932);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (33,933);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (34,934);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (35,935);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (36,936);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (37,937);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (38,938);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (39,939);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (40,940);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (41,941);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (42,942);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (43,943);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (44,944);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (45,945);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (46,946);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (47,947);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (48,948);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (49,949);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (50,950);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (51,951);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (52,952);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (53,953);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (54,954);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (55,955);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (56,956);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (57,957);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (58,958);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (59,959);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (60,960);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (61,961);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (62,962);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (63,963);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (64,964);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (65,965);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (66,966);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (67,967);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (68,968);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (69,969);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (70,970);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (71,971);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (72,972);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (73,973);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (74,974);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (75,975);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (76,976);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (77,977);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (78,978);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (79,979);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (80,980);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (81,981);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (82,982);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (83,983);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (84,984);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (85,985);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (86,986);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (87,987);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (88,988);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (89,989);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (90,990);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (91,991);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (92,992);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (93,993);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (94,994);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (95,995);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (96,996);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (97,997);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (98,998);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (99,999);

INSERT INTO IllnessTreatmentMapping (TreatmentKey,IllnessKey) VALUES (100,1000);

