
# coding: utf-8

# In[1]:


# coding: utf-8
# ## Initiating required libraries

import pandas as pd
import os, codecs
import random
from faker import Faker
fake = Faker()

#Chaning Working Directory
os.chdir("C:/Users/ayans/OneDrive/Desktop/nosql-db-ayansarkar/projects/project02/neo4j")


# In[18]:


# ## Generating data for table: Doctor

AreaOfMedicine =['ALLERGY & IMMUNOLOGY','ANESTHESIOLOGY','DERMATOLOGY','DIAGNOSTIC RADIOLOGY','EMERGENCY MEDICINE','FAMILY MEDICINE','INTERNAL MEDICINE','MEDICAL GENETICS','NEUROLOGY','NUCLEAR MEDICINE','OBSTETRICS AND GYNECOLOGY','OPHTHALMOLOGY','PATHOLOGY','PEDIATRICS','PHYSICAL MEDICINE & REHABILITATION','PREVENTIVE MEDICINE','PSYCHIATRY','RADIATION ONCOLOGY','SURGERY','UROLOGY']

print("DoctorKey,AreaOfMedicine,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip",file=open('LoadDoctor.csv', 'a+',encoding = 'latin1', errors='ignore'))
for x in range(100):
    print("D"+str(x+1)+","+random.choice(AreaOfMedicine)+","+fake.email()+","+fake.first_name()+","+fake.last_name()+","+fake.phone_number()+","+fake.street_address()+","+fake.secondary_address()+","+fake.city()+","+fake.state()+","+fake.zipcode_in_state(state_abbr=None),file=open('LoadDoctor.csv', 'a+',encoding = 'latin1', errors='ignore'))
 


# In[4]:


# ## Generating data for table: Patient

print("PatientKey,EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip",file=open('LoadPatient.csv', 'a+',encoding = 'latin1', errors='ignore'))
for x in range(10000):
    print("P"+str(x+1)+","+fake.email()+","+fake.first_name()+","+fake.last_name()+","+fake.phone_number()+","+fake.street_address()+","+fake.secondary_address()+","+fake.city()+","+fake.state()+","+fake.zipcode_in_state(state_abbr=None),file=open('LoadPatient.csv', 'a+',encoding = 'latin1', errors='ignore'))


# In[19]:


# ## Generating data for table: TreatedBy

# Populating records where Doctors are themselves patients

print("DoctorKey,PatientMasterID",file=open('LoadDocsTreatingDocs.csv', 'a+',encoding = 'latin1', errors='ignore'))
for x in range(1,36):
    print("D"+str(x)+","+"D"+str(x+50),file=open('LoadDocsTreatingDocs.csv', 'a+',encoding = 'latin1', errors='ignore'))
    
# Populating records where the patients are regular patients

print("DoctorKey,PatientMasterID",file=open('LoadTreatedBy.csv', 'a+',encoding = 'latin1', errors='ignore'))
d = [i for i in range(1,101)]
incr = 0
for p in range(1,10001):
    print("D"+str(d[incr])+","+"P"+str(p),file=open('LoadTreatedBy.csv', 'a+',encoding = 'latin1', errors='ignore'))
    if incr <= 98:
        incr = incr + 1
    else:
        incr = 0
    
    


# In[5]:


# ## Generating data for table: Illness

Severity =['Low','High','Medium']

print("IllnessKey,Name,Severity",file=open('LoadIllness.csv', 'a+',encoding = 'latin1', errors='ignore'))
for x in range(1,1001):
    print(str(x)+","+"I"+str(x)+","+random.choice(Severity),file=open('LoadIllness.csv', 'a+',encoding = 'latin1', errors='ignore'))


# In[6]:


# ## Generating data for table: Treatment

print("TreatmentKey,Name",file=open('LoadTreatment.csv', 'a+',encoding = 'latin1', errors='ignore'))
for x in range(1,751):
    print(str(x)+","+"T"+str(x),file=open('LoadTreatment.csv', 'a+',encoding = 'latin1', errors='ignore'))


# In[11]:


# ## Generating data for table: IllnessTreatmentMapping

print("TreatmentKey,IllnessKey",file=open('LoadITMapping.csv', 'a+',encoding = 'latin1', errors='ignore'))
    
incr = 1
for x in range(1,1001):
    print(str(incr)+","+str(x),file=open('LoadITMapping.csv', 'a+',encoding = 'latin1', errors='ignore'))
    if incr <= 249:
        incr = incr + 1
    elif incr >= 250 and  incr <= 449:
        incr = incr + 1
    elif incr >= 500 and  incr <= 749:
        incr = incr + 1  
    else:
        incr = 1


# In[20]:


## Generating data for table: SufferingFrom

print("PatientKey,IllnessKey",file=open('LoadSufferingFrom.csv', 'a+',encoding = 'latin1', errors='ignore'))
print("PatientKey,IllnessKey",file=open('LoadDocSufferingFrom.csv', 'a+',encoding = 'latin1', errors='ignore'))
   
incr = 1
for x in range(1,10036):
    if x <= 35:
        print("D"+str(x)+","+str(incr),file=open('LoadDocSufferingFrom.csv', 'a+',encoding = 'latin1', errors='ignore'))
    else:
        print("P"+str(x-35)+","+str(incr),file=open('LoadSufferingFrom.csv', 'a+',encoding = 'latin1', errors='ignore'))
    if incr <= 999:
        incr = incr + 1
    else:
        incr = 1


# In[16]:


## Generating data for table: TreatmentPlan

print("PatientKey,TreatmentKey",file=open('LoadTreatmentPlan.csv', 'a+',encoding = 'latin1', errors='ignore'))
   
incr2 = 1
for x in range(1,10036):
    if x <= 35:
        print("D"+str(x)+","+str(incr2),file=open('LoadTreatmentPlan.csv', 'a+',encoding = 'latin1', errors='ignore'))
    else:
        print("P"+str(x-35)+","+str(incr2),file=open('LoadTreatmentPlan.csv', 'a+',encoding = 'latin1', errors='ignore'))
    if incr2 <= 749:
        incr2 = incr2 + 1
    else:
        incr2 = 1        

