/***
Collection Create Statement & server side Functions to insert data into collections 
***/

db.Users.insert({
  _id:0,
  EmailAddress: "salinasdenise@johns.com",
  FirstName: "Julie",
  LastName: "Palmer",
  PhoneNumber: "001-560-453-1308x24053",
  AddressLine1: "N23185 Lee Isle",
  AddressLine2: "Apt. 623",
  City: "Ericaberg",
  State: "Alaska",
  Zip: "20015",
  CreatedAt: ISODate("2019-05-23")
});

insertUsers = function ( _id, EmailAddress, FirstName, LastName, PhoneNumber, AddressLine1, AddressLine2, City, State, Zip, CreatedAt) {
  db.Users.insert({
    _id:_id,
    EmailAddress: EmailAddress,
    FirstName: FirstName,
    LastName: LastName,
    PhoneNumber: PhoneNumber,
    AddressLine1: AddressLine1,
    AddressLine2: AddressLine2,
    City: City,
    State: State,
    Zip: Zip,
    CreatedAt: CreatedAt
  });
}
db.system.js.save({_id: 'insertUsers', value: insertUsers})

db.Customer.insert({
  _id: 0,
  EmailAddress: "zjoyce@yahoo.com",
  FirstName: "Amanda",
  LastName: "Howe",
  PhoneNumber: "(817)093-1993",
  AddressLine1: "08421 Emily Views",
  AddressLine2: "Apt. 391",
  City: "North Joseph",
  State: "Alabama",
  Zip: "28286",
  CreatedAt: ISODate("2019-05-23")
});

insertCustomer = function (_id, EmailAddress, FirstName, LastName, PhoneNumber, AddressLine1, AddressLine2, City, State, Zip, CreatedAt) {
  db.Customer.insert({
    _id:_id,
    EmailAddress: EmailAddress,
    FirstName: FirstName,
    LastName: LastName,
    PhoneNumber: PhoneNumber,
    AddressLine1: AddressLine1,
    AddressLine2: AddressLine2,
    City: City,
    State: State,
    Zip: Zip,
    CreatedAt: CreatedAt
  });
}
db.system.js.save({_id: 'insertCustomer', value: insertCustomer})

db.Inventory.insert({
  _id: 0,
  Name: "Dry Yeast",
  Description: "1 package (2 1/4 teaspoons) of active dry yeast",
  Quantity: "75000",
  WeightInGrams: "500",
  CreatedAt: ISODate("2019-05-23")
});

insertInventory = function (_id,Name,Description,Quantity,WeightInGrams,CreatedAt) {
  db.Inventory.insert({
    _id: _id,
    Name: Name,
    Description: Description,
    Quantity: Quantity,
    WeightInGrams: WeightInGrams,
    CreatedAt: CreatedAt
  });
}
db.system.js.save({_id: 'insertInventory', value: insertInventory})

db.Recipe.insert({
  _id: 0,
  Name: "Berry, Arugula and Prosciutto Pizza",
  Description: "This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for wa\n" +
      "rm spring or summer brunches or dinners!",
  CookingInstructions: "Not Available",
  InventoryKey: {$ref: "Inventory", _id: "0"},
  CreatedAt: ISODate("2019-05-23")
});

insertRecipe = function (_id,Name,Description,CookingInstructions,InventoryKey,CreatedAt) {
  db.Recipe.insert({
    _id: _id,
    Name: Name,
    Description: Description,
    CookingInstructions: CookingInstructions,
    InventoryKey: InventoryKey,
    CreatedAt: CreatedAt
  });
}
db.system.js.save({_id: 'insertRecipe', value: insertRecipe})

db.Orders.insert({
  _id: 0,
  UserKey: {$ref: "User", _id: "0"},
  CustKey: {$ref: "Customer", _id: "0"},
  RecipeKey: {$ref: "Recipe", _id: "0"},
  ExpectedCompletionTime: "30",
  TotalCost: "10",
  CreatedAt: ISODate("2019-05-23")
});

insertOrders = function (_id,UserKey,CustKey,RecipeKey,ExpectedCompletionTime,TotalCost,CreatedAt) {
  db.Orders.insert({
    _id: _id,
    UserKey: UserKey,
    CustKey: CustKey,
    RecipeKey: RecipeKey,
    ExpectedCompletionTime: ExpectedCompletionTime,
    TotalCost: TotalCost,
    CreatedAt: CreatedAt
  });
}
db.system.js.save({_id: 'insertOrders', value: insertOrders})

db.CustomerAwardsProgram.insert({
  _id: 0,
  CustKey: {$ref: "Customer", _id: "0"},
  AwardPoints: "10",
  CreatedAt: ISODate("2019-05-23")
});

insertCAP = function (_id,CustKey,AwardPoints,CreatedAt) {
  db.CustomerAwardsProgram.insert({
    _id: _id,
    CustKey: CustKey,
    AwardPoints: AwardPoints,
    CreatedAt: CreatedAt
  });
}
db.system.js.save({_id: 'insertCAP', value: insertCAP})

db.loadServerScripts()