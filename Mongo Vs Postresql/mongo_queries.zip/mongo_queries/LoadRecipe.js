insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(1,'Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(2,'Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(3,'Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(4,'Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(5,'Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(6,'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(7,'Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(8,'Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(9,'Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(10,'Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(11,'Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(12,'Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(13,'Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(14,'Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(15,'Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(16,'Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(17,'Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(18,'Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(19,'Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(20,'Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(21,'Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(22,'Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(23,'Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(24,'Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(25,'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(26,'Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(27,'Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(28,'Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(29,'Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(30,'Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '1'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '2'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '3'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '4'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '5'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '6'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '7'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '8'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '9'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '10'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '11'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '12'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '13'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '14'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '15'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '16'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '17'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '18'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '19'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '20'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '21'},'2019-05-23')

insertRecipe(31,'Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza','Not Avaiable',{$ref: 'Inventory', _id: '22'},'2019-05-23')

