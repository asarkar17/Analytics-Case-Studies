INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (1,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (2,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (3,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (4,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (5,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (6,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (7,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (8,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (9,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (10,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (11,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (12,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (13,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (14,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (15,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (16,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (17,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (18,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (19,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (20,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (21,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (22,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (23,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (24,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (25,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (26,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (27,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (28,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (29,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (30,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (31,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (32,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (33,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (34,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (35,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (36,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (37,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (38,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (39,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (40,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (41,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (42,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (43,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (44,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (45,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (46,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (47,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (48,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (49,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (50,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (51,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (52,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (53,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (54,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (55,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (56,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (57,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (58,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (59,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (60,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (61,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (62,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (63,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (64,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (65,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (66,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (67,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (68,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (69,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (70,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (71,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (72,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (73,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (74,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (75,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (76,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (77,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (78,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (79,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (80,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (81,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (82,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (83,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (84,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (85,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (86,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (87,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (88,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (89,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (90,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (91,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (92,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (93,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (94,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (95,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (96,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (97,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (98,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (99,10);

INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (100,10);

