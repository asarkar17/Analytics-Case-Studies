INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('zjoyce@yahoo.com','Amanda','Howe','(817)093-1993','08421 Emily Views','Apt. 391','North Joseph','Alabama','28286');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('speters@johnson-trevino.org','Randy','Contreras','001-254-637-6267','78441 Kevin Oval Apt. 466','Apt. 567','Tiffanyberg','Kansas','96744');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('delacruzchristopher@miller.com','Natalie','Rivera','(578)205-2100','86802 Kent Lodge Apt. 914','Suite 866','South Patricia','California','04058');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kevin86@newman.info','John','Cruz','9778270239','76144 Michael Loaf Suite 679','Apt. 105','Michaelmouth','Florida','29744');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ngarcia@hotmail.com','Mark','Wright','0117095571','314 Lynch Terrace Apt. 038','Suite 525','North Scottside','North Carolina','59345');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('shanson@jones.com','Ricardo','Baker','965-498-3693','822 Boone Fords','Suite 220','North Spencerstad','New Hampshire','96825');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('julie74@schneider-miller.info','Anna','Reynolds','251-264-8803','8033 Lloyd Port Suite 043','Suite 685','Blackberg','Alaska','06216');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jonesmark@walter.com','Kelsey','Yang','728-168-8488x93153','634 Jacob Valley','Apt. 750','East Michael','Oregon','46812');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('llopez@mccarthy-thomas.com','Jason','Harper','+1-612-107-5990x9028','671 John Lakes Suite 624','Suite 069','East Rebeccachester','Wisconsin','88001');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jacquelinefuller@gmail.com','Francis','Sullivan','5279083560','29624 Campbell Ranch','Suite 941','West Amyborough','Maryland','02876');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('scott21@hotmail.com','Susan','Foster','(167)439-7959','7015 Erin Crossroad','Suite 858','Angelahaven','New Mexico','68018');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('whitejessica@turner.net','Laura','Sanford','665.872.3024','2279 Jeremiah Island Apt. 655','Apt. 102','New Kayla','South Carolina','86209');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michaelwhite@gmail.com','Alexis','Lee','527.698.9141x492','4010 Anthony Mount Suite 791','Apt. 515','Phillipborough','Ohio','26074');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('renee75@gmail.com','James','Madden','(671)652-0786x53767','191 Perez Mountains Apt. 255','Suite 016','Monicafort','Tennessee','02835');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('murrayheather@mcgee.com','Sharon','Chavez','+1-758-463-7109x449','6569 Carolyn Villages','Suite 301','Armstronghaven','Kentucky','98239');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('maryrodriguez@bartlett.org','Thomas','Garcia','690.299.9110','3833 Hutchinson Rest Apt. 174','Apt. 233','Port Ronnie','California','87325');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michael46@brown.com','Emily','Sweeney','110.201.8947','07794 Ashley Passage','Suite 622','Port Rachelbury','Kansas','02493');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('melanie70@thomas-rojas.com','Bobby','Wagner','001-790-076-3477x22931','984 Serrano Pike','Apt. 782','Port Ashleytown','Illinois','25263');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tmayer@gmail.com','Colin','Hart','(559)737-2828x9023','10489 Wright Circles','Suite 441','Andradechester','Washington','57097');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('davidadams@yahoo.com','Ryan','Lee','309-426-7015x39793','461 Collins Ford Apt. 402','Suite 397','Pruittville','Kansas','58135');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('smithdaniel@rowe-khan.com','Michael','Walter','837-757-9013','4986 William Common Suite 425','Suite 266','Rossland','Texas','56603');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('aaronlara@yahoo.com','Tina','Meyer','0624498690','06531 Ramirez Pine Apt. 353','Suite 955','West Johnton','Virginia','97417');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kelliecox@gmail.com','Joshua','Chapman','3364477000','586 Boyle Extension','Suite 458','North Louisland','Illinois','19812');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lewisblake@yahoo.com','Teresa','Gonzalez','(059)556-6357','5892 Miles Row','Suite 630','Johnsonport','Arkansas','97889');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jamiemartinez@gmail.com','Carolyn','Moody','9333487895','6787 Jordan Unions','Suite 583','West Paulbury','Connecticut','97343');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('woodstimothy@hotmail.com','Matthew','Lewis','001-747-464-4217x757','3110 Claudia Parkway Suite 717','Suite 830','Samanthamouth','Vermont','03814');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dawn79@grant.com','Judith','Rogers','2919761507','40081 Michael Forge','Suite 159','Port John','Nevada','88135');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnsonalexander@yahoo.com','Julie','Farmer','(178)859-2723x20484','174 Arnold Isle','Suite 307','Dianamouth','Florida','08031');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stephaniejames@fitzgerald-watson.com','Chase','Price','+1-540-631-7635x8415','06877 Steven Mount Apt. 086','Apt. 141','Adamsburgh','Wyoming','02864');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jenkinszachary@gmail.com','Jason','Garcia','707.513.1062x0726','3167 Montgomery Rapids Suite 635','Suite 597','North Nicholasfort','Tennessee','59092');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stephanierodriguez@perez-james.info','Carrie','Love','001-257-365-3775','402 Schmitt Port Suite 116','Apt. 100','Thomasbury','Arizona','46301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('daniel15@gmail.com','George','Clark','526-991-1549','829 Carlos Vista Apt. 866','Suite 633','Markchester','Utah','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('davidyoung@gmail.com','Matthew','Ramirez','001-988-230-6546x40036','014 Peters Grove','Suite 461','Matthewfort','North Dakota','58631');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('woodjohnathan@webb.net','Allison','Freeman','216.178.6628x67128','46410 Andre Trafficway Suite 009','Suite 664','Jenniferstad','Alaska','72543');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brian06@yahoo.com','Brooke','Fuentes','(631)098-6248x94249','3966 Kristen Ford','Suite 620','Taylorhaven','Ohio','05214');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joselynch@diaz.com','Gregory','Gonzalez','(308)402-5651x4334','949 Cantrell Lights Apt. 717','Suite 044','Anthonyland','Georgia','97602');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michael17@cook-crawford.biz','Xavier','Thomas','750.879.1009x4432','38166 Allison Spurs','Apt. 762','Port Brian','Oregon','52146');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('xjones@yahoo.com','Kyle','Smith','262-307-5855x547','305 Nelson Hill','Apt. 432','Lake Tiffanytown','Utah','59120');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dennisgilbert@dean.com','Taylor','White','(591)944-9365x918','017 Jones Rue Apt. 722','Suite 230','Dylanview','Massachusetts','43158');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('goodmanandrew@gmail.com','Gregory','Wilson','962-663-2648','2780 Kimberly Meadows','Apt. 977','Ramirezberg','Wyoming','02837');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vernonlewis@gmail.com','Austin','Collins','434-861-0909x4710','164 Kimberly Plain','Suite 722','Michaelburgh','Texas','03599');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nicholassanders@davis-delgado.net','Lori','Cooper','(039)293-2283x818','4566 Brewer Ways Suite 455','Suite 833','Newtonhaven','Utah','32068');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hjacobs@hotmail.com','Mckenzie','Meyers','812-416-5013','086 Jimmy Spur Apt. 678','Suite 626','North Summershire','Oklahoma','01762');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bblevins@lopez-clark.com','Kristi','Lawson','+1-465-683-2877','2515 Anderson Square','Suite 205','New Crystalshire','New Jersey','71770');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('john64@cortez.com','Andrew','Barrett','4683935694','636 Raymond Greens','Apt. 895','Dawntown','Alaska','57111');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('martinjulie@hotmail.com','Karen','Osborne','(577)954-3649','84437 Jared Junction Apt. 963','Suite 337','Jamesstad','Tennessee','15188');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rodney85@gmail.com','John','Mitchell','432-984-6246x551','512 Judith Spring Suite 835','Apt. 551','South Alexton','Alaska','36289');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('frederickrobinson@long.com','Rachel','Cobb','402-122-2721','56037 Jessica Summit','Apt. 387','South Jimfort','Alaska','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('maria35@hotmail.com','Heidi','Solomon','160.670.3994x98430','5113 Robert Port','Apt. 929','East Sandyland','Alaska','31710');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('yprice@gmail.com','James','Davis','616.984.9548','0036 Williamson Village Suite 365','Apt. 502','Deborahshire','Iowa','24765');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('maryriggs@berry.com','Justin','Erickson','001-265-411-4964x253','4888 Gregory Overpass','Apt. 450','Cohenshire','Arkansas','90360');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('casekenneth@gmail.com','Lauren','Mccormick','075-814-2554','4263 Joseph Circles','Suite 692','Port Rhonda','Arizona','05285');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ttaylor@yahoo.com','David','Berry','(388)289-3441','4811 Victoria Row','Apt. 970','Colemanville','Tennessee','37410');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('anthony09@russo.com','Kari','Frank','001-059-180-7885','5253 Victoria Knoll Suite 060','Apt. 379','Reidmouth','Montana','49514');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('elizabeth03@young.org','Jessica','Lyons','409.517.5373','5224 Elijah Oval Apt. 881','Apt. 301','New Jessicaberg','Delaware','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('castillotamara@walker.info','Dylan','Hoffman','811-481-8504x4026','0583 Daniel Lodge Apt. 301','Apt. 690','Hughesport','Michigan','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('whitelisa@gmail.com','Kristi','Reed','(428)467-8685','337 Rice Villages Suite 970','Suite 727','Batesside','Nebraska','96897');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rangelmichael@rose.info','Jesse','Foster','844.308.1888x30509','80891 Hunter Center','Suite 864','Alyssaberg','California','31911');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('corey34@morris.com','Suzanne','Parker','968.380.8366x0324','307 Grant Roads Apt. 044','Apt. 089','Margaretshire','South Dakota','82526');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('chenrobert@gutierrez.net','Matthew','Jensen','753-408-1097x600','66317 Foster Haven','Suite 084','Port Alicia','New Jersey','62538');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('thogan@hotmail.com','Andrea','Sanders','001-382-205-7280x461','78976 Amy Shoals Apt. 607','Apt. 444','Scottville','Arizona','68047');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('eric96@oconnell.org','Ashley','Harris','001-550-514-4098','3827 Arnold Drives','Suite 009','Staceystad','Texas','99526');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lewisantonio@wiley.biz','Dana','Owens','(347)127-9120','1383 Timothy Path','Apt. 617','Daniellemouth','Vermont','99584');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wmcpherson@yahoo.com','Tamara','Mccarthy','018.931.1893','149 Logan Branch Apt. 935','Suite 315','Nicholeland','Tennessee','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ohawkins@gmail.com','Amanda','Flores','(871)060-0129x18811','81144 Sanchez Islands','Suite 436','New Sean','Rhode Island','87916');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ttrujillo@yahoo.com','Jose','Griffin','885-395-8743x6513','5902 David Port','Suite 523','Port Kimport','Hawaii','33615');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('carl62@liu-flores.net','Julia','Gonzales','(066)666-3257','12577 Kennedy Mountain','Apt. 795','Jennifershire','Washington','96802');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cory74@myers-cummings.biz','Stephanie','Mckinney','(157)376-7246','366 William Inlet Apt. 583','Suite 137','West Ericafort','Virginia','25958');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hojerry@yahoo.com','Mackenzie','Hernandez','118-711-3800x701','7591 Larry Mountains Suite 553','Suite 724','Davenportland','Kentucky','97644');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tchen@murphy.com','Reginald','Brooks','+1-659-223-3164x007','08228 Morales Coves','Apt. 974','Thomaston','North Carolina','08555');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('thomashenry@hensley.info','William','Bell','(944)690-6992x667','58792 Heather Creek','Apt. 108','South Davidfurt','Rhode Island','29481');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('andrew21@reid.net','Matthew','Holt','888-097-1083','295 Samantha Points','Apt. 300','Carolynport','Oregon','02130');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('emichael@lamb.info','Kyle','Shannon','001-242-268-3592x4542','6836 Richard Pike Apt. 734','Apt. 588','Moranmouth','Mississippi','80372');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rgonzalez@martinez.biz','Victor','Singleton','001-502-763-3418x30920','13221 Martin Meadows','Suite 967','Richardside','Louisiana','59196');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jacksonkayla@gmail.com','Mark','Rodriguez','871-101-4098x327','3472 Gamble Corners','Suite 701','East Loristad','Michigan','45423');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('xramos@gmail.com','Alyssa','Garcia','(827)341-0575x389','5365 Becker Rest Apt. 789','Apt. 351','Port Markshire','Wisconsin','59574');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('awebb@smith.com','Stephen','Nash','+1-498-407-5147x2762','64740 Farmer Row Apt. 258','Suite 315','East John','Ohio','06365');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cooperjason@hotmail.com','Ronald','Guzman','782.254.8143x761','9015 Wang Place','Suite 713','Michaelburgh','New York','20011');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jennifer83@yahoo.com','Teresa','Vaughn','001-612-419-1826x62564','76467 John Parkway Apt. 054','Suite 039','North Scottview','New Mexico','96766');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ldeleon@yahoo.com','Jessica','Cortez','2958816040','963 Scott Path Suite 517','Apt. 357','Myersfurt','New York','45535');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mayoruth@ford.com','Kayla','Shaw','(290)109-3356','7817 Kayla Pike Suite 096','Apt. 700','Millermouth','Wisconsin','73009');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tracy04@mcbride.com','Karen','Pena','811.800.7162x805','851 Gibson Fork Suite 559','Apt. 196','East Jeffreyton','Kansas','97107');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kellerlauren@yahoo.com','Rhonda','Ware','(832)514-8116x95034','9189 Reid Mountain','Apt. 969','North Samuel','Montana','59434');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lauren75@hotmail.com','Joseph','Harvey','039-582-6013x022','835 Scott Turnpike','Apt. 419','South Juan','Arkansas','67784');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hooverjoseph@davis.org','Michael','Lawrence','872-356-5955','118 Richard Views Suite 723','Apt. 031','Parkerland','Washington','02059');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kevindunn@brooks.info','Christopher','Payne','001-485-128-3736x7361','424 Graves Keys Apt. 288','Suite 908','New Jennifer','Tennessee','25887');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('egutierrez@hotmail.com','Adam','Paul','001-670-992-1983','80996 Emily Turnpike','Suite 474','North Tracy','Virginia','19703');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ginarobinson@patel.net','Laura','Hopkins','(966)193-5968x396','0531 Hudson Views','Suite 381','Vargasberg','Nebraska','99054');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vjones@gmail.com','Sharon','Smith','001-449-637-4825x01907','34207 Mason Loaf Suite 959','Apt. 871','South Spencer','New Jersey','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('daniel21@gmail.com','Gary','George','+1-981-031-7545x8885','4736 Robinson Lock Suite 430','Apt. 399','North Vanessastad','Kentucky','06019');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mperez@dixon-chambers.biz','Clayton','Lopez','001-391-942-2520','08259 Scott Prairie Suite 600','Suite 469','West Michaelstad','Texas','63275');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('james20@hotmail.com','Michael','Jones','9678977309','24313 Kathleen Mission Apt. 000','Suite 634','Lake Tracey','Connecticut','48189');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('frose@gmail.com','Cynthia','Lopez','0867462683','79846 Goodwin Forest','Suite 388','Juarezmouth','Virginia','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gregg70@yahoo.com','Maria','Luna','(759)753-5284x19282','5432 Timothy Pines','Apt. 516','Angelamouth','Rhode Island','05252');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('megan64@yahoo.com','Karen','Roberts','663.743.2779','70333 Michael Meadows','Suite 803','Piercefurt','Alabama','05098');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ylutz@edwards.net','David','Trujillo','(145)045-4711x28506','051 Navarro Viaduct Suite 915','Suite 944','West Gregorymouth','Idaho','93469');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kathrynmorales@osborn.com','Jessica','Harris','(615)828-9357','1493 Vanessa Motorway','Suite 685','Lake Masonchester','Texas','03290');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kellirivera@yahoo.com','Christian','Spencer','001-926-901-6103','011 Rivera Crest Apt. 571','Apt. 003','North Tammyhaven','Alabama','56005');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brownjeremy@yahoo.com','Jacob','Powers','651.131.0504x4725','40703 Marc Point','Suite 498','Priscillaton','Wyoming','98607');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ubennett@hotmail.com','Tammie','Martin','563-545-1491x38728','172 Lee Ville','Suite 288','New Dustinberg','Oklahoma','63104');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('julie14@avila.biz','Jesus','Ramirez','836.057.1408x86253','1538 Mitchell Land Suite 657','Suite 392','New Jennifer','North Carolina','34331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nancyjohnson@gmail.com','Sean','Bonilla','+1-080-284-7919x3283','9886 Shaw Turnpike Suite 015','Suite 868','West Stacy','Nevada','59385');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jgarza@hotmail.com','Russell','Sherman','+1-809-056-8083','37402 Ruiz Ville Suite 058','Suite 071','Lake Bettyberg','Oklahoma','50128');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jboyer@hotmail.com','Theresa','Lewis','(062)013-7861','36140 Jacobs Landing Apt. 299','Suite 783','Hallstad','Massachusetts','97090');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mariewilliams@yahoo.com','Teresa','Barron','225-915-0593','417 Hahn Rapid Suite 043','Apt. 171','Port Alyssahaven','Alaska','89125');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joyce09@hotmail.com','Brian','Terry','460.975.9670x03205','83365 Alexander Fork','Suite 282','South Jean','Kansas','82466');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('victoriajohnson@mitchell-harrington.info','Antonio','Eaton','1884019710','4709 Brown Creek','Suite 709','South Anthony','California','02137');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jason05@hotmail.com','Mark','May','(908)217-0566','0952 Krueger Plains','Apt. 993','Briannaville','Nevada','82010');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('benjamin00@yahoo.com','John','Estrada','970.842.3370x654','0983 Campbell Row','Suite 898','Johnsonshire','Montana','48024');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('martinezstephen@riddle.com','Justin','Cox','(146)350-4312x30866','8574 Judy Springs','Apt. 784','Cooperbury','Hawaii','34480');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rogerssherry@hotmail.com','Patrick','Clayton','001-372-105-8667','24292 Joan Plaza','Suite 083','Lake Andreton','Colorado','29936');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('garcianicole@johnson.net','Megan','Riley','5610510953','64267 Barbara Manors','Suite 113','Feliciahaven','Tennessee','99930');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('parkerfrank@gmail.com','Belinda','Pierce','9051431555','5717 Moore River','Suite 252','West Nicholaschester','Georgia','92239');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('katherinewebb@velez.com','Mary','Wheeler','(498)677-6506','822 Geoffrey Ports Suite 183','Suite 961','New Angela','Alaska','70716');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lutzsharon@gmail.com','Kurt','Watts','024.311.7024','262 Shannon Isle Apt. 552','Apt. 473','Mccluretown','Georgia','36056');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('warnertracey@gmail.com','Michael','Mendoza','(205)755-8037x77660','2587 Martin Lakes Suite 322','Suite 323','Ericberg','Iowa','73098');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('karenshah@gonzales-sutton.net','Troy','Mcbride','+1-665-235-8522x58172','880 Alex Junctions Suite 355','Suite 058','West Melissa','North Carolina','07486');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('urodgers@hotmail.com','Danielle','Durham','(748)317-5510','659 Lisa Roads','Apt. 210','South Kaylafurt','Vermont','73059');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('colinwatson@hotmail.com','Steven','Rose','355-689-0289x313','04207 Eric Crossroad Apt. 170','Apt. 531','Port Brianabury','Tennessee','38166');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kellydudley@hotmail.com','Shawn','Daniels','001-940-754-6648x9435','3801 Rebecca Square Suite 986','Suite 097','Monicatown','Kentucky','19838');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('reneebuck@yahoo.com','Eric','Paul','(074)696-6239x4586','8130 Veronica Road','Apt. 356','North Brianside','Alaska','29020');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('matthew72@myers-pierce.com','Jon','Dominguez','204-852-5755x29886','96557 Gillespie Center Suite 403','Apt. 968','Christopherport','Kentucky','96812');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnsonjorge@harrington-hall.biz','Nicole','Leblanc','233-779-0346','8314 Tucker Gateway','Apt. 572','Odomstad','South Carolina','61367');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('yvonne39@franklin.com','Lori','Mahoney','+1-529-123-8598x903','7807 Larry Springs','Suite 534','West Ryan','Utah','39378');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ryangibson@hotmail.com','Vanessa','Reynolds','001-697-854-7381x5068','6052 Freeman Crest','Suite 988','Mathewshire','Louisiana','57022');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lchang@gmail.com','Bill','Thomas','(762)413-9760x977','345 Richard Walk','Suite 106','West Dustin','Nebraska','60669');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('scottkevin@yahoo.com','Alan','Wilcox','683-052-8228','355 Michael Lock','Apt. 891','East Patrick','Utah','02930');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lramos@gmail.com','Denise','Simpson','(438)098-4059x4573','3325 Rush Wall','Apt. 116','Tammyburgh','New York','73152');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wardkristina@davis.info','Margaret','Martinez','173.989.4003x17356','55146 Daniels Passage Apt. 279','Apt. 571','East Lindseyhaven','Indiana','81335');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('crystal28@yahoo.com','David','Cook','(007)432-1706','3484 Hernandez Meadow Suite 643','Suite 850','Lake Evan','Iowa','02444');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ttyler@duffy.info','Jennifer','Collins','(050)264-7055x97679','69174 Heather Shoals','Suite 106','Port Joseph','Michigan','96857');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ashleybrown@gibbs-murphy.com','Daniel','Mcdonald','170-918-3603x9537','16357 Williams Freeway Suite 196','Apt. 877','Lake Kaylaville','Utah','82400');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('williamsapril@gmail.com','Robert','Fuller','+1-904-417-7124x18067','176 Nancy Underpass Suite 638','Suite 322','Amberberg','Georgia','82038');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('destiny29@weber.com','Julia','Sparks','+1-156-619-4930x4108','764 Cruz Extensions Suite 759','Apt. 398','Carrollfort','Louisiana','61861');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('samuelwilliams@smith.com','Richard','Palmer','933.629.5270','886 Tanya Row','Apt. 044','Lake Paulside','Kentucky','58166');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vdawson@yahoo.com','Aaron','Jackson','470.753.9611x8764','383 Jason Points Suite 722','Apt. 323','Caitlinmouth','Colorado','97239');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sandra08@hotmail.com','Vanessa','Oconnell','079-881-5455','126 Fields Motorway','Suite 633','Lake Shannon','Ohio','15261');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ambershaw@robinson.com','Steven','Vasquez','901.797.7762x535','716 Foster Alley Apt. 675','Suite 158','North Katherine','Vermont','68059');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stephen74@yahoo.com','Andrew','Barrett','(660)903-4224x2757','49786 Steve Crossing Apt. 187','Apt. 981','Lucasfort','Georgia','83555');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mitchellwilliamson@hotmail.com','Benjamin','Gregory','(113)284-5548x06364','933 Marshall Highway','Apt. 774','Lindamouth','Pennsylvania','08218');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mollycamacho@garcia.com','Thomas','Anderson','8717349814','21650 Phillip Extensions Suite 179','Suite 272','Lake Amy','Illinois','80115');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fmoore@hotmail.com','Lauren','Thomas','(423)875-5688x65536','70004 Vicki Lights','Suite 680','New Robertborough','Tennessee','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnsjesse@grimes-flores.com','Tammy','Thompson','001-033-983-2818x343','3341 Russell Spring','Apt. 504','Lake Bryceside','Ohio','96860');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('davidoliver@hotmail.com','Cynthia','Fitzpatrick','321-286-1738x131','56394 Harrison Tunnel Suite 467','Apt. 823','West Sara','Arkansas','60537');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ashleyanderson@yahoo.com','Renee','Torres','001-862-700-2391x9871','429 Donna Villages','Apt. 296','Raymondberg','Virginia','53316');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('maureen85@sutton.info','Charles','Ray','+1-527-899-8214x196','27287 Kevin Heights Apt. 801','Apt. 495','Port Todd','Illinois','46245');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christophermunoz@wright.com','Charles','Knox','001-671-166-4663x672','9931 Brown Extensions','Suite 791','Shelbyborough','Pennsylvania','73011');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('angela23@yahoo.com','Michael','White','(742)440-7940x55854','7692 Golden Circles','Apt. 318','Marciaton','Alabama','81598');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('juliegallegos@jones-morales.biz','William','Beck','001-232-268-7603x8482','67313 Patricia Estate Apt. 148','Suite 142','South Joshuaburgh','South Carolina','38756');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('linda99@bell.biz','Joseph','Morris','991.754.5360','734 Kim Well Suite 053','Apt. 434','New Maria','New Jersey','98449');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jeremymartinez@gmail.com','William','Allen','170-758-4871','4404 Rodriguez Groves','Suite 748','Alexandrafort','New Mexico','56433');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mmcdaniel@hotmail.com','Veronica','Sanchez','731-596-6939x24065','406 Tammy Squares Apt. 065','Suite 483','Lake Mary','Nebraska','39754');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brownmichael@weaver-velasquez.biz','Megan','Blankenship','737.560.0992x74821','093 Brooks Villages Suite 114','Suite 674','Nicoleberg','Arizona','18087');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lonnie82@gmail.com','Brian','King','+1-193-968-3780x276','7605 Timothy Common Suite 897','Suite 536','West Calvin','North Carolina','61165');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('linda24@hotmail.com','Anita','Becker','001-374-371-3858','324 Danielle Fall','Apt. 854','East Gloria','Hawaii','98416');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joseph20@curtis.com','Carlos','Rodriguez','512-117-7543','92021 Cobb Place Apt. 948','Apt. 635','West Timothy','Pennsylvania','89671');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('robertdavid@gmail.com','Megan','Hunt','117.129.4629x0972','61986 Ayala Mill','Suite 817','Hopkinsfort','Illinois','85532');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('heidi18@glass.com','Dan','Lewis','553.786.9398','416 Abbott Mountain Apt. 482','Suite 799','North Charles','Michigan','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('laura89@gmail.com','Ashley','Smith','(169)292-4704x26974','68801 Powell Track Suite 897','Suite 487','Fowlerchester','Michigan','55149');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christophersimpson@yahoo.com','Angela','Russell','(209)824-8623x532','6285 Nicholas Loaf','Suite 872','Karafurt','Tennessee','86477');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('heather98@hotmail.com','Stephanie','Turner','336.777.4280x15273','4806 Kimberly Vista Suite 687','Suite 596','East Kerriton','Delaware','41504');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stonejo@nicholson.biz','Ashley','Hudson','9777235621','54533 Rodriguez Rapids Suite 839','Suite 086','New Shelbymouth','Wisconsin','05109');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('garciajennifer@yahoo.com','Elizabeth','Alvarez','379-314-8845x895','17078 Haney Mountain','Suite 981','Taylorfurt','Kentucky','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dreese@hotmail.com','Mary','Brooks','991.544.9593x25390','703 Baker Route','Suite 353','Cooperstad','North Dakota','92044');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('daniel82@douglas.com','Kenneth','Hart','836-478-7063x7302','541 Jonathan Ports Suite 534','Apt. 377','Lake Jessicaside','Nebraska','18053');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('laurenmiller@wheeler-salas.biz','Michael','Morrison','+1-542-307-1087x57923','822 Daniel Forks Apt. 977','Suite 247','Howardport','Connecticut','27888');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('barbara82@yahoo.com','Sarah','Thomas','931.451.9151x04519','158 Wells Fall Apt. 100','Apt. 678','Kelseymouth','Michigan','98790');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('meyertimothy@yahoo.com','Robert','Allen','+1-601-969-2042x5630','92690 Douglas Shore','Suite 717','Murraymouth','Oregon','05293');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('calderonbeverly@gmail.com','Christina','Robinson','(987)020-7172x460','669 Garcia Throughway Apt. 764','Apt. 078','West Shannonside','Arizona','72194');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('andreacampbell@gmail.com','Alison','Olson','+1-389-293-8809','9974 Miller Hill Suite 960','Suite 111','Hallton','Montana','29368');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gordonnancy@chapman.info','Mark','Esparza','587-445-2863','6052 Fisher Pass','Suite 060','Hernandezfurt','New Jersey','02921');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('alexispeterson@green.com','William','Quinn','382-818-7204x6971','8928 Todd Fields Suite 334','Apt. 198','New Sueberg','North Carolina','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kjohnson@meyer.com','Patrick','Young','493.886.9958x511','45424 Caleb Mountain','Apt. 695','South Kimberlyton','Florida','63709');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pbecker@hotmail.com','Jamie','Brooks','656-549-8362x218','06705 Rachel Passage Apt. 272','Apt. 394','Josephville','Illinois','01122');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michaelmorris@singh.com','Tracy','Hall','097.234.4320','5100 Scott Pine Suite 994','Suite 413','Chavezview','Arizona','96784');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('makaylamiller@hotmail.com','Luis','Hudson','+1-992-696-1609','552 Donald Passage','Apt. 314','Moyerview','Idaho','60387');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('terryjuan@yahoo.com','Jessica','Baxter','985.484.9319','498 Samantha Prairie Apt. 700','Apt. 859','New Cathyborough','Illinois','30583');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sharpmatthew@gmail.com','Caleb','Guzman','341.853.7044x6061','82036 Rosario Viaduct','Apt. 360','Brewerport','Oregon','54171');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cody68@hotmail.com','Glen','Bauer','+1-253-011-6103','54570 William Ridges Apt. 214','Apt. 450','New Scott','Texas','87595');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('larsonmegan@yahoo.com','John','Johnson','001-836-956-5245x8718','668 Olsen Valleys','Suite 600','Marytown','Washington','19819');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('maria48@bowman.org','Sharon','Mann','7203654909','2364 Kevin Mount Apt. 421','Suite 576','Barrettland','Arizona','70082');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('qshah@gmail.com','Crystal','Rose','001-473-989-2735','891 Patel Keys','Apt. 264','Paulberg','Alaska','03658');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ramirezlisa@phelps.com','Ernest','Hammond','4664052339','673 Pearson Lodge Apt. 503','Apt. 192','North Sabrinaport','Rhode Island','44362');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('isaiahdavis@hotmail.com','Gregory','Miller','469.469.9777','48785 Alison Walk Suite 430','Suite 789','Jaredland','North Dakota','82294');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wilsonanthony@anderson.net','Brian','Jordan','104.794.9002','4979 Medina Underpass Suite 142','Apt. 351','Stewartmouth','Washington','20030');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('smithdonna@gmail.com','Timothy','Hays','081.672.7107','32771 Bell Club Suite 703','Apt. 110','New Jason','Maine','53478');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nathangibbs@davis-johnson.org','Benjamin','Doyle','(080)812-8307x35464','7397 Ashley Crest','Suite 724','Williamsport','West Virginia','39501');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('suzanne46@hotmail.com','Trevor','Armstrong','411-289-2453','902 Scott Unions Suite 458','Apt. 615','South Robin','New Jersey','82718');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cynthiajohnson@hotmail.com','Michael','Schwartz','+1-273-383-6625x14751','74054 Jennifer Crossroad','Suite 781','Lake Mary','Florida','72090');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pbrown@gmail.com','Rebecca','Miller','001-016-289-4673x66948','928 Wheeler Row Suite 297','Apt. 888','Duncanland','Oklahoma','59246');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fescobar@mckenzie.biz','Christopher','May','669-878-6755x1775','14343 Berry Flat Apt. 421','Apt. 129','Farmerton','Colorado','88948');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pottermartha@gmail.com','Elizabeth','Molina','+1-002-267-6944x474','0951 Amy Expressway Apt. 066','Suite 697','Danielside','South Carolina','56632');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('moorewilliam@stevenson.com','Brenda','Mora','928.502.6032','1443 Barry Shoals','Apt. 005','North Jeffrey','North Dakota','58853');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('medinatara@yahoo.com','Wesley','Fox','+1-654-300-8590x9664','8321 Russell Shores','Apt. 181','New Meganfurt','Minnesota','49612');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ychristensen@lozano-flores.net','John','Martin','001-396-627-9775x251','249 Cynthia Squares','Suite 584','Jenniferberg','Kentucky','03988');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('harperhannah@saunders.com','Yolanda','Long','190.859.0310x16002','2954 White Pine','Suite 410','Scotthaven','Alaska','96794');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('danielphillips@hotmail.com','Carrie','Harris','4225926448','88039 Lopez Lane','Apt. 190','West Donaldstad','Alabama','63087');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('william86@yahoo.com','Laura','Blackwell','4765819198','894 Barbara Valleys Apt. 881','Apt. 752','Lindseyview','North Carolina','98288');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wardheather@yahoo.com','Joanne','Frederick','843-954-5794x0122','888 Ochoa Pine','Apt. 226','New Richardfort','Wisconsin','03155');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnstonkevin@hotmail.com','Dustin','White','+1-107-584-0231','6571 Dudley Corners','Apt. 272','New Christopherville','Maryland','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wendy51@brown-scott.com','Sue','Hanson','002.283.9395','926 Jones Underpass Suite 973','Suite 288','Waltersmouth','New Hampshire','56504');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('normaneric@gmail.com','Stephanie','Rice','(734)641-5342','439 Whitney Brooks Apt. 121','Suite 335','East Danielshire','Arizona','03094');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('uross@yahoo.com','Joseph','Gutierrez','+1-253-672-6885x682','18025 Martin Circles Suite 507','Suite 420','Priceborough','Kentucky','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('donna13@hotmail.com','Kim','Wright','(496)021-8984x5905','8559 Jennifer Drive Apt. 715','Suite 384','North Donaldbury','Washington','28716');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mcdanielandrew@hotmail.com','Michelle','Nguyen','784-922-9951x660','1547 Adam Park Suite 658','Suite 884','Bradland','Vermont','81638');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('laurenallen@goodman.net','Michelle','Blackwell','253.974.5787x59995','807 Jeffery Forge','Suite 972','East Josephfort','Washington','27960');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('swagner@scott-foster.com','Bruce','Mills','367-893-3037','73466 Petersen Locks Apt. 262','Suite 326','Normanton','New York','95318');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brentmcclure@hotmail.com','Nicole','Velez','136.090.6480','0459 Bush Creek','Suite 249','Jaredfurt','Texas','01661');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('josephturner@yahoo.com','Austin','Glenn','(017)367-6003','9810 Gary Courts Apt. 701','Apt. 878','Angelicaland','Iowa','62843');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ellisdawn@hotmail.com','Douglas','White','(631)773-7131x66144','5928 Cowan Streets Apt. 620','Apt. 778','Stevenside','Colorado','27482');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pcurry@zamora-nguyen.com','Richard','Gallegos','001-732-458-1082','8764 Jacob Mills','Suite 736','North Courtneyville','Oregon','28832');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('danielscindy@zimmerman.biz','Joshua','Chavez','0480359156','23487 Katherine Circles','Suite 720','Port Carolville','Nevada','85878');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('megan78@simon.com','Jennifer','Sanford','338.164.0292x774','882 Valentine Mount Suite 570','Apt. 804','Sonyaville','Idaho','02261');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('timothy35@yahoo.com','Jennifer','Shaffer','(404)518-3088','90278 Angelica Fort','Apt. 881','West Justinberg','Louisiana','29763');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('anthonyeverett@calderon-daugherty.com','Sean','King','(638)059-4527x6447','29345 Tucker Glen Suite 288','Apt. 711','East Reneefurt','Utah','43129');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('randolphshirley@gmail.com','James','Estrada','(055)620-4028','70504 Matthew Court','Apt. 564','East Thomas','Oklahoma','02838');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('favila@santos.com','Haley','Scott','899-000-6495','798 Natalie Meadows Apt. 315','Suite 977','Port Joshuamouth','Kansas','51665');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hannah89@simpson.info','Sarah','Russell','279-727-5011x35165','116 Huff Mountains','Suite 947','Danielburgh','Vermont','80241');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('collinskristina@yahoo.com','Justin','Morgan','527-624-2264','2583 Gallegos Walks Apt. 591','Apt. 621','South Christinaport','Idaho','57660');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('merrittbrittany@yahoo.com','Heather','Thomas','001-140-290-4104','323 Katherine Isle Apt. 802','Apt. 523','Michaelmouth','Louisiana','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('juliegreen@gmail.com','Brittney','Mcgee','+1-590-847-4582x76153','356 Beverly Island','Apt. 666','Johnburgh','Virginia','73108');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dchapman@escobar-riley.info','Samuel','Anderson','+1-012-809-9197x37307','5599 Daniel Park','Suite 100','Reginahaven','Alabama','02894');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stephaniebaker@chandler.biz','Tyler','Chapman','001-757-011-1429x88150','716 Lee Cove Suite 282','Apt. 804','New Brittany','Alabama','99733');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ihogan@johnson.org','Angela','Harper','+1-758-649-3903x80825','2012 Craig Bypass Apt. 683','Suite 115','New Amanda','Wisconsin','47506');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('penningtonmichael@gmail.com','Tracy','Davis','001-636-895-9415x782','6456 Christine Walks','Apt. 868','Bryantshire','New Mexico','91530');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christine27@cannon.com','Christina','Morales','1464052477','7489 Carpenter Brook Apt. 884','Apt. 859','Robertborough','South Carolina','71604');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('smithphilip@hotmail.com','Jonathan','Chase','+1-115-142-7038','42545 Kiara Fort','Apt. 928','Katrinashire','Maryland','80542');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('turneranthony@bell-sharp.info','Kelly','Ayala','001-078-014-3961x0970','091 Miller Row','Suite 302','Port Jenny','South Dakota','05390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('andreaaguilar@lewis.com','Catherine','Thomas','(377)798-1326x905','9637 Carpenter Port Suite 483','Suite 829','Williamschester','Massachusetts','65219');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('leecourtney@stanley.com','Pamela','Kennedy','001-320-869-6202x8930','003 Murillo Inlet Suite 604','Suite 947','Stephaniemouth','Texas','55251');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ryan45@hotmail.com','Joseph','Lopez','(930)541-8398x96088','39185 Brooks Pine Apt. 459','Suite 603','East Dennis','Minnesota','19387');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mayedward@ramos-kemp.com','Kyle','Garcia','671-889-8176x1117','69534 Sheri Spur','Apt. 228','Caitlinside','Texas','02809');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('paynelaurie@hendricks-hunter.com','Norman','Smith','1322413543','7729 Hernandez Gardens','Apt. 043','Marcusshire','Montana','47980');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('curtiscuevas@perez.com','Jennifer','West','001-380-083-9910x1573','015 Hoffman Hill','Suite 722','Wademouth','Kentucky','57264');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('franklin73@tate.com','Jeffrey','Maxwell','+1-392-387-9183','27606 Alicia Spring','Apt. 994','Elizabethton','Montana','72423');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('marcmanning@williams.com','Abigail','Tyler','(717)067-4297x506','19430 Kelly Point','Suite 154','Wintersland','Maryland','62875');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('shernandez@white-benson.net','Caleb','Wyatt','001-865-301-8389x163','6007 Pacheco Prairie Suite 595','Apt. 367','Ballardstad','Alabama','97103');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lowerykatherine@coleman.com','Joanna','Jackson','893.687.7753x652','8515 Stevenson Ports','Apt. 494','Singletonmouth','Maine','59848');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('parsonstiffany@yahoo.com','Ricardo','Lucas','6720654351','472 Anderson Parkway','Suite 330','Robertfurt','Oregon','89316');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('riggskatelyn@yang-smith.com','Michael','Day','001-360-709-1548x6857','57601 Eugene Flats','Apt. 046','East Patrick','Georgia','05105');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnwhite@yahoo.com','Nathaniel','Meyer','043-729-5918','5764 John Lock Suite 126','Suite 141','South Terri','Nebraska','33363');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('yroberts@sutton.biz','Matthew','Miller','(482)386-3802x3526','6196 Whitney Springs','Suite 604','New Kellyview','Wyoming','97531');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('aimee05@yahoo.com','Brittany','Stewart','(956)649-6085x85096','63447 Stephanie Streets','Suite 943','Jamesborough','Indiana','59785');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('heathanthony@yahoo.com','Edward','George','261.031.8716x96777','27515 Megan Burg','Suite 810','Rosemouth','Nevada','04644');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('uramos@hotmail.com','Angela','Johnson','5459176018','15877 Pham Dam','Suite 960','Dunnfort','Wyoming','07740');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rogersryan@garner-sanchez.info','Amy','Jordan','7404538733','903 Victor Road','Apt. 509','Nicolechester','Tennessee','59493');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sgarrett@green.com','Matthew','Soto','206.247.1595','61269 Molina Causeway Apt. 971','Suite 405','Wolfeshire','Rhode Island','05456');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('elliscody@yahoo.com','Corey','Hernandez','991-290-3749','712 Wright Glen Suite 231','Suite 512','New Charleshaven','Alaska','99847');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('smithmatthew@hotmail.com','Nicole','Lopez','001-726-958-7424','38207 Stokes Isle','Apt. 636','Robertton','North Carolina','41418');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('reginald25@randolph.com','Katherine','Paul','6409133834','311 Carroll Keys','Apt. 390','Michaelburgh','Massachusetts','38333');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hillbrian@hotmail.com','Russell','Rodriguez','308-014-8063','0205 Katelyn Viaduct Suite 349','Suite 419','New Jacob','Hawaii','37772');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rwebb@hotmail.com','Joel','Mcpherson','001-875-224-8927','9870 Small Mountain','Apt. 254','Thomasfurt','Washington','63725');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('carlalewis@hotmail.com','Emily','Edwards','+1-506-271-2688x230','7558 Kyle Parkways','Suite 261','Clarkfort','Illinois','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bowenjason@mccarthy-campbell.biz','Amanda','Erickson','+1-824-151-5678x0886','079 Kathryn Island','Suite 355','East Nicholashaven','Delaware','58007');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bgamble@nunez-johns.com','William','Alexander','(962)163-9930x156','694 Austin Spur Suite 133','Apt. 568','North Matthewside','Delaware','54348');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stephanie71@pope.org','Dale','Bass','849.307.4311x211','82932 White Underpass Apt. 351','Apt. 791','Whitefurt','Indiana','03674');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bross@hotmail.com','Anna','Little','+1-868-041-7839x327','7791 Jessica Heights','Suite 067','New Johnland','Idaho','27391');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tanyawilliams@gmail.com','Sarah','Turner','814-926-9595x3261','875 Tran Manor','Suite 736','Simstown','Missouri','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('maryfarmer@gmail.com','David','Taylor','497.513.7417x86533','4038 Harris Mall Suite 214','Apt. 664','Nicholashaven','North Carolina','33952');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mmorris@hutchinson-johnson.net','Edward','Allen','001-916-835-5476','51338 Bailey Isle Suite 172','Suite 178','Port Cheryl','Nebraska','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vanessalowery@gmail.com','Daniel','Martinez','+1-293-281-9419','264 Adriana Branch Suite 179','Suite 337','Cameronport','New York','30211');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nathanbraun@hotmail.com','Anita','Casey','(421)282-9051x60418','65223 Watson Keys','Apt. 524','New Anthonyfurt','Michigan','48776');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('maureengray@jenkins.com','Erika','Robertson','1714469432','921 Julian Expressway','Suite 253','Bushfort','Nevada','57633');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('anthony73@gmail.com','Tamara','Wilson','(680)166-3308','91104 Elizabeth Crescent','Apt. 803','Luisstad','Illinois','05485');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ismith@yahoo.com','Bryan','Jones','753-695-2465','38424 Matthew Gateway Apt. 925','Apt. 483','West Annaside','New Jersey','91252');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jasonjones@yahoo.com','Rita','Velasquez','(619)769-1064x2823','68738 Amanda Plain Apt. 268','Apt. 557','Port Adrian','Utah','59187');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('chaneydavid@hotmail.com','Mary','Rangel','+1-182-495-0806','930 Bianca Place Suite 155','Suite 169','West Sarah','New Jersey','29092');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lutzxavier@little.com','Sean','Lopez','276-319-2231','01854 Karla Club','Apt. 691','Jasonbury','West Virginia','94735');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stewartmark@yahoo.com','Christopher','Gutierrez','326-936-3467','225 Christopher Prairie','Suite 833','East Richardview','South Carolina','96821');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('manuelwaller@hernandez.com','Patrick','Oneill','(184)863-3638x73206','8549 Gonzalez Loaf Suite 952','Apt. 744','West Joshua','New York','36610');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lindseygray@hotmail.com','Matthew','Gonzalez','+1-091-030-8017x00045','5503 Blair Station','Apt. 378','South Timothy','Mississippi','50558');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnnygonzalez@howe.com','Mike','Cox','292-353-0718','9857 Baldwin Pine Suite 630','Apt. 303','New Ann','Texas','66082');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('amandadavis@hotmail.com','Dwayne','Richardson','+1-483-201-4281','4699 Coleman Underpass Suite 870','Suite 099','Toddstad','Massachusetts','57684');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('taylorjustin@gmail.com','Samuel','Mcdaniel','+1-469-719-4184x37685','5543 Cooper Vista Suite 167','Apt. 162','Jonesfort','Connecticut','83622');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mendozasusan@berry.com','Breanna','Case','+1-691-776-5379x235','77866 Erik Mountain','Suite 855','West Saraside','Rhode Island','85107');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bellnancy@gmail.com','Richard','Hodges','001-499-019-2788','639 Spence Loaf Suite 630','Apt. 147','Lake Joseph','Alabama','29640');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('margaret69@gmail.com','Curtis','Lopez','428-975-5767','463 Liu Isle Suite 357','Apt. 930','Judithhaven','Massachusetts','35933');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bjimenez@yahoo.com','Chloe','Moore','466.254.6349x450','408 Robert Run','Apt. 803','East Michael','New Hampshire','84630');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ian80@fisher-grant.com','Meghan','Lam','001-179-090-3920x433','47791 Stevens Lakes Apt. 094','Suite 007','Tinashire','Illinois','57184');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('emanning@obrien-bell.com','Arthur','Martinez','+1-598-207-0615x970','264 Douglas Place Apt. 841','Apt. 688','Christopherside','Rhode Island','70765');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnrobinson@hunt.info','Brandi','Cooper','+1-913-874-9923x08313','485 Russell Ways','Apt. 080','Jeffhaven','California','19881');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ajones@anderson.com','Shannon','Brown','(512)537-4954x176','7856 Christopher Mountains Apt. 427','Suite 104','East Kimport','Mississippi','39407');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('perezbenjamin@yahoo.com','Jacqueline','Lyons','706-171-1695x799','672 Andrew Wells','Suite 177','Lake Dawn','Colorado','19932');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('felicia10@anderson-smith.org','Donna','Perry','6285487756','1936 Jake Lane Apt. 978','Suite 696','Terrystad','New Mexico','08094');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('evanschneider@hotmail.com','Steven','Robinson','(249)631-2236','6084 Parker Light Apt. 684','Apt. 714','Adamberg','North Carolina','86327');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ktaylor@gmail.com','Roberto','Peterson','442.924.0585x756','855 Thomas Mews Suite 112','Suite 062','Mariahhaven','New Mexico','08333');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('diamondtownsend@gmail.com','Laura','Watson','(250)900-2038','3177 Maria Divide','Suite 252','Port Amy','Maine','83857');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('merritttina@mccormick.biz','Jessica','Terrell','099.446.9629x882','52482 Michael Turnpike Apt. 990','Suite 881','New Shannon','New Jersey','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('robertmcclain@hotmail.com','Laura','Stone','984-074-2441x03908','6620 Katherine Locks Suite 139','Suite 623','North Amber','Idaho','83106');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('adam47@edwards.com','Michael','Benjamin','988.852.9536x6551','1919 Mcdonald Drive','Suite 478','West Danielton','North Dakota','60082');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hbolton@gmail.com','Carolyn','Carlson','046.703.9638x88352','12410 Christian Motorway Apt. 148','Suite 918','Kimhaven','North Dakota','72643');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brockkelsey@blanchard.com','Cynthia','Contreras','868-667-6149x17035','728 Anthony Harbors Suite 945','Apt. 985','Griffintown','South Dakota','19814');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('william48@lin-carlson.com','Haley','Green','(299)766-9396x32104','25152 Paul Plain Suite 461','Suite 576','Port Pamborough','Florida','70675');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('courtney95@beard-brown.com','Peter','Mitchell','604.433.9839x11795','31517 Ashley Orchard','Apt. 579','Townsendmouth','Mississippi','98226');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('medinawilliam@hotmail.com','Maria','Rose','(666)932-2802x654','06616 Renee Stream','Suite 803','New Wayne','New York','03528');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('marie53@nguyen.biz','Michael','Reyes','578-207-9038x77767','0367 Salinas Row Apt. 662','Apt. 786','East Mary','South Carolina','44560');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wjackson@hotmail.com','Danielle','Blair','(930)863-3300x5292','96433 Brown Coves','Apt. 535','Brandonmouth','Texas','54379');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mayerjohn@gmail.com','Rebekah','Rodriguez','249-425-6912x95189','57305 Pamela Path','Suite 908','South Laura','Alaska','80557');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('alan16@hotmail.com','Erin','Perkins','+1-249-205-4640x071','1646 Williams Plaza','Apt. 117','New Martin','Kentucky','82225');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('steven50@herman.com','Gregory','Hardin','+1-787-568-2608x91082','60834 Lisa Crescent Apt. 364','Apt. 812','Vickimouth','Washington','25395');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('myersantonio@yahoo.com','Cynthia','Bass','+1-087-464-3928x04864','142 Ryan Island Apt. 837','Suite 332','Port Briantown','California','55259');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('zwallace@gmail.com','Sarah','Turner','251-614-1400x56765','276 Wayne Wells Apt. 767','Apt. 036','South Katherinefort','Texas','63250');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('adamanderson@yahoo.com','Samantha','Snow','545.043.4723','72443 Olson Manor','Suite 418','Port Brittany','Alaska','72946');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nortiz@hotmail.com','Steven','Smith','4386213723','496 Thompson Courts Suite 077','Suite 083','East David','Pennsylvania','31993');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ruizcasey@hotmail.com','Judy','Johnson','073-623-4329x60896','12488 Duke Estate','Apt. 549','Riggsburgh','Ohio','91127');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jason20@hotmail.com','Tina','Flowers','931-302-6426x776','490 Kathryn Mills','Suite 274','New Paulachester','New Mexico','91629');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bakerseth@gmail.com','Caroline','Kramer','330-298-8825','0554 Hicks Summit','Suite 951','South Davidborough','Arizona','42759');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('braysarah@rodriguez-powell.com','Karen','Novak','280.494.8264x931','325 William Squares','Apt. 928','Lake Aaronport','Indiana','48294');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('zjohnson@yahoo.com','Joshua','Parks','(905)559-1780x571','286 Angela Pass','Apt. 107','Xavierside','Illinois','62277');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rodgerslisa@turner.com','Bonnie','Mendoza','+1-160-584-0752x144','65375 Hannah Corner Apt. 889','Suite 902','Wangfort','New Jersey','48940');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('martinezmichelle@lozano-moore.com','Benjamin','Brown','488-451-3737','2168 Barbara Meadow','Apt. 812','Kennedyhaven','Delaware','60609');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('zdavis@mitchell.com','Kevin','Long','385.138.4696x9602','8007 Floyd Meadows','Suite 036','East Michael','Georgia','89453');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tjackson@gmail.com','Andrew','Terrell','991-004-9673x6827','3456 Amy Squares Apt. 040','Suite 858','North Nicholas','North Dakota','31088');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wayala@williams.info','Kevin','Stewart','754-556-5119x204','38519 Amy Forges Suite 682','Apt. 161','North Laura','Texas','97866');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('harrisonhenry@hotmail.com','Daniel','Small','(120)346-3935x8112','946 Donald Garden','Suite 504','Leehaven','California','19859');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('craigtaylor@perry.org','Lori','Holland','+1-189-096-9057x51936','9233 Hall Curve Suite 577','Suite 787','Pachecoport','Colorado','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ronald84@williams-smith.org','Troy','Williams','(124)360-2083','57464 Smith Walk','Suite 287','South Tracey','Florida','55472');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('browndebbie@moore-christensen.com','Jacob','Perez','(383)755-0636x628','5609 Erica Mount Apt. 667','Suite 576','South Jesse','Connecticut','99716');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mwest@hotmail.com','Gabriel','Benson','044-281-7937','918 Taylor Bridge Suite 944','Suite 275','Kevinburgh','New Hampshire','37540');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('timothy27@nunez.com','Nicholas','Williams','(075)329-3019x47307','104 Bolton Throughway','Apt. 084','Waltersfort','Louisiana','19929');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('millsjoseph@hotmail.com','John','Smith','732-499-6537','0875 Acosta Forest Apt. 186','Apt. 070','North Shawn','Wyoming','47259');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('davidlopez@davis.biz','Melissa','Boyer','+1-478-836-7604x69206','115 Ryan Spur','Apt. 322','Orozcomouth','Nevada','56586');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nicole76@hotmail.com','Selena','Moore','035.428.0410','64390 Taylor Meadow','Suite 714','Garciafurt','Vermont','86377');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('linda62@hill.com','Vanessa','Moore','289.340.4533x950','8643 Bautista Heights Suite 453','Suite 626','West Jeffreymouth','Indiana','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nicole08@pham.net','Sherri','Love','(184)866-9879','501 Jason Meadows','Suite 512','Colemanport','Rhode Island','20025');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('thomasvanessa@hotmail.com','Maria','Moore','473.358.3651x80866','1493 Danielle Springs','Apt. 986','Dyerbury','New Hampshire','31528');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('daniel43@morton.com','Shawn','Price','001-067-779-3587x341','1199 Blake Mountains Suite 840','Apt. 630','Michaelfurt','Arkansas','59169');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rschwartz@parker.com','Brian','Oneill','3242348434','6935 Thomas Pine Suite 084','Apt. 555','Lake Crystal','Indiana','27773');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('david69@wilson.biz','Richard','Thompson','523.280.5727','47405 Johnson Branch Suite 610','Apt. 493','Kristinaport','Vermont','25893');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tammyleon@valdez.info','Heather','Contreras','470-042-0649x9964','7091 Jerry Ford Suite 036','Suite 133','Hicksmouth','Texas','66915');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('taylorlisa@hotmail.com','Patrick','Ruiz','201.350.6705','620 Greer Drive','Suite 828','Nataliechester','Arizona','89182');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tamarasnyder@yahoo.com','Stephen','Manning','+1-019-708-1809x069','635 Tracy Wall Suite 251','Suite 083','Steveborough','Kansas','25860');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('watsontanya@riley.com','Caroline','Johnson','936.687.7621','81008 White Valleys Suite 048','Suite 443','Prattmouth','Pennsylvania','99046');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('katelynsnow@rogers.net','Kathryn','Harris','(051)076-1007','19693 Stout Valley Suite 117','Apt. 277','Ryanton','Arizona','59671');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('velezchristopher@gmail.com','Robert','Galloway','916-506-4452x820','74574 William Square','Apt. 863','Heatherport','Utah','05136');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nfields@gmail.com','Jessica','Mullen','001-993-887-7575x9907','45972 Gilmore Club Suite 349','Suite 277','South Amy','North Dakota','46869');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('qmartinez@hotmail.com','Jay','Lawrence','+1-515-932-3198x6714','61259 Daniel Junction','Apt. 988','North Samanthaside','Connecticut','57736');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kathryn94@hotmail.com','Clayton','Mckinney','1275863709','28564 Jonathan Parkways','Suite 777','Jordanshire','Oklahoma','70175');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nmoore@curtis.info','Amy','Williams','944.120.2873','4155 Lisa Terrace','Suite 962','Lake Cassandrabury','Connecticut','35265');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brenda79@gmail.com','Jackie','Howell','001-413-526-6864x41607','95310 Butler Crescent Suite 569','Suite 756','Vasquezmouth','New Jersey','03709');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tanyaconway@hotmail.com','Jasmine','Stephens','610-837-8087x67131','159 Braun Pines Suite 172','Apt. 191','South Vincentchester','North Dakota','05277');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joshuataylor@gmail.com','William','Harris','001-509-202-5583','172 Debra Ford Suite 252','Apt. 595','East Laurastad','Florida','99659');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('richard06@yahoo.com','Carol','Blankenship','001-475-716-3762x668','253 Tanner Junction','Apt. 017','West Brittney','Nebraska','97808');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('martinpreston@dawson-savage.biz','John','Gonzalez','(534)976-3180x866','69921 Taylor Plaza Apt. 310','Apt. 972','Williamsmouth','Connecticut','29423');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('millerjane@gmail.com','Rachel','Graham','001-886-935-1676x8831','0317 Michael Cliff','Apt. 962','South Nicolebury','New York','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sanchezsarah@gmail.com','Katherine','Kelly','545.700.8207x39178','41998 Calvin Ports','Apt. 853','Smithmouth','Connecticut','06333');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brownmatthew@morgan-meyer.com','Marvin','Torres','075.349.8577x5115','89811 Brent Ford','Apt. 119','Markland','Nebraska','73110');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mpowers@hotmail.com','Dwayne','Stafford','(483)944-9308x6708','767 Austin Plain Suite 520','Suite 864','West Marie','Texas','95960');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('david16@hotmail.com','Crystal','Newman','001-974-280-6517','0308 Zachary Expressway Suite 094','Suite 175','West Justin','Oklahoma','32680');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bhines@gutierrez.com','Lydia','Becker','435.093.5284','718 Harris Pine','Apt. 428','Stephaniefort','Montana','03639');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brittney99@phillips.org','Eric','Schmidt','728.230.1090x5010','6840 Amber Expressway','Suite 484','South Suzanne','Wyoming','45461');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('onelson@valentine.biz','Linda','Fisher','001-086-155-9185x528','6012 White Summit Apt. 608','Apt. 640','West Elizabethfort','California','54950');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('john25@hotmail.com','Antonio','Barrett','(267)164-3210','76359 Harper Expressway Suite 773','Apt. 619','North Joycestad','Missouri','48143');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('chelseagriffin@cunningham-carpenter.org','Laura','Maynard','+1-318-223-8026x159','246 Gutierrez Burg Apt. 894','Apt. 251','Berryland','New York','96784');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('perezmisty@hotmail.com','Nathaniel','Taylor','+1-372-975-9249','0337 Ramos Heights Apt. 968','Suite 043','Hessberg','Oklahoma','65729');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('karen76@lane.com','Don','Jones','+1-499-201-5059','08069 Emily Prairie','Suite 999','Gwendolynchester','California','93479');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tcook@hotmail.com','Jacqueline','Miller','3163405054','16766 Stacy Rapids Suite 174','Suite 564','New Alyssaside','Montana','87043');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bryce70@yahoo.com','David','Ruiz','036.367.9714x03430','42300 Harris Plain Apt. 817','Apt. 102','West Charleshaven','Indiana','83422');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('deniserogers@hotmail.com','Theodore','Harrison','(265)869-4445x6929','4922 Carolyn Road','Apt. 993','West Donald','Minnesota','45979');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('amber94@wood-salinas.com','Alison','Steele','(189)962-9430x9410','534 Brandon Harbor Suite 553','Apt. 780','Markstad','Illinois','81243');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bjones@gmail.com','Stephanie','Berger','+1-941-780-1689x6295','02964 Kathryn Courts Apt. 808','Suite 733','North Heather','Louisiana','49798');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('emilymcknight@cook.com','Kimberly','Finley','001-271-654-6257x7025','40607 Johnson Mount','Suite 160','South Kenneth','Alaska','49925');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vmay@evans-martin.net','Rachel','Williams','001-332-689-4763x6660','667 Janet Cape Suite 637','Suite 325','Nicholasstad','Nebraska','66738');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michele29@gmail.com','Michael','Diaz','(992)789-4334x3768','83798 Jonathan Ways','Apt. 009','Wareburgh','Missouri','83251');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ujohnson@yahoo.com','Michael','Lopez','+1-213-878-2401x080','3306 Sandoval Creek Apt. 675','Suite 189','New Samanthaberg','Maine','88186');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('levyemily@king-smith.com','Brittney','Clark','423.871.5869','764 Dennis Motorway Suite 718','Suite 494','Longshire','Hawaii','04196');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('matthewbrown@yahoo.com','Jason','Burton','055-491-6764','15301 Carey Rue','Suite 938','Port Karenshire','Pennsylvania','46313');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ckerr@hurst.biz','Elaine','Johnson','001-051-451-0379x70122','777 Stacey Union','Suite 778','Rubenfurt','Massachusetts','06367');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('keithhughes@hill-ford.biz','Jose','Moreno','6806522456','4658 Hess Estates','Suite 373','Davisview','Maine','64981');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('andrewbeard@gmail.com','Mitchell','Jones','+1-711-529-7636x97032','4155 Tonya Rue','Suite 594','West Raymond','Oregon','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('qlee@hotmail.com','Jenna','Barnes','756.225.2869x9077','01814 Gilmore Ports','Apt. 895','Evanschester','Alabama','99194');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('alanallen@brown.org','Angela','Blackwell','919.175.1091x3074','740 Bowman Cliff','Apt. 359','Nicholeport','Florida','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('terribradley@hotmail.com','Leslie','Robinson','001-224-587-6620x768','029 Wallace Locks Apt. 024','Suite 681','West Amandaberg','Pennsylvania','81517');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('patrickhancock@johnson-king.com','Michelle','Allen','695.080.3071','24858 Perry Harbors','Suite 744','Lake Katherine','North Dakota','65363');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ruben39@hotmail.com','Antonio','Hall','(204)323-7499','28907 Valerie Station Apt. 572','Apt. 136','West Bradleyhaven','Hawaii','64860');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cantrelljohn@gmail.com','Rebecca','Weaver','(373)677-3718x895','04091 Jody Centers','Apt. 606','Port Danielside','Maine','72200');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gdunlap@hotmail.com','Timothy','Martinez','499-376-0020','387 Melvin Flat Apt. 773','Suite 101','East Dakotabury','Michigan','31115');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('shelly42@yahoo.com','Justin','Gonzalez','928.738.4155x07560','45063 Schneider Plaza','Suite 531','New Jamesburgh','New Mexico','38778');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gabrieldiaz@gmail.com','Darren','Rollins','(764)442-9918x843','58355 Bryant Pike','Suite 406','Christopherside','Colorado','20023');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('courtneybutler@marks.net','Jessica','Williams','001-349-513-6452x8799','4753 Adams Road','Apt. 221','North Sabrina','Washington','86294');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gibsonsara@gmail.com','Christina','Cook','9892638303','29727 Edward Gardens','Apt. 148','Weissborough','Oregon','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cmcdowell@yahoo.com','Christopher','Morales','604-263-6967x19302','9126 William View','Apt. 063','North Shelbyfurt','Wisconsin','82418');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rioslauren@hotmail.com','Allen','Rodgers','+1-356-363-2437x4708','244 James Viaduct Suite 177','Suite 599','West Jeffrey','Nevada','89462');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bruce43@gmail.com','Leah','Soto','862-780-6207x7960','30375 Katherine Radial Suite 092','Apt. 957','Guerreroport','Florida','07881');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('luceromichael@yahoo.com','Daniel','Thomas','001-898-865-3708x648','847 Daniel Way','Suite 408','Jasminestad','West Virginia','57484');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('xsmith@cruz.com','Roger','Douglas','(840)475-4171x6969','95258 Mary Estate','Suite 311','Youngland','Wisconsin','99614');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gwhite@yahoo.com','Shawn','Taylor','+1-993-595-9755x3094','795 Caleb Turnpike','Apt. 606','Morganside','Colorado','43999');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jaredhoffman@hotmail.com','Sabrina','Young','(141)552-5857x2974','542 Trujillo Walk Suite 313','Suite 528','Kimberlyfurt','Tennessee','17066');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vincentvaughn@bradshaw.biz','Heather','Wise','+1-259-581-4815x9122','764 Ellis Lodge','Suite 233','Ramirezhaven','Missouri','71988');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('yramirez@brooks.com','Briana','Soto','+1-640-756-3909x95616','5027 Phillip Drive Suite 770','Apt. 197','South Walterport','Georgia','59702');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rfitzpatrick@singh.info','Courtney','Lopez','070-038-4005','859 David Groves Apt. 664','Suite 112','Lake Wanda','Utah','03805');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('yalexander@allen.com','Tony','Edwards','360.651.6018x24258','37702 Samuel Row Apt. 042','Apt. 987','Kristiefurt','New Mexico','60121');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('william46@bishop.com','Christopher','Baker','+1-296-900-6397','6759 Stephenson Lane Apt. 023','Suite 565','East Yvonne','Ohio','68108');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lopezdarrell@matthews.com','Luke','Robinson','439-601-7993','653 Price Isle Suite 701','Suite 120','Jennifermouth','Alaska','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lindseysamantha@gmail.com','Amanda','Steele','(026)409-0634','248 George Estate Apt. 946','Suite 094','Johnstonshire','Arkansas','30650');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nanderson@gmail.com','Robert','Walsh','956.946.5670x67459','5882 Fields Stream Apt. 846','Apt. 562','Millerport','Virginia','84596');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jenniferjohnson@hernandez.com','Valerie','Torres','(389)168-2641x86450','01327 Joshua Lodge','Suite 293','West Erikside','Arkansas','67472');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brownkevin@banks-jordan.info','Jacob','Brown','789.655.7084','6926 Fisher Plain Apt. 650','Suite 007','Port Charlesborough','Arkansas','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('melissa94@carter.com','Tyler','Sawyer','042-046-8051x0502','02774 Morgan Row','Suite 996','West Melody','Arizona','56506');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('zachary16@solis-gutierrez.org','Erin','Ramirez','001-868-270-7361','289 Taylor Circle Apt. 627','Apt. 302','Watsonville','Oklahoma','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dennis44@gmail.com','Marie','Hanson','629-106-1008x3441','22646 Lewis Trail Apt. 243','Suite 759','Nicoleview','Iowa','71214');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wwilliams@black-brown.biz','Laura','Solis','+1-969-665-7484','24346 Fowler Club','Suite 735','Jeffreystad','Texas','03140');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('averyrobin@hotmail.com','George','Cantrell','724.081.9158','404 Sarah Flat','Apt. 466','Ramseyborough','Washington','80622');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jacksonlori@yahoo.com','Tina','Jones','001-522-781-6057x2878','3586 Morgan Drive','Apt. 762','South Carl','North Carolina','26761');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lindawilliams@lowe.com','Vincent','Graham','(867)435-1907x88418','6144 Dana Camp','Suite 871','New Matthew','Maine','90922');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('adam52@hotmail.com','Nathaniel','Kane','(016)675-1245x82234','572 Cohen Ville','Apt. 127','Olivermouth','Nebraska','36271');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('evan64@rivas.info','Brian','Webb','(354)898-9207x475','1023 Timothy Underpass','Suite 991','North Michelle','Virginia','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gmercado@hotmail.com','Tina','Hunter','001-829-941-9411x92147','55920 Erica Cliffs','Suite 143','West Cathy','Louisiana','02815');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vfarmer@smith-brown.com','Lisa','Martin','001-696-426-4657','79064 Donna Prairie','Apt. 667','Port Dennisburgh','Ohio','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mjohnson@woods.com','Katherine','Brooks','509-499-8695x549','2493 Courtney Fords','Suite 719','North Beverly','South Dakota','20012');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tristandelgado@hotmail.com','Michael','Lewis','508-722-1968','7471 Brandon Corner','Apt. 231','Fordborough','Washington','92052');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jenniferhayden@wright.net','Isaac','Martin','(016)182-3162','0035 Dominic Creek','Suite 758','Port Andrewmouth','Kansas','73158');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('edwardthomas@adams.biz','Mary','Kim','194-768-1840x719','27584 Susan Turnpike Apt. 755','Suite 018','Michaelborough','Pennsylvania','52713');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('morriscorey@wood-smith.com','Rebekah','Dean','068.100.5051x459','217 Kimberly Road Suite 485','Suite 997','Port Kevinview','Arkansas','20036');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('iclark@davis-garcia.com','Lori','Zimmerman','(035)033-0323x253','2545 Wolfe Estate','Suite 280','North Tonytown','California','83389');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vcraig@yahoo.com','Gina','Weaver','0953771559','342 White Rapids','Suite 765','Sherryberg','Connecticut','19940');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kevin28@barnes-west.com','Adrian','Barnett','001-965-581-9873x4698','732 Shaun Alley','Apt. 401','Port Timothy','New York','37890');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('moconnor@adkins.org','Belinda','Davis','384.530.0895x4410','7511 Stephens Crossroad','Apt. 753','Clarkefort','Wyoming','35738');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vriley@lee-george.com','Meredith','Johnston','(885)742-1950','11085 Reid Light','Apt. 061','Calderonville','Virginia','41197');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('donovanbonnie@gmail.com','Tammy','Williamson','(815)522-7759','40868 Garcia Park','Apt. 533','Justinberg','Montana','25875');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joshuaprice@hotmail.com','Adrienne','Rogers','545-912-9534','1784 Michael Neck','Apt. 244','New Samanthashire','Ohio','63658');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jason41@mason-larson.biz','Jessica','Gordon','+1-304-880-0546x859','2703 Kane Route Apt. 719','Suite 043','Martinstad','Michigan','31519');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christopher23@keller.com','Jennifer','May','739-497-3027','35120 Lee Parkway','Suite 549','New Jeffreyside','Wisconsin','27671');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('margaret89@vazquez.com','Linda','Wright','642-281-6773x140','830 Vanessa Curve','Suite 696','South Michelleland','Mississippi','06308');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pollarderic@patrick.info','Brianna','Russell','015.751.3166x10624','745 Daniel Summit Suite 276','Apt. 640','Lake Emilyfurt','California','19340');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('imolina@gmail.com','Christopher','Roth','(528)670-3812x2737','400 Moore Corner Apt. 452','Suite 255','Melissashire','California','51973');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lindasingleton@gmail.com','Angela','Ponce','001-390-837-9738x11220','280 Gary Shoals','Suite 827','East Latoyachester','West Virginia','20017');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joellozano@yahoo.com','Melissa','Burns','001-980-251-5445x228','22240 Mark Loaf','Suite 481','Arnoldmouth','Missouri','47059');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('allisondaniels@johnson.com','Aimee','Bryant','+1-069-864-8911x49108','1451 Timothy Ford','Apt. 934','Evanston','Ohio','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('crystaljones@yahoo.com','William','Decker','(384)878-9055x308','185 Howard Summit Suite 980','Suite 815','Ronaldmouth','Illinois','02730');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hwoodard@yahoo.com','Jill','Anderson','6042456481','1209 Daniels Wells','Suite 063','East Amanda','Kentucky','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gomezcurtis@hotmail.com','William','Rodriguez','353-133-7676x84658','904 Wilson Causeway','Apt. 540','West Aliciaville','Connecticut','38271');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('justincarlson@hotmail.com','Amber','Austin','953-063-1684x08353','7645 Baker Rapids','Apt. 741','Port Derek','Tennessee','67599');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('millersusan@glover.com','Barbara','Mitchell','+1-261-592-8308x032','18850 Martinez Springs','Apt. 902','Lake Michaelside','Maryland','02839');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christinethompson@yahoo.com','Angela','Moore','411.642.0535x605','53918 Burns Motorway','Apt. 644','New Katherineburgh','Vermont','06028');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('williamsjacob@hotmail.com','William','Sellers','+1-257-725-4391','4125 Bryan Ville','Suite 870','Jeremyshire','Maine','37982');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('samuel28@gmail.com','Carlos','Green','527-073-2092','669 Stephanie Valley Apt. 372','Suite 773','Maldonadoborough','California','28654');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gina62@hotmail.com','Alicia','Yoder','001-722-339-9822x667','45665 Matthew Crescent Apt. 708','Apt. 383','New Jeffrey','Mississippi','25915');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('salinasdaniel@hotmail.com','Mercedes','Hardin','(265)890-2492x7651','3893 Jasmine Wall','Suite 151','Moralesmouth','Virginia','55626');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('james35@gmail.com','Steven','Caldwell','229.684.7649','23802 Callahan Forges Apt. 456','Apt. 248','Jerryborough','Nebraska','57147');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tayloranna@yahoo.com','Phillip','Bennett','344.708.3536x14389','55488 Harris Walk','Apt. 892','Blackburnside','Massachusetts','83211');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ulee@robinson.biz','Daniel','Garcia','(662)126-9918x3695','458 Drake Shoal Suite 613','Apt. 060','New Robert','Illinois','44274');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('elizabethallen@riggs-johnson.com','Patricia','Garza','(427)358-8103x72688','6484 William Spur','Suite 589','Williamsonhaven','Alabama','05355');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('shannonwilliam@yahoo.com','Shannon','Park','(850)755-0728','595 Morgan River','Apt. 704','Douglasview','West Virginia','72698');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ugalloway@peters.net','Rebecca','Robinson','001-580-245-9716x38956','7831 Melanie Tunnel','Apt. 910','Port Mary','Vermont','51206');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michael43@yahoo.com','Theresa','Martinez','533-143-7214x199','445 Robinson Islands','Apt. 755','New Johnshire','Ohio','82940');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('collinsvanessa@nguyen.net','Mike','Kim','(554)365-6319x5969','7356 Thompson Pines','Apt. 055','Jimenezburgh','Montana','68051');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('svillanueva@hotmail.com','Tanya','Hunter','+1-335-501-7010x871','15371 Kim Mountain Suite 707','Apt. 678','Joshuafurt','Iowa','28430');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pbraun@hotmail.com','Sonya','Adams','439-343-6086x878','3580 Collins Course Apt. 284','Apt. 280','North Anne','California','03335');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('moorerobert@acevedo.com','Carrie','Krueger','+1-219-825-5088','59772 Rachel Coves Suite 361','Apt. 846','Hartside','Idaho','02706');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gary57@gmail.com','Barbara','Garza','049-504-9768x88305','81987 Mitchell Unions Apt. 482','Suite 952','Gonzalezbury','Minnesota','59225');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('heatherblackwell@hotmail.com','Joseph','Lopez','857-139-3529x92364','525 Black Ways Suite 464','Suite 870','New Erika','Oklahoma','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hunterjames@williams.com','Katherine','Sampson','+1-528-871-9879','7709 Jacob Coves Suite 069','Apt. 062','Thomasfort','New Mexico','84580');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ykramer@hotmail.com','Michelle','Ballard','891.231.5843x113','65788 Perry Island Suite 698','Apt. 698','Port Dennisshire','Utah','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hblack@yahoo.com','Lisa','Frank','146.673.0917x78353','020 Scott Prairie Suite 743','Suite 387','North Jamesborough','Massachusetts','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nicolemiller@miller-ellis.org','Robin','Smith','238.212.0635','740 Mooney Ranch','Apt. 455','Vickiemouth','Arizona','87571');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ppowell@hotmail.com','Thomas','Arnold','+1-202-266-0262x355','174 Lawrence Pike Apt. 604','Suite 355','West David','Pennsylvania','48968');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brenda22@gmail.com','Gregory','Brown','001-521-227-0153x24538','32875 Lee Roads Suite 431','Suite 000','North Travis','Utah','41789');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tayloralexis@lewis-walker.com','Allison','Newton','+1-862-864-9960','39573 Welch Track Suite 502','Suite 722','Aprilport','New York','28568');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dhancock@arnold.com','Jessica','Estrada','069.707.9559x7799','42983 Samantha Port','Apt. 916','Stephaniefort','New Mexico','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('xramirez@galvan-meyer.org','Melissa','Duncan','001-614-583-3450','021 Mccall Fort','Apt. 350','Cainborough','Rhode Island','32943');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vanessaedwards@mack.com','Justin','Reese','+1-100-267-5622x64363','167 Conley Station Suite 587','Suite 153','East Margarettown','Virginia','29045');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sandradiaz@barry.com','Kari','Smith','(997)107-7178','9822 Gina Landing Apt. 432','Apt. 269','Andrewchester','South Carolina','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gwood@williams-bowen.info','Eric','Mcbride','095-016-2587x339','12950 Mary Coves','Suite 947','South Joseborough','Connecticut','16580');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ashley60@johnson.com','Gregory','Brown','(497)557-5075x43554','4659 Jeremiah Pine Suite 610','Suite 412','South Arthur','Colorado','58729');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pwilson@meyers.com','Rebecca','Green','264-749-3287','085 Ruben Gardens Suite 757','Suite 898','Robertmouth','North Carolina','73130');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('melissawright@yahoo.com','Bryce','Dodson','+1-619-465-8834x039','342 Ashley Stream','Suite 778','New Jessebury','Mississippi','82575');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ashleytucker@david-martinez.net','Heather','Huffman','244-947-0219x742','571 Morgan Plains','Suite 720','Morrismouth','Indiana','47585');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ochoaann@robertson.com','Heather','Robles','+1-056-585-8770x60553','59216 Austin Shores Apt. 703','Apt. 032','Campbellbury','Utah','61518');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michellelopez@hotmail.com','James','Vaughn','033-746-8559','250 Katie Islands','Apt. 737','West Vanessabury','Nevada','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gcollins@gmail.com','Miguel','Barnes','(827)613-9556','617 Duke Forks','Apt. 438','Markton','Delaware','83310');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jasonrodriguez@williams.com','Barbara','Cobb','(761)563-3450x5851','76909 Joseph Via','Apt. 918','Williamton','Michigan','04064');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('laura09@gmail.com','Sean','Perez','+1-224-529-0948x544','044 Chelsea Vista Suite 308','Apt. 842','Jordanchester','Montana','43360');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('suzannesawyer@gmail.com','Marc','Cooper','133.438.4444x4959','57554 Jesus Curve Suite 847','Apt. 226','Allisonport','Wyoming','15705');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('boyledominique@hotmail.com','Michael','Swanson','(045)974-4883x74262','3259 Daniel Meadow Apt. 097','Suite 274','West Jeffreychester','Michigan','58181');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('erinellis@hill-wright.com','John','West','001-486-964-8058x845','088 Watkins Islands','Apt. 416','Lake Seanport','Wyoming','57475');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jennifer63@yahoo.com','Jane','Young','762-048-0699x474','206 Miller Extension Suite 853','Apt. 853','Estesland','New Hampshire','43140');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hunterrobert@hotmail.com','Nicole','White','446-088-8827x183','71906 Green Meadows','Suite 769','South Mike','Washington','59514');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('othompson@yahoo.com','Melanie','Mosley','744.621.3629','1432 Banks Port','Suite 268','West Jessica','North Dakota','02831');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sherrifloyd@yahoo.com','Michael','Lopez','328.469.4174','141 Brown Motorway Apt. 978','Apt. 878','Ericbury','South Dakota','70258');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rhoward@evans.com','Zoe','Davis','229-964-1691x51527','018 Patricia Greens','Suite 976','Nicholasshire','Vermont','73103');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rachelpeterson@hotmail.com','Victoria','Novak','876.210.5659x2378','0970 Jenkins Drives','Suite 321','Caldwellstad','Mississippi','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('delgadobrittany@foster.com','Cassandra','Owen','+1-603-549-5203x9633','87634 Nicole Manor Apt. 155','Suite 459','West Hannah','Hawaii','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('serranocatherine@watson.com','Timothy','Taylor','+1-967-175-0074x802','2619 Madeline Union','Apt. 686','Williamsonport','South Carolina','72181');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('potterjacqueline@yahoo.com','Brittany','Stewart','(300)261-1666x542','027 Morales Road Apt. 267','Suite 998','South John','California','98682');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tamara45@willis.com','Elizabeth','Hicks','8960901884','2261 Martinez Corner Suite 348','Apt. 609','Gibbsborough','Nevada','95038');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jasonlynn@gmail.com','Todd','Miller','(328)720-4774','748 Francis Park Suite 957','Suite 077','West Ianside','Michigan','39017');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bennettsarah@ferrell-barton.com','David','Francis','(700)260-9920x682','9099 Arnold Crossing Suite 055','Suite 414','Kellerbury','Texas','70961');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jacob52@johnson.com','Anna','Lawrence','5797125078','787 Murphy Expressway','Suite 140','Port Matthewhaven','Iowa','98021');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bestgabriel@valenzuela.com','Kelly','Taylor','265-604-1115x81837','694 Taylor Ramp','Suite 963','North Kevinfurt','Montana','94772');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kevin89@gmail.com','Danielle','Ware','+1-574-779-6869','74297 Charles Stravenue','Suite 369','South Markport','New Mexico','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pgray@kirk-buchanan.com','Samantha','Martin','001-821-281-1755x17887','6255 Waters Fords Suite 272','Apt. 992','Leebury','West Virginia','30987');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nbarton@jordan.info','Toni','Perez','+1-001-296-3695x44584','7638 Mcdaniel Lights Suite 087','Suite 798','Kevinfort','Delaware','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mwalsh@gmail.com','Carlos','Woods','001-263-539-2055x6258','4988 Lee View','Apt. 428','Clintonberg','Minnesota','90557');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christine30@yahoo.com','Eddie','Hodges','001-252-553-2093x27632','1255 Denise Island Apt. 672','Suite 458','Bernardfurt','Florida','48029');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('shanehamilton@yahoo.com','Matthew','Rios','734.069.3394','860 Raymond Summit','Suite 155','Kathleenville','Maine','19858');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hawkinsjustin@gmail.com','Laura','Koch','788-878-0636x808','473 Stacie Crossing Suite 055','Apt. 153','Port Susan','Iowa','56046');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cynthia49@davis-sellers.com','Katherine','Wright','359.450.8227x28045','471 Gary Mountain Apt. 626','Suite 030','South Elizabethland','Tennessee','72608');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rachelvargas@gmail.com','Anna','Gutierrez','(198)938-5057','6560 Wright Overpass','Suite 596','North Melissa','South Carolina','89857');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('thomasscott@hotmail.com','Nicholas','Baker','9029105483','7462 Oneill Islands Suite 350','Suite 344','Josetown','Florida','73118');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('victordominguez@armstrong-johnson.com','David','Pierce','584-882-8344x604','0420 Lisa Course Apt. 170','Apt. 663','West Randy','North Dakota','25308');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('owilliams@gmail.com','Hunter','Thomas','001-279-803-6960x4408','44661 Nguyen Shore','Suite 318','New Brian','Minnesota','96794');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kimchad@hotmail.com','Jessica','Mcneil','001-779-045-7595x0611','875 Wood Island Suite 080','Suite 839','Hernandezhaven','New York','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('aliciabrown@gmail.com','Travis','Martin','(593)256-6339','487 Hill Run','Suite 706','New Keith','Maine','48989');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('leenatalie@yahoo.com','Kayla','Ortiz','359-261-9503x037','49553 Pena River','Suite 594','South Bobbybury','Connecticut','29948');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('melissa81@charles.com','Marcus','Nelson','+1-870-024-1881x04962','1148 Duane Springs Suite 367','Apt. 059','Lake Melvin','Virginia','29877');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('coopercasey@gmail.com','Sarah','Perez','983.274.1326x26806','89110 Alexander Prairie','Apt. 092','Zacharyshire','Washington','29517');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stephen16@hotmail.com','Angela','Cisneros','+1-891-509-2353','27813 Joshua Estate Apt. 666','Apt. 760','Anthonyhaven','Alaska','06375');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ffaulkner@gmail.com','Chad','Harrison','766-771-2735x9367','634 Strickland Radial','Apt. 296','Lake Aaron','Wyoming','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('debbie82@hotmail.com','Tyler','Fields','+1-032-879-2517x4301','1076 Le Common','Apt. 477','Kimberlymouth','Nebraska','27252');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('youngdaniel@hotmail.com','Sheena','Larson','272.139.7109x374','559 Brooks Curve','Apt. 251','Williamstad','Pennsylvania','59086');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('russellcasey@alexander-johnson.com','Heather','Freeman','(208)323-5050','2125 Daniel Ports','Apt. 192','West Sean','Minnesota','27174');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fwells@yahoo.com','Megan','Whitehead','340-403-8831x94717','1828 Alex Fords','Apt. 070','Sherylport','Texas','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('craigrojas@richards.com','Richard','Bradshaw','804-601-4648x58154','8011 Megan Walks','Apt. 082','Gonzalesland','Alaska','89868');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('robertsonwilliam@mills-swanson.com','Lauren','Williams','001-021-291-0685x001','444 Ray Spring','Apt. 530','Deborahfurt','North Dakota','40397');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('david63@johnston.com','Ethan','Peterson','249.479.1248','11180 Owens Port','Apt. 977','West Alexanderside','Connecticut','96755');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('edwardjordan@english.com','Megan','Snyder','+1-575-069-7139x1274','4362 Kathleen Creek Apt. 335','Suite 883','North Colin','Washington','47321');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ibrown@yahoo.com','Grace','Garcia','+1-390-320-5171x710','075 Grant Falls Suite 238','Apt. 528','Lake Dominiquehaven','North Carolina','89146');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('linda11@gmail.com','Timothy','Barrett','926-451-5811x51938','569 Aaron Islands','Suite 932','Wolfton','Pennsylvania','39411');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rodriguezanita@hotmail.com','John','Shelton','387-988-2320x96535','32127 Douglas Shores','Apt. 279','West Jacquelinebury','Connecticut','19880');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fmiller@santiago-wright.com','Crystal','Chaney','+1-020-698-1344x76760','4194 Kathryn Field','Suite 050','New Lisaview','Wisconsin','96799');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('marieaguilar@hotmail.com','Jeremy','Lewis','443-091-9717x009','12505 Bobby Vista','Apt. 684','Mandyton','Michigan','73088');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jeffreyparsons@hotmail.com','Bridget','Lyons','001-009-676-5651x59657','3687 Ryan Rue Suite 416','Apt. 952','Jonesmouth','New Mexico','67863');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('spencerstephanie@bryant-bennett.com','Amanda','Kerr','755.294.3273x63115','9074 Thompson Squares','Apt. 650','Mayoville','Vermont','83874');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nelsonkenneth@chan-short.com','Lisa','Fox','115.115.7820','6681 Rebecca Orchard','Suite 017','Smithbury','Illinois','66943');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christopher05@alvarado.com','John','Walker','024.409.9193x98349','14962 Fox Landing Suite 789','Apt. 947','Huberton','Louisiana','19969');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('robersonchristopher@gmail.com','Heidi','Perez','001-553-493-6762x107','9194 Nicole Extension','Apt. 226','New Nancytown','Maine','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('duanewilliams@collins.net','Micheal','Peterson','001-121-200-6352x05585','8129 Smith Lakes Suite 846','Suite 597','West Hunter','Vermont','20032');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('abrown@martinez.org','Michael','Hansen','(511)687-0624','670 Laura Mountains','Apt. 599','North Joseph','Hawaii','31901');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('juan07@hotmail.com','Ethan','Reyes','(931)359-4836','16645 Nunez Square Suite 369','Suite 134','Johnsonstad','Hawaii','72422');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gloria95@mills.org','Christie','Butler','001-436-226-2410','6697 Ashley Plaza','Apt. 671','Lake Claudiabury','Oregon','83492');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('alex25@yahoo.com','Jennifer','Morales','610.375.5243x209','426 Hill Lights Suite 811','Suite 042','New Kathleen','Minnesota','16028');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('smorgan@yahoo.com','Frederick','Sanchez','(286)962-8851x0265','68186 Shannon Underpass','Apt. 694','Blakefort','Kentucky','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wyu@morris-carrillo.org','Alyssa','Green','291.777.8181x4678','0604 Gloria Points','Suite 535','North Daniel','Idaho','07030');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('andrewsmith@yahoo.com','Scott','Downs','8233440668','21682 Bishop Isle Suite 310','Suite 550','Markview','Oklahoma','20004');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('daisyavila@yahoo.com','Clayton','Irwin','(495)189-0027','514 Robert Knolls','Apt. 268','Jamesburgh','Colorado','43171');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('contrerasjames@gmail.com','Margaret','Smith','869-316-3067x877','7515 Joseph Road Apt. 732','Apt. 311','Lake Audreyfort','North Carolina','36399');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jason06@gmail.com','Amanda','Rice','001-739-648-4187x172','1359 Justin Harbor','Suite 655','Gutierrezshire','Massachusetts','50537');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bclark@gmail.com','Christine','Carroll','6309727580','5424 David Shoals Suite 850','Apt. 827','North Jeffreyland','Iowa','51000');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gonzalezbarbara@yahoo.com','Mercedes','Gonzalez','084.294.4716x0816','493 Cohen Tunnel Apt. 873','Apt. 820','Jacksonville','Washington','27414');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gonzalezdakota@roberson.com','Tracey','Stevenson','001-837-885-3442x73888','39637 Jerry Flat Apt. 946','Apt. 920','Hodgeshire','Oklahoma','26272');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('heathmonica@hotmail.com','Alan','Ford','524-268-9285x36585','7147 Ashley Parks','Suite 088','South Markland','Maine','40590');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('opittman@gmail.com','Amanda','Simmons','001-511-111-9987x1647','1256 Wright Unions Suite 214','Apt. 038','Port Marissaborough','Maryland','70027');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('aaronhill@hotmail.com','James','Johns','+1-592-034-5011x6605','3309 Kimberly Street','Suite 466','Cherryfort','South Dakota','27467');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ejohnson@morales.org','Laura','Cruz','095.489.8052','6586 Edward Motorway Apt. 571','Suite 208','Dorseymouth','Ohio','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kenneth51@yahoo.com','Brian','Oliver','001-051-970-0227x3082','963 Glenn Throughway Suite 363','Suite 629','West Jeffreyside','Maryland','99627');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nvillanueva@hotmail.com','Gregory','Carrillo','(609)948-4635','3916 Richmond Ferry Apt. 067','Suite 301','Karenton','California','94577');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hunterhebert@gmail.com','Charles','Larsen','790.167.0403x644','3160 Pearson Road','Suite 504','Nguyenbury','New York','16692');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vharrell@yahoo.com','Lauren','Kim','+1-476-142-8079','58643 Hernandez Point Suite 839','Apt. 323','Kirkfurt','Idaho','84378');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bryantcassandra@johnson-morales.com','Reginald','Walton','(368)849-4155x75197','142 Alexa Lakes','Suite 612','South Debraton','Iowa','64789');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hmclean@yahoo.com','Jared','Morgan','(166)480-8236','295 Munoz Bypass','Apt. 391','Stephaniefurt','Tennessee','64125');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('chavezemma@nelson-bailey.info','Deanna','Espinoza','+1-429-948-1115x04898','27493 Ibarra Trace','Apt. 248','Williamsbury','Wisconsin','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('woodselizabeth@ellis.com','Stanley','Cherry','(751)854-4017x5721','70646 Louis Path','Apt. 640','Johnview','New York','87593');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rosaleshailey@hotmail.com','Luis','Meyer','+1-898-681-8605x0786','54415 Miller Island','Apt. 375','Wayneport','New Hampshire','96867');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kristaharrison@hotmail.com','Tracy','Strong','(780)120-1490','86447 Zachary Meadow','Suite 006','Downsberg','Michigan','44615');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fpotter@johnson.com','David','Nixon','948-107-2915','08631 Marc Cape Suite 954','Apt. 586','Port Lindsey','Connecticut','02927');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('theresapitts@yahoo.com','David','Pena','668-528-6583x6904','704 Torres Meadows Apt. 602','Suite 572','Ronaldbury','Wisconsin','39365');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kennethwells@garcia.com','Daniel','Guerra','3712366089','784 Benitez Rapids','Suite 314','Simmonsshire','Florida','67184');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('xhernandez@yahoo.com','Phillip','Rivera','527.276.2919x24632','27416 Nicole Plains','Suite 205','Kyleside','Pennsylvania','26852');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('william31@yahoo.com','Brad','Thompson','910-564-3617','384 Nguyen Village Suite 649','Apt. 951','East Sierramouth','Colorado','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('andreakelley@gmail.com','Leslie','Moreno','391-988-5432','305 Mark Street Apt. 639','Apt. 115','Henrytown','Wisconsin','86402');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christopherkelly@hotmail.com','Heather','Roman','346-081-6370','493 Charles Square','Apt. 837','North Sierra','Colorado','71077');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ginawilson@gmail.com','Kara','Santiago','+1-742-508-8968x42194','6247 Odonnell Spur','Suite 205','Lake Amystad','Washington','57085');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('colleen65@hotmail.com','Shannon','Simpson','0622750928','6445 Brown Wells','Suite 695','Lake Curtis','Alabama','47360');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hhart@wright.net','Savannah','Smith','019-834-0754','587 Lisa Squares','Apt. 535','West Robert','Utah','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cynthia16@smith-singleton.net','Colton','Allen','292.827.9606x91620','6652 Jennifer Neck','Apt. 987','Taylorchester','New York','73139');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jeffreysmith@yahoo.com','Tina','Rodriguez','821-624-5678','3436 Natalie Neck','Apt. 274','North Matthewchester','Delaware','19742');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ellisjamie@hotmail.com','Tricia','Hodges','001-836-967-4655x8471','778 Lynn Road Suite 604','Suite 932','Hessland','Washington','05364');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('keithharris@hotmail.com','Teresa','Johnson','+1-222-888-9045','479 Juan Locks Suite 121','Suite 208','West Linda','Oregon','52578');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pfoster@armstrong.com','Christian','Jordan','458-725-8427x1449','918 Justin Valley','Apt. 712','New Stephen','Washington','68067');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('harrisrandy@watson.net','Paul','Logan','001-831-648-7983x497','411 Carey Glen Suite 062','Apt. 094','Merrittfort','New Mexico','20015');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ronaldnguyen@rivera.org','Andrew','Becker','2545153746','236 Nicole Fort','Suite 045','Lyonsstad','Nevada','86237');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joshualee@hotmail.com','Judy','Schneider','551-847-0550x2849','18915 Frank Center Apt. 825','Apt. 117','South Stephanieton','Tennessee','08368');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('zsmith@larson.com','David','Foster','001-340-899-8473','720 Seth Skyway','Apt. 109','Wilsonmouth','New York','68075');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('krystal57@hotmail.com','Roger','Moreno','190.758.6324x505','544 Stephanie Flats','Apt. 690','North Scott','Maryland','25155');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('aaron87@carter-anthony.com','Kelli','Davis','+1-825-280-5001x5538','89098 Friedman Lakes Suite 470','Apt. 693','Amandaside','Indiana','57622');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brittanymaxwell@brown.com','Alejandro','Ford','+1-301-618-7817','646 Nelson Flat','Suite 585','Payneborough','Minnesota','02786');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('susan25@hickman-perry.com','Karen','Clark','699.599.9638','927 Scott Courts','Suite 035','Brewerside','Oregon','43752');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jasonsimmons@morales.biz','Nicholas','Kelley','818-873-2730','8145 Hill Circle','Apt. 389','South Lauriestad','Utah','89323');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rwalker@hotmail.com','Lauren','Friedman','990-834-2722x8167','49146 Sara Divide','Suite 945','Jodifort','New Hampshire','18675');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gfreeman@hamilton-murphy.com','Sarah','Morales','(650)753-4752x422','0116 Macdonald Highway','Apt. 927','Sanchezchester','North Dakota','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('phillipsrobert@patel-ford.com','Matthew','Jackson','871.849.0590x1656','613 Ibarra Spurs Suite 671','Suite 885','North Caitlin','New Mexico','30659');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brooke23@yahoo.com','Donna','Perry','169.039.3708','1859 Bradley Lock','Apt. 803','Alexandraport','Utah','06325');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rogerslaura@gmail.com','Heather','Phillips','052.418.5066x820','65475 Elizabeth Crest','Suite 837','West Michele','West Virginia','20012');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('andrea14@yahoo.com','Ashley','Morris','001-867-732-4594x75780','875 Howe Turnpike Apt. 842','Apt. 199','Ramirezborough','New York','57019');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('thompsonamanda@weber-hebert.com','Melody','Patterson','503-520-2156','1833 Rangel Points Suite 616','Apt. 858','South Tonyatown','New Jersey','36245');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('susanfrost@miller.biz','Jose','Conner','(789)207-2088','0449 Mary Expressway','Apt. 576','Port Clarence','Missouri','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('yvetteallen@terrell.info','Andrew','Murphy','(737)646-5667x54068','4701 Alexander Dam Suite 965','Suite 718','Richardsontown','Connecticut','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kimberly56@green.net','Kenneth','Floyd','001-360-498-8766x1223','13146 Wise Wells Apt. 912','Apt. 635','Port Richard','Minnesota','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rebecca99@watson-bauer.org','Jordan','Brown','001-932-568-3003x32809','21196 Lauren Port Suite 745','Apt. 701','Choiborough','Arkansas','20036');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('robin07@yahoo.com','Steven','Coleman','217-005-7251','250 Lopez Causeway Apt. 912','Apt. 286','Port Sierra','North Carolina','68060');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brianoliver@elliott.org','John','Harvey','0494271155','94764 Crawford Centers Apt. 859','Apt. 165','Smithborough','Illinois','83259');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sandraweber@rocha-lawrence.biz','Walter','Grant','+1-699-401-9141x698','638 Fowler Crossing Apt. 088','Suite 852','South Kristenstad','Alaska','70910');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vstewart@sampson-weaver.com','Cory','Bryan','+1-810-415-1382x613','71448 Johnson Crest','Apt. 895','South Sandra','Georgia','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hayesbriana@gmail.com','Karen','Reid','(160)733-4292x656','805 Johnson Parks Apt. 332','Suite 121','Karenberg','Hawaii','36388');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hurstrose@hotmail.com','Michael','Jones','4322278228','493 Tamara Meadows Apt. 287','Suite 495','West Taylorland','North Carolina','86311');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('marysmith@beasley.com','Michelle','Carpenter','877.854.9280','459 Chung Inlet Apt. 661','Apt. 961','Lake Lisafurt','Connecticut','02822');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dennispalmer@yahoo.com','Jonathan','Moreno','+1-470-276-8836','985 Kevin Track','Suite 254','Rhodestown','California','58032');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('thale@yahoo.com','John','Brown','020.410.3250x95429','5195 Jones Overpass','Suite 886','Masseyport','Alaska','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('heatherhall@arroyo-martin.biz','Elizabeth','Scott','+1-794-641-3526x002','8185 Beverly Crossing Suite 045','Apt. 083','Lake Karen','Pennsylvania','71715');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mcclurealicia@yahoo.com','Destiny','Vasquez','418.765.3732','254 Daniel Mountain Apt. 680','Apt. 947','Jasonfort','Louisiana','85164');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('grayjamie@yahoo.com','Michael','Romero','7076264557','0055 Jennifer Mount Apt. 619','Suite 954','Derrickstad','West Virginia','82326');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('singletonann@huang-snyder.info','Ronald','Davies','(969)427-1600','67145 Tran Forks','Apt. 815','West Raymond','Michigan','41540');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('anna47@daniels.org','Scott','Webster','776.212.8394','77518 Amy Spring','Suite 320','Levineport','North Carolina','55495');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('uroberts@wright.com','Jennifer','Mullins','631-564-9703x10661','2932 Peter Junction Suite 152','Apt. 918','Pierceburgh','Maryland','38676');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sscott@williams.com','Andrew','Sandoval','155.801.6462x4119','66928 Kimberly Street','Apt. 875','East Russellport','Tennessee','98161');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('suzanne64@gardner.com','Emily','Nelson','001-593-076-4480x988','54270 Brown Burgs','Apt. 530','Port Angelica','New Hampshire','98201');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ruththomas@yahoo.com','Megan','Davis','7610727908','691 Martin Circles','Apt. 070','West Jonathan','Alabama','25055');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('danielle57@yahoo.com','Jennifer','Smith','+1-374-503-0667x160','671 Bell Villages Suite 462','Apt. 520','West Allison','Delaware','46574');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('trevor61@dillon.com','Brian','Weber','016.314.6990x54878','8303 Garcia Court Suite 022','Suite 607','East Jennifer','Mississippi','08539');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('shawngeorge@bailey-flynn.net','Michelle','Brown','892.708.7669x82275','64951 Stephanie Pike','Suite 152','Brightland','Delaware','37650');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hermankari@gmail.com','Christine','Parker','+1-505-935-6154x0714','047 Hobbs Bridge','Suite 136','West Mark','Arizona','06138');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('olsonsharon@holmes.com','Michele','Bishop','335.579.9628x5506','39692 Burke Well','Suite 911','East Christopherstad','Georgia','37823');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('alexander64@gmail.com','Tracey','Jones','1363975076','06719 Martin Court','Suite 093','Lake Jennifer','Idaho','38887');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lbell@gmail.com','Shelby','Robertson','+1-789-133-1336','9897 Hudson Lane','Apt. 105','Frenchberg','Utah','66504');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('othompson@fitzpatrick.info','Jeffrey','Jones','5779791315','52576 Sarah Curve Apt. 194','Suite 683','East Laurenborough','Alabama','61859');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('parkerbrett@mcintosh-krause.org','Krystal','Johnston','(777)014-2533x957','2528 Elizabeth Lakes Suite 755','Suite 240','Henrytown','Wyoming','68041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('parksblake@hotmail.com','Michelle','Gomez','001-954-197-6615x475','80957 Martin Port','Apt. 299','East Sergio','Louisiana','63677');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('richard99@soto.com','Carrie','Espinoza','+1-721-108-7021x765','61458 Baker Ridges Apt. 181','Suite 681','South Kaitlynburgh','Missouri','55517');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nbryant@yahoo.com','Alexander','French','451-314-0666x136','97847 Savannah Camp','Apt. 476','Brianastad','Arizona','70716');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jasonterrell@gmail.com','Trevor','Young','001-394-270-2885x0545','364 Scott Mount','Suite 675','Timothyburgh','Oklahoma','04991');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joshuawood@lewis.com','Oscar','Hernandez','001-761-832-2351x2142','58846 Evan Courts','Apt. 500','Meadowsview','Michigan','37764');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('amanda76@olsen.com','Sarah','Sanchez','629-867-1807x4911','897 Amy Springs Suite 908','Apt. 757','East John','Arizona','34261');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('alexis99@gordon.com','James','Anderson','001-192-925-3389','79386 Pamela Ford Apt. 330','Apt. 669','South Joshuaview','Idaho','42327');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('john09@newman.org','Aaron','Brown','289-967-4922','90412 Shelton Vista Apt. 313','Suite 863','Kathyport','Connecticut','54788');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lejonathan@riggs-griffith.net','Travis','Carney','121-183-9680x72500','68281 Joseph Views','Suite 856','Brianport','Michigan','38323');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('haileywright@parker-scott.com','Valerie','Smith','001-266-427-3613','480 Evelyn Hills Suite 145','Suite 643','Lamland','Wisconsin','02230');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ssmith@hotmail.com','Adam','Aguirre','001-840-936-9037x31821','215 Maria Forest Suite 571','Suite 461','New Lindaville','Utah','20001');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('charlesmorris@gmail.com','Linda','Hamilton','6099202266','279 Thompson Walk Suite 837','Suite 779','South Patriciaside','Maryland','27649');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('craigtucker@hotmail.com','Jason','Perkins','335-107-2425','7352 Smith Throughway Suite 565','Suite 222','East Yolanda','Texas','47759');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('masontina@wilson.com','Stephanie','Chase','067.461.0091x77461','080 Glass Road Suite 082','Apt. 270','East Christopherfurt','Connecticut','94171');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christina66@foster.biz','Briana','Gray','203-479-1165','227 Anthony Springs','Suite 671','East Tiffanyberg','Tennessee','33194');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('qbarnes@graham-buchanan.com','Lauren','Stevens','849-541-9611','3421 Morgan Skyway Suite 103','Apt. 354','Tranland','Pennsylvania','19175');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bondmelissa@yang.info','Leah','Bailey','871.279.3581x0557','227 Angela Plains Suite 284','Apt. 021','North Jamiemouth','Iowa','37075');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bernardscott@gmail.com','Cynthia','Conley','709-326-9711','200 Thomas Expressway Suite 836','Suite 498','East Tiffanybury','Mississippi','96768');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('blake97@gmail.com','Kelly','Wood','+1-221-253-5012x3274','591 Larry Well','Suite 121','Patriciatown','Indiana','71117');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ipierce@johnson.info','William','Martinez','(620)888-8667','581 Wilson Walk Apt. 727','Suite 612','North Stacy','Rhode Island','32213');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('qhall@yahoo.com','Laurie','Nichols','846.435.7488','1355 Charles Neck','Suite 376','Harristown','Ohio','32941');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('melissahorne@yahoo.com','Samantha','Wiley','598-672-8216','50811 Smith Mill','Apt. 277','Donnabury','Tennessee','56466');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('andreaandrews@gmail.com','Carol','Williams','495-793-9757x6029','583 Jesus Island Apt. 453','Suite 168','North Jasonview','Kansas','04920');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michaelacasey@hotmail.com','Erica','Livingston','392.517.7595x208','316 Anthony Ranch Suite 655','Apt. 607','Johnhaven','Oklahoma','82572');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rachelmartinez@horn-cantrell.info','Travis','Kelly','485.043.0536','03322 Christine Isle','Suite 399','New Colleenfort','New Hampshire','08020');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kevin88@hotmail.com','Christina','Rodriguez','(036)082-8746x693','9271 Hall Forks','Apt. 040','Williamschester','Oregon','58770');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lindafaulkner@clark-griffin.com','James','Smith','8834925480','77426 Bond Plaza Suite 410','Apt. 244','Cartermouth','Alabama','98739');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jeff34@wright.info','Judith','Thomas','9632095637','152 Williams Ways Apt. 650','Apt. 178','West Steven','Connecticut','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bowersantonio@edwards.net','Tara','Owen','+1-666-341-4441x40661','361 Brian Shoals Apt. 238','Suite 581','East Cassidy','New Jersey','57785');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tfaulkner@yahoo.com','Rachael','Rodriguez','001-971-882-3694x9291','8812 Andrew Crescent Apt. 712','Suite 029','Schroederfort','New Mexico','95526');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ugarcia@oconnell.info','Heather','Mayo','+1-942-119-5025','23865 David Isle','Apt. 699','Garytown','Maryland','97543');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('leeisaiah@yahoo.com','James','Fields','200.069.3985x54818','207 John Plains Apt. 616','Apt. 454','Port Lori','Utah','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('santosjeffrey@carter.biz','Michael','Suarez','7136961273','92556 Green Loop','Apt. 840','South April','California','05448');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('carpenterstephen@hotmail.com','Bradley','Leach','050.925.0196x18089','184 Jonathan Path','Suite 278','Ericside','Montana','02902');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('arnoldhelen@yahoo.com','Adam','Thompson','(991)179-9537','976 Mathew Club Suite 248','Suite 938','Valdezshire','Oregon','45132');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gonzalezamy@allison.org','Daniel','Sullivan','890-951-4899','6926 Martinez Lodge','Apt. 709','South Lindastad','Wisconsin','58768');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('weberpamela@hotmail.com','Monica','Fisher','(292)508-0908','46184 Michael Camp Apt. 063','Suite 361','Rebeccafort','Massachusetts','85209');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnprice@gmail.com','Charles','Diaz','3329117353','64908 Joseph Pine','Apt. 589','East Nataliemouth','Wisconsin','98124');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('williamskevin@gmail.com','Daniel','Williams','150-496-6658x727','9606 Jenny Landing','Suite 440','West Kimberly','Massachusetts','52177');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kimmelissa@gmail.com','Michael','Ramirez','957.414.0016','523 Martinez Way','Suite 063','Analand','Maine','99524');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cmoore@gmail.com','Amber','Patterson','483-740-4332x0056','246 Moss Divide Apt. 182','Apt. 755','Port Laura','Massachusetts','57144');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jenningserica@hotmail.com','Andrew','Johnson','583.612.7946','55137 Parks Ways','Apt. 976','Acostafurt','Montana','98693');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('donna16@hotmail.com','Heather','Davis','(257)883-5448','5760 Christy Manors Apt. 722','Suite 708','Christopherbury','Minnesota','31955');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('georgechristopher@gmail.com','Patrick','Ramirez','(652)980-1836','975 Ana Isle Suite 975','Apt. 679','Alexandraside','West Virginia','58554');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('williamsclifford@martin.org','Erin','Myers','(210)967-9729x7267','5978 Schwartz Squares','Suite 058','East Maryburgh','Georgia','04648');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('osmith@hotmail.com','Peter','Diaz','8173850053','3638 Lopez Union Apt. 372','Apt. 096','Farrelltown','Vermont','19820');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pbrown@johnson-vasquez.com','Renee','Blevins','590.039.7632','7524 Jessica Coves','Suite 156','South Marcustown','Iowa','20011');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wtaylor@smith.biz','Samantha','Campbell','938-138-0511x5446','3982 Brian Fort','Suite 224','North Josephmouth','Idaho','71189');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('james05@hotmail.com','Mitchell','Ramos','(619)108-3143','910 Nicholas Club Suite 714','Apt. 940','North Annburgh','Idaho','68047');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pricejose@robinson.com','Roger','Jackson','514.154.9065x3232','960 Adams Corner Apt. 898','Suite 813','Port Stephenborough','Kansas','35826');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wesley48@gmail.com','Julie','Gray','544-709-1810','632 Harper Islands Apt. 255','Suite 486','New Justinberg','Colorado','99859');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rmccormick@dixon.biz','Ashley','Douglas','+1-519-826-5289x6162','7607 Mcpherson Ridges','Apt. 365','South Michael','Delaware','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jcarney@hotmail.com','Emily','Campbell','9123707080','246 Sanders Unions Suite 480','Suite 866','Vargastown','Idaho','95650');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jonesjade@hunt-thomas.com','Patricia','Greene','895.684.5985x295','5812 Reed Turnpike Apt. 771','Apt. 858','Lukemouth','Illinois','04731');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('chadhawkins@yahoo.com','Anthony','Morales','(056)854-5791','97326 Kevin Meadow','Suite 340','West Matthewside','Idaho','82693');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('steven31@gmail.com','Jo','Sharp','817-174-4563','270 Matthew Knolls Apt. 072','Suite 848','West Harry','Idaho','34904');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('robertparrish@gmail.com','Paula','Graham','001-688-456-2181','413 Welch Meadow','Apt. 425','Edwardstad','South Dakota','50700');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('audrey74@yahoo.com','Robert','Nguyen','+1-589-794-2612x398','286 Richmond Pine Apt. 859','Suite 693','Allenhaven','Arkansas','88313');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gina19@yahoo.com','Megan','Atkinson','+1-124-283-7895','6870 Andrea Motorway','Apt. 015','Lake Alexander','Idaho','29608');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mark68@fritz-cooper.net','John','Cole','7639874670','8101 Michael Turnpike','Apt. 361','Lake Kelly','Illinois','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('larsonsarah@ward.com','John','Rogers','001-553-240-0230','535 Ward Crescent','Suite 665','East Brianville','Maine','80551');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vgonzalez@sullivan.net','Ashley','Williams','048-212-7021','29589 Watkins Grove','Suite 586','New Bryan','Pennsylvania','99605');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('margaret73@gmail.com','Nathan','Smith','068-736-4841x669','032 Casey Knoll Suite 590','Suite 410','Port Heathertown','New Mexico','07815');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('normanaustin@jackson-villanueva.com','Heather','Hodges','+1-111-463-6298','2746 Taylor Wall Suite 480','Suite 801','East Meganshire','Oklahoma','04330');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gina40@hotmail.com','Benjamin','Proctor','(719)734-0449','4789 Morgan Street Apt. 648','Apt. 793','East Justin','Michigan','49378');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bcompton@miller.com','Andrea','Williams','829-643-4556x2099','78728 Karen View Apt. 458','Apt. 775','Lake Jennifermouth','Kansas','55094');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vmccullough@hotmail.com','Thomas','Hardin','001-669-022-3002x757','158 Cline Mountains Apt. 050','Suite 264','Reedview','New Hampshire','03731');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wilsonsamantha@yahoo.com','Anne','Sanchez','001-068-051-1545x422','43880 Williams Club Apt. 543','Apt. 499','Valeriefurt','New Jersey','41576');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('webbmicheal@mack-pennington.com','David','Moore','136-076-5239x3697','89164 Jessica Street Suite 554','Apt. 734','New Gabrielle','Arizona','41927');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('haleyjohnson@yahoo.com','Michele','Stephenson','305.463.4617','208 Fowler Avenue Suite 909','Apt. 923','West Andreamouth','Arkansas','47488');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('uhernandez@hotmail.com','Taylor','Garcia','391.760.7127','149 Nichols Mountain Suite 914','Apt. 885','Natalieside','Kansas','46300');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('robert40@yahoo.com','Brian','Young','(863)508-0946x1379','41144 Anthony Rapid Suite 359','Suite 420','South Sandrafort','Iowa','18368');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ggarza@gonzalez.com','Suzanne','Walker','642.488.2534x4174','326 Swanson Grove Apt. 753','Suite 845','Grossshire','Wisconsin','97767');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bellmichael@farmer.biz','Bryan','Benitez','001-670-900-6829x547','4014 Moore Park','Apt. 982','West Donna','Idaho','83800');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hartmichele@reyes.com','David','Franklin','(560)452-2390x4101','1988 Stephen Divide','Apt. 648','North Marybury','Washington','47523');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sarahrodriguez@knapp.com','Janice','Schneider','685.744.2831','34570 Alvarez Center Apt. 458','Apt. 537','Robertchester','Arizona','56217');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('alicia64@yahoo.com','Joshua','Thomas','001-186-155-1606x8706','981 Johnson Forks','Apt. 036','Michaelville','Massachusetts','89877');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('llee@white.net','Chase','Fitzgerald','265-929-7616','209 Smith Rapid Apt. 634','Suite 200','East Michael','Indiana','89351');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ppatel@cervantes-williams.com','Diana','Robertson','(353)609-8349x55802','0837 Kaiser Points Suite 628','Apt. 558','Kariview','North Carolina','56499');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lisa04@hotmail.com','Joshua','Perez','(357)195-9812','79598 Lindsey Walks','Suite 406','Christinefort','Iowa','33386');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('evelynclark@yahoo.com','Travis','Anderson','(306)498-1268x516','2150 Shaw Shoals Apt. 567','Apt. 953','Port Emilytown','California','83846');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lisatucker@yahoo.com','Ruth','Walters','001-340-041-3714x8710','2729 Austin Fork','Apt. 195','Lisaview','Georgia','29606');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lori97@acosta-glass.org','Rachel','Sanders','817.181.1652','18872 Gardner Rue','Suite 512','New Bobbyberg','Arizona','66461');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kendrathompson@mitchell.com','Mary','Acevedo','5320044940','6017 Walsh Locks Apt. 918','Apt. 057','New Tonya','Hawaii','89585');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('warerobert@chase-jones.com','Evelyn','Sloan','862.992.9207x557','74749 Glenn Fall','Suite 447','Nathanielport','North Carolina','03551');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kaylasandoval@gmail.com','Vicki','Lozano','632-507-9403x2146','31353 Aguilar Gateway','Suite 145','Kimberlyborough','Alaska','07989');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pauleric@gmail.com','Lisa','Chambers','+1-044-050-6424x174','80939 Steven Shoal','Apt. 068','Griffithchester','Nevada','72825');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('caitlinlee@yahoo.com','Tony','Nash','6142742782','10671 Nicholson Ridges','Suite 238','Chavezhaven','Washington','08569');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lisadavis@wilkinson-brown.net','Theresa','Clark','(910)771-2421x52565','116 Gray Village','Apt. 747','Smithton','Arkansas','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('omaynard@mosley-reynolds.com','Donna','Hoffman','406-309-0959x8166','835 Elizabeth Oval','Suite 429','North Rebecca','New Hampshire','68056');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('yavery@barnett.biz','Jenna','Brooks','242.969.6232x9972','14865 Eduardo Expressway','Suite 158','Mitchellbury','Mississippi','62956');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('orasmussen@hotmail.com','Jeremy','Burgess','+1-931-307-3966','80218 Katelyn Mountains','Apt. 020','West Angela','Missouri','83874');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christopher22@chan.net','Amy','Brown','759-832-1130','24115 Turner Run','Suite 276','Lake Amanda','Maine','82114');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('areid@marks-lucero.org','Scott','Davis','654.807.6791x166','42858 Shawn Row','Apt. 640','Hudsonville','Wyoming','46399');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bestmarisa@hotmail.com','Gerald','Pena','943-994-2839','5282 Fernandez View','Suite 791','Crawfordport','Massachusetts','47371');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nathaniel18@hotmail.com','Ricky','Johnson','001-209-502-8635x8624','146 Benjamin Ridge','Apt. 800','Wallaceberg','Georgia','99863');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('danielletate@wilson.biz','Andrea','Burke','097-674-5810x12606','0404 Cody Drives','Suite 968','East Suzanne','Rhode Island','97826');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('burnsdominic@hotmail.com','Monique','Wilson','001-463-219-6266x696','5940 Simon Field','Apt. 610','Hartbury','Massachusetts','86296');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hcollins@gmail.com','Jenna','Lewis','623.881.7268x822','31802 Alvarado Curve Suite 455','Apt. 880','Leemouth','Iowa','82414');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brownnicholas@gmail.com','Lindsey','Smith','030-407-1407x1172','362 Clark Glens','Suite 643','Port Dennis','Arizona','99354');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('diamond28@hotmail.com','Donna','Nguyen','(976)521-1611','940 Morales Neck','Suite 689','West Ginastad','Mississippi','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('garrisonrichard@nash.com','Jose','Parker','461.325.3365','323 Young Coves Suite 715','Suite 612','New Josephburgh','Virginia','39690');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('heathersmith@rice.com','Lisa','Roy','001-333-057-2892x276','58451 Edward Pass','Suite 695','Mariabury','Ohio','91420');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pamelamills@gmail.com','Adam','Hernandez','310-869-3493x7523','67506 Martinez Pass Apt. 844','Apt. 206','Fullerborough','New Mexico','52793');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('patriciabyrd@gmail.com','Stephanie','Davidson','775-390-2754x06489','720 Long Manors','Apt. 243','Aaronmouth','Ohio','84235');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('garycarter@smith-robinson.info','Elizabeth','Carter','277-829-7432x4859','21054 Barbara Villages Apt. 996','Suite 076','Gregoryfurt','Pennsylvania','55599');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pcampbell@owens.com','Cassandra','West','407.259.2490x94434','56660 Ramirez Union','Suite 813','Mitchellport','Indiana','19859');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('veronica40@benton.info','Scott','Martinez','+1-144-886-4564x3995','732 Austin Greens Apt. 581','Apt. 811','Port Danielleport','North Dakota','89667');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cantuchristopher@gmail.com','Craig','Young','787.554.0917x84688','6265 Jennifer Spring Apt. 020','Apt. 696','South Daniel','Minnesota','85517');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('taylordennis@shaw.biz','Tanya','Parker','001-058-297-8646x52779','22500 Tony Vista Apt. 714','Suite 788','North Travis','Delaware','64137');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('penny37@hotmail.com','Kelly','Hall','001-441-258-1848x856','9985 Hahn Stream','Suite 052','Paulamouth','New York','50911');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('luisrichmond@cortez.org','Charles','Fernandez','001-026-798-4557x02681','21297 Douglas Heights','Suite 823','Lauriemouth','South Carolina','54303');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rhondawaller@mercado-graham.com','Beverly','Patel','(512)064-3370','715 Andrea Crest','Apt. 176','Ramirezville','Arkansas','28560');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('aimee38@taylor.com','Michael','Cobb','+1-577-422-5014x7529','49234 Phillips Road','Apt. 591','West Jamestown','Illinois','84616');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('qclark@hotmail.com','Teresa','Munoz','001-012-804-4432','87272 Amanda Squares Apt. 302','Apt. 593','North Nicolechester','Iowa','70189');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vsmith@gmail.com','Kaitlin','White','(413)974-3987','57870 Daniel Glen Suite 981','Apt. 794','East Ashleyview','Maine','87561');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('amandaparker@bender.org','Nicholas','Burke','+1-039-037-0321x39199','6034 Trevor Springs Apt. 695','Suite 100','New Dustin','Delaware','01296');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('morganvargas@yahoo.com','Phillip','Morgan','8361052143','70133 Garrett Junction','Suite 410','Port Curtis','Wisconsin','03221');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vbaker@hotmail.com','Kathryn','Rodgers','298.696.9126x63862','387 Jasmine Meadows Suite 232','Apt. 516','New Ronniefort','Missouri','81567');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cobbjennifer@hotmail.com','Aaron','Duncan','072.030.8921','230 Cynthia Plain Suite 521','Apt. 146','Gregoryburgh','Oregon','15469');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tgray@morris-fletcher.com','Anthony','Sandoval','001-286-902-1967x741','3822 Powell Green Apt. 701','Apt. 272','Reginamouth','Michigan','27370');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnsonsarah@hotmail.com','Keith','Reynolds','6818800442','935 Benson Locks Apt. 468','Apt. 984','Port Jennifer','Idaho','33560');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mhall@mueller.com','Robert','Barnes','001-743-344-7272x5671','5680 Ryan Trail','Apt. 982','Allenmouth','Vermont','82755');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cory65@hotmail.com','Gregory','Lewis','813.070.6207x09449','3592 Mary Groves Apt. 814','Suite 175','South Sarahhaven','Colorado','64220');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fthompson@yahoo.com','Tim','Montes','(536)282-9227x0174','24960 Sandra Key','Apt. 539','New Melissaton','Hawaii','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('laurajordan@hotmail.com','Eric','Williams','(313)692-7408x2007','9008 Patricia Shoals','Suite 178','Lake Jameston','South Carolina','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('melissa36@yahoo.com','Brett','Petty','911.568.0330','8562 Zachary Island','Apt. 585','Collinsview','Georgia','40709');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rpineda@bridges-wilkinson.org','Dawn','Keller','(136)392-2259x97775','7503 Nicole Shoals','Apt. 538','South Brian','Iowa','20016');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lanceriley@hotmail.com','Margaret','Townsend','529-232-3242x166','7303 Edward Stream','Apt. 917','Brianmouth','Pennsylvania','71984');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('carla08@stewart.com','Sharon','Chang','641-084-7152','92769 Dean Burgs Suite 327','Suite 341','Marcview','Virginia','50728');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lisa57@miller.com','Laurie','Pope','+1-222-064-2085x0564','87251 Diaz Branch Apt. 849','Apt. 734','Lake Johnbury','South Carolina','58279');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ericafarley@brandt.com','Kevin','Smith','001-899-646-6597x91874','070 Michael Square Apt. 901','Apt. 732','Port Robert','Alaska','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pattersoneric@hotmail.com','Jon','Morrison','7443443602','91785 Hannah Ferry','Suite 411','South Douglastown','Rhode Island','84381');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('watershenry@yahoo.com','Patrick','Patrick','556.865.8791x2368','9916 Rich Common','Suite 448','Port Williamfurt','Pennsylvania','80055');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('latasha93@hotmail.com','Mary','Webb','125-755-4823x206','51156 Smith Squares','Apt. 369','West Jonathanshire','North Carolina','02901');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mcintoshshaun@johnson.com','Mary','Zimmerman','(875)747-3279x0849','386 David Overpass','Suite 405','North Darlene','Indiana','96740');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kimberlysavage@logan.org','Andrew','Howard','(682)974-6249x41115','4104 Alan Turnpike','Apt. 051','South Williamside','South Carolina','29217');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kandersen@anderson.com','Dean','Brewer','504-253-8150x154','57465 Mcbride Oval','Apt. 345','Santosside','New Jersey','31776');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brandon19@gmail.com','Edwin','Moore','001-807-100-8260x07311','831 House Skyway','Suite 900','West Beth','Massachusetts','84007');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pacejose@hotmail.com','Maria','Edwards','(110)086-2872x0447','47088 Rogers Cape','Apt. 985','Jessicaville','Wyoming','57694');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('danielle40@hotmail.com','Cristian','Barker','7544210076','4582 Karen Mill Suite 666','Apt. 393','Hernandezmouth','Connecticut','99923');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('esmith@hotmail.com','James','Coffey','001-704-745-0710','2688 Jackie Turnpike','Suite 782','Woodfurt','New Jersey','96726');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dsampson@yahoo.com','Victoria','Potter','768-788-9279x256','688 Jack Cape Suite 737','Apt. 472','East Deborahfurt','Alaska','38509');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lindsay25@hotmail.com','Mary','Rodriguez','867.898.8004','87311 Natalie Streets Apt. 315','Apt. 574','North David','Vermont','34037');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michele85@yahoo.com','Kari','Stein','(618)890-4039x67513','9683 Murphy Circle','Suite 454','West Tonya','Michigan','56563');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('valeriecosta@ferguson-russell.info','William','Thompson','2569947422','19591 Anderson Common','Apt. 525','West Mindyport','Tennessee','32419');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('amichael@yahoo.com','Robert','Rangel','518-912-1157','2711 Samantha Ramp Apt. 974','Suite 405','West Stevenburgh','South Dakota','42754');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('riverajeffrey@yahoo.com','Carl','Cortez','(174)679-5804x96326','7480 Howard Meadows','Apt. 012','North Angela','Colorado','54568');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sowen@yahoo.com','Gary','Peters','001-875-158-0491x174','349 Ray Alley Apt. 690','Suite 508','Foxport','New Jersey','29440');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('renee69@yahoo.com','David','Wright','030.239.6879x2207','8598 Miles Corner','Apt. 758','South Rachelchester','Connecticut','07013');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michaelcook@miller-washington.com','Courtney','Jones','882.198.8331','89522 Caitlin Shore Apt. 605','Apt. 117','New Daniel','Florida','53480');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sguerra@yahoo.com','Jason','Martin','3455794673','6116 Butler Court','Suite 555','Katherinebury','Wisconsin','29371');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('williamaustin@yahoo.com','Timothy','Clay','913-959-5525','489 Barber Groves Apt. 201','Suite 092','Port Karen','Kansas','87887');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lroth@hotmail.com','John','Perkins','+1-200-767-7599x531','59338 Brittany Extension','Apt. 661','Dixonland','Texas','28365');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('smithtravis@pham.com','Olivia','Smith','052-057-7715','315 Smith Crossroad','Apt. 359','New Linda','Mississippi','84336');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('allentina@yahoo.com','Stephanie','Warren','+1-838-630-8091x01399','567 Emma Ways','Apt. 492','North Kathryn','Maryland','62238');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('williamsbarbara@gmail.com','Monica','Townsend','6528211495','480 Felicia Squares','Suite 634','South Shelby','Alaska','32183');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nicole33@gmail.com','Jose','Harrison','001-971-451-1892x909','53936 Michael Springs','Apt. 563','Port Laurenstad','Tennessee','04406');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('charvey@velez.com','Todd','Brown','(051)726-2658','4370 Marsh Garden','Apt. 666','Blakeshire','West Virginia','25831');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('noblemonica@wolfe.com','Paul','Nelson','001-640-855-3699x8268','79471 Myers Key','Suite 368','Port Erica','Tennessee','96842');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('qlewis@yahoo.com','Katherine','Austin','875.858.5830','1729 Casey Hill Suite 508','Apt. 238','Nixonburgh','Idaho','19889');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jsexton@hotmail.com','Amy','Flores','480-458-2764','75056 Michael Canyon Suite 952','Apt. 247','Nathanside','Connecticut','31945');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('geralddavis@morrison.org','Carrie','Robinson','(000)166-8505','68948 Simpson Prairie Suite 086','Apt. 209','Briantown','Wisconsin','96780');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('floresryan@james.com','Victoria','Mayer','512-183-5020x6136','7786 Douglas Inlet','Suite 503','Lake Morganport','Ohio','02848');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stephanie49@gmail.com','Justin','Jacobson','(215)507-1766x681','432 Wallace Estate','Suite 136','Perezhaven','Montana','30642');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gerald29@kaiser-white.biz','Stephanie','Case','637.176.9811x236','9857 Smith Rapid','Suite 508','Lake Mark','South Carolina','08213');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('thomas02@mejia.info','Toni','Miller','706-026-8220','550 Jerry Spur Suite 445','Apt. 980','Port Daniel','Vermont','29720');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fosterjason@wilson.net','Sara','Richardson','+1-418-239-8985x469','21254 Wheeler Forge','Suite 952','Port Richardtown','Kentucky','20032');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tiffanyluna@yahoo.com','Jacob','Johnson','3655416048','10377 David Square Suite 660','Suite 555','Nicoleshire','New Mexico','19757');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('karen36@hicks.info','Cindy','Bryant','(264)683-0055x5900','9497 Rebecca Prairie Suite 267','Apt. 648','Garciaberg','Alabama','06014');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jonesjennifer@ortiz.org','Michelle','Montgomery','238.565.7646x05982','03631 Gray Street','Suite 361','Port Tannerside','Indiana','58044');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michellelopez@roberts.com','Tracey','Parks','1144807804','570 Sherman Flats','Apt. 935','Lake Stephanie','New Jersey','64842');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ecox@hotmail.com','Jessica','Weeks','319-458-9020x0196','2412 Long Avenue Suite 207','Apt. 066','Dawsonport','Louisiana','30772');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('davidramos@alexander.com','Maria','Murphy','(724)661-1893x49162','06059 Collins Course','Apt. 140','Hamiltonfort','Mississippi','98327');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fieldslynn@hotmail.com','Kirsten','Adams','(721)362-0290x120','8953 Ryan Burgs','Apt. 997','North Chloestad','Oregon','64220');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('xscott@hotmail.com','Parker','Sexton','(089)381-5696x2823','265 Suzanne Mission','Apt. 872','West Davidfort','Indiana','49590');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('morrowsusan@davis.com','Christopher','Andrews','(904)496-0522','790 Kelly Drives Suite 328','Suite 868','South Curtis','Hawaii','07734');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('laurencross@gmail.com','Ronald','Tate','510.048.6438','44958 Long Drives','Suite 110','Hernandezburgh','Alabama','25840');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('marisawilson@lee-murphy.info','Daniel','Young','935-823-6912','71777 Jennifer Oval Apt. 158','Apt. 368','Garzashire','Colorado','39178');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joshuaflores@johnson-wade.com','Daniel','Blanchard','+1-311-687-1079x278','46469 Jermaine Roads','Suite 626','Port Ashley','Montana','19948');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('steven10@pham-jackson.com','Diane','Cochran','152.754.9669','033 Gomez Island Apt. 908','Suite 397','New Peterton','Vermont','05168');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('william37@phillips.biz','Manuel','Beard','001-988-220-0427x41257','910 Castro Corner Suite 705','Suite 532','Jeffreyshire','Wisconsin','67605');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('iodom@yahoo.com','Adrienne','Cannon','6191279265','205 Graham Curve Suite 240','Apt. 769','Port Stephanieshire','Michigan','06240');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dillondaniel@hotmail.com','Kelly','Whitney','(479)697-1534','366 Bryant Freeway','Apt. 305','Stephenside','Maryland','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('drivers@gmail.com','Taylor','Heath','001-717-673-2573x0842','06197 Scott Green','Apt. 921','New Kristinland','Kentucky','97539');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mary75@anderson.com','Clinton','Smith','380-162-0742','49309 Jenkins Glen','Apt. 410','Wendymouth','Rhode Island','82816');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mporter@thompson-graves.net','Paul','Ramirez','(500)506-1285x3270','05336 Phillip Dale Suite 341','Suite 894','Stevensstad','Kansas','68016');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('robertsonerin@watson.org','Jim','Jackson','001-878-461-6404','118 Diane Via Suite 812','Apt. 310','Simmonsstad','Kentucky','38796');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brianna58@gmail.com','Jermaine','Flynn','(810)945-9610x2565','60536 Austin Loop','Apt. 374','North Katherineland','Wyoming','90181');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('zharris@hotmail.com','Christina','Vega','001-124-570-9850x55567','77813 Patrick Road Apt. 295','Suite 607','Gutierreztown','Louisiana','84119');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('deborah37@taylor.info','Kimberly','Espinoza','(167)114-4842','7325 Jamie Spring','Apt. 566','Penningtonshire','Arizona','89240');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('anthonyherrera@reed-castro.com','Richard','Hawkins','828.065.3825x69936','367 Paul Drives Suite 679','Apt. 682','North Allisonport','Utah','97766');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kevin61@gmail.com','Jennifer','Moore','766-016-9715','8631 Thomas Port','Suite 757','Port Kevinport','Nebraska','48832');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vjones@lewis.com','Joseph','Jones','110.440.1039x1644','8747 Matthew Roads Suite 040','Suite 662','North Nicole','Nevada','02891');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ericsuarez@day.com','Robin','Erickson','(365)455-2825x354','5851 Sutton Corner Suite 971','Apt. 197','Lake Sherrybury','Iowa','29427');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('danielmartinez@hotmail.com','Jennifer','Rodriguez','374.935.1984x41260','095 Cheryl Wall Suite 311','Suite 609','Rebeccaview','Washington','15754');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pbrowning@hotmail.com','Elizabeth','Davis','401-561-4052x8696','3628 Lloyd Isle Suite 030','Suite 521','North Marystad','Wyoming','60378');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pollardscott@yahoo.com','Jason','Hamilton','904-426-4988x616','70033 Garcia Inlet Suite 852','Apt. 310','Conleyhaven','Kansas','63744');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mariamiller@nunez.net','Jessica','Bell','490.270.9241x85208','17058 John Expressway Suite 160','Suite 963','Smithview','Kansas','04528');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('paulscott@hotmail.com','Anna','Thompson','184-633-8740x0963','8085 Allen Trace Apt. 595','Apt. 373','Port Nicholasfurt','Ohio','96791');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fhunter@hotmail.com','Mitchell','Moon','726.592.2481x12019','141 Johnson Crest Apt. 851','Apt. 322','Fergusonbury','New Mexico','90241');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jasonhall@hotmail.com','Samantha','Olson','226-959-7588x849','1471 Rivas Ports','Apt. 283','East Connieberg','Massachusetts','84060');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ashley43@barker-marsh.com','David','Lowe','826-553-6511x837','7468 Sanford Terrace','Apt. 744','Bradleystad','Maine','85294');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('osantos@williams.com','Michael','Simpson','754-145-1651x196','25112 Kristen Burg','Suite 731','New Tammy','West Virginia','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('whoward@yahoo.com','Eric','Conway','+1-802-099-1870x88537','2398 Evan Field Suite 196','Suite 391','Jeanettemouth','Kansas','29377');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sabbott@nash.com','Elizabeth','Barnes','+1-946-301-2591x6763','982 Lewis Tunnel Suite 730','Apt. 345','Kristinburgh','Wyoming','55696');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('abrooks@campbell-munoz.com','Lisa','Bradley','(375)608-8880x1309','67796 Eric Fork','Apt. 766','Lake Adriana','Nevada','66424');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('taylormelton@hotmail.com','Megan','Robertson','+1-765-814-3060x171','91611 Gaines Summit Suite 771','Suite 301','East Maryburgh','Georgia','26033');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tayloredward@gmail.com','Todd','Anderson','+1-449-924-4079x32231','3946 Richards Station Apt. 581','Suite 820','North Adrian','Wyoming','99712');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jamesgutierrez@gmail.com','Jacqueline','Byrd','264.392.1918x1241','3728 Martin Lock Apt. 731','Apt. 496','North Mark','Connecticut','15033');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ndixon@castaneda-lewis.com','Julie','Walters','974-550-1878','275 Hampton Oval','Suite 027','Port Juliaborough','Illinois','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('donna54@alvarez.com','Jeffrey','Henry','+1-151-216-7877x46974','75815 Boyer Falls Suite 252','Apt. 918','Jeffreyburgh','Rhode Island','55186');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bianca28@stewart-mccann.com','Sandra','Hanna','8972513539','6777 Brad Dale Suite 959','Apt. 552','Taylormouth','Georgia','84722');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('liunicholas@mason.net','Rachel','Black','001-895-341-7465','84504 Stewart Wells','Suite 310','Lake Jenniferton','Maryland','19199');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('meganjuarez@hotmail.com','Johnny','Kline','281-722-6123x2620','9003 Shawn Field','Apt. 281','Lake Timothy','Arkansas','04267');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ashleylittle@yahoo.com','Frederick','Cooke','+1-335-901-1096x5297','71603 Garcia Locks','Apt. 469','Dakotaburgh','Hawaii','29481');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('laurenhartman@lane-barnett.com','Sherry','Gomez','+1-542-774-4153','56354 Mandy Avenue Suite 591','Suite 108','New Brianborough','North Carolina','91738');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sara74@yahoo.com','Zoe','Anderson','(377)808-7660x865','401 Michelle Wall','Apt. 927','Rachelbury','Nebraska','99661');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('richard65@gmail.com','Jose','Edwards','001-661-025-3165x13666','02894 Gregory Summit','Suite 768','Laurahaven','Connecticut','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('joshualopez@booth.info','Morgan','Watkins','001-958-925-2951x667','808 Barnes Cliff Suite 867','Apt. 738','South Christopherville','California','25488');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kelly77@rodriguez.com','Marie','Welch','4274490039','968 Joel Meadows Apt. 478','Apt. 329','Port Zachary','North Dakota','19224');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('deborahpotts@cook.biz','Barry','Hayes','(633)359-5997','7006 George Ford Apt. 305','Suite 404','East Rebecca','Nebraska','63351');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('eric79@goodman-rollins.com','Justin','Smith','830.028.1776x203','9622 Jason Tunnel Apt. 436','Apt. 205','East Sarah','Louisiana','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nyoung@gmail.com','Raymond','Duncan','985.542.7452','31492 Walsh Cove Apt. 314','Suite 680','Myersborough','Iowa','49349');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('susancarr@yahoo.com','James','Gonzales','422-223-8125x005','69395 Gardner Pine','Apt. 165','South Ronaldchester','Louisiana','56023');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pfox@rodriguez.net','Paul','Hicks','(863)411-0089x81213','147 Antonio Oval','Apt. 735','Bobfort','Maine','72798');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kevin99@reeves-cunningham.com','Erica','Spencer','172.617.2963x1896','2289 Anthony Lakes Suite 439','Apt. 388','Jessicashire','Colorado','29501');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tkerr@smith.com','Donald','Moss','624-800-7445','61570 Acosta Crescent','Apt. 669','New Gregory','Indiana','36621');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jamesdavis@hotmail.com','Summer','Anderson','(899)311-1373','444 Howell Run','Suite 106','South Michaelborough','Florida','59087');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('njordan@hotmail.com','Lisa','Boone','(271)185-3387x530','11686 David Neck Apt. 233','Apt. 073','Lake Jenniferburgh','Wisconsin','67563');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('paynestephanie@doyle.info','Christina','Russell','123.031.8614x679','24747 Sullivan Hollow Apt. 977','Apt. 909','Port Steven','Montana','97218');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sandra83@barrera-payne.org','Kelly','Delgado','955.948.5525','41993 Brandy Lakes Suite 159','Suite 787','Hutchinsonside','Mississippi','04333');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnsonthomas@murphy-webster.com','Derrick','Sullivan','591.143.5189x5039','0096 Dougherty Mission Suite 941','Suite 073','Smithberg','Washington','89150');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vhicks@stephens.com','Kayla','Kim','001-415-740-1850x951','539 Thornton Overpass','Suite 984','Clarkborough','Nebraska','51535');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gallagherstephen@jones-gonzalez.com','James','Colon','657.652.6191','3838 Lloyd Harbor Suite 184','Apt. 186','East Brittany','Minnesota','68089');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('elizabethcortez@hotmail.com','Ashley','Lynch','+1-351-782-9431x22966','197 Jack Station','Suite 974','Nicholasfurt','Arkansas','68097');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('weberfrederick@henderson-moreno.com','Carl','Jackson','(193)802-2327x90296','433 Savage Estates','Suite 563','South Brian','South Dakota','32573');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rbradford@ramirez.com','Karen','Baldwin','925-118-7523','22864 Cummings Park','Apt. 668','West Mitchellview','North Dakota','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stewartbrianna@cook.com','Natalie','Fox','+1-329-398-9784x5379','7118 Williams Groves','Suite 261','Port Courtney','Nebraska','60514');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sanchezerica@gmail.com','Marie','Haynes','4568073873','705 Julie Square Suite 031','Apt. 612','Lake Danielle','Idaho','56357');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rfernandez@yahoo.com','Stephanie','Tran','435-780-2065x91981','00105 Michelle Cliffs Apt. 269','Suite 114','East Christopher','Wyoming','68006');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('daychristopher@gmail.com','Randy','Fields','222-661-2601','6621 Farrell Parkways','Apt. 122','South Ravenmouth','Arkansas','96754');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('daviselizabeth@yahoo.com','Rachel','Lee','916.884.4242','8990 William Drive Suite 763','Suite 749','Donnamouth','Oregon','39770');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('longkimberly@morris.net','Julie','Thompson','+1-811-518-2345x6087','705 Adam Plaza Suite 073','Apt. 015','West Anthonybury','Idaho','85441');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ballen@hotmail.com','Raymond','Kennedy','526-301-2531x1567','70563 Victoria Radial Suite 591','Apt. 911','East Michaelland','Maine','82542');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lynchdiana@yahoo.com','Edward','Price','+1-856-471-9770x75251','975 Lee Trafficway','Suite 107','Lake Ashley','Nebraska','84228');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('dana62@chung.net','Christopher','Murillo','021-179-4829','8347 Eric Oval','Apt. 342','North Kimberlymouth','Texas','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pblack@gonzales.info','Kelsey','Rogers','001-744-543-2066x0471','3364 Fuller Brook Apt. 534','Apt. 768','Lake Vanessaberg','Montana','73091');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('katherine79@gmail.com','Richard','Hanna','671.660.4050x6418','1159 Phillips Gardens','Suite 002','North Caitlintown','Michigan','20331');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('victoria38@henson.com','Madison','Watkins','352-441-8259x1982','011 Gabrielle Estate Apt. 283','Apt. 778','South Jonathanborough','Minnesota','54018');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('egarcia@wade.com','Benjamin','Hall','546.352.0307x5887','4627 Fisher Islands Suite 112','Apt. 231','Jesseborough','Missouri','05114');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gonzalezcharles@porter-washington.net','Andrew','Dyer','042.100.7716x928','5349 Foley Hollow Suite 649','Apt. 100','Frankmouth','Rhode Island','95391');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wwilson@gmail.com','Christine','Garcia','5306727423','074 Jeremy Vista Suite 552','Apt. 599','Rodriguezfort','Maryland','99510');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('abarnes@estrada.org','Diane','Conley','+1-875-498-7120','53569 Hurley Lakes','Suite 696','Davisville','Minnesota','02875');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ymoore@gallagher-harris.com','Michael','Benson','796-574-7058x695','94844 Evans Brook','Suite 827','Barnesstad','Louisiana','59310');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jonathan17@murphy.com','Jose','West','386-658-2894','620 Mitchell Views Apt. 651','Apt. 132','Rodriguezstad','Tennessee','70891');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('anna35@davis.info','Teresa','Gibson','+1-665-372-8010','44542 Jessica Knolls','Suite 941','Clarktown','Nevada','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sarah52@hotmail.com','Nicole','Hopkins','751-480-5796','855 Christopher Vista','Apt. 191','Melissafurt','North Dakota','99687');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nancy92@hammond.org','Rhonda','Love','001-202-945-3333x5499','8883 Gregory Harbor','Suite 967','South Jennifer','Texas','27807');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mclaughlintina@greene.com','Erik','Webster','001-748-418-9381x759','712 Greene Avenue','Suite 941','Juliehaven','New Mexico','81428');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('awilson@yahoo.com','Erik','Miller','(297)616-2172x3373','1080 Adam Way Suite 901','Apt. 360','West Christian','Wyoming','60674');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('haynestimothy@russell.biz','Lisa','Buchanan','+1-974-214-3449x219','65545 Robert Club','Suite 060','Fernandezfort','Michigan','07834');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cynthiagreen@johnson.com','Stacy','Phillips','+1-339-422-9029x7020','13135 Katie Harbors','Suite 899','East Nicoleberg','Rhode Island','68077');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('scottcook@mcconnell.biz','Cory','Scott','(043)464-3604x713','2391 Harper Tunnel','Suite 096','North Jessicashire','Illinois','56205');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('robersonjoanne@gmail.com','Mia','Ford','001-936-334-4743x910','52464 John Stream Suite 748','Suite 602','South Rebeccatown','Tennessee','34805');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('teresa28@castillo.com','Michelle','Murray','251.154.3993x5321','8470 Jacob Creek Apt. 648','Apt. 859','Matthewfort','Tennessee','28678');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kendralevine@ortiz.net','Penny','Hammond','(635)561-6867x789','834 Lauren Neck','Suite 530','Mercedesstad','Kansas','64452');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hfoster@williams-robertson.org','Jeffrey','Lam','039-302-5917','686 Michael Rue Apt. 039','Apt. 341','South Lance','Washington','47007');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kennethrichards@yahoo.com','Edward','Cummings','+1-145-051-2428','7789 Ryan Station Suite 594','Suite 361','Briantown','Kansas','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jmyers@long.biz','Madison','Gray','733.792.2092','3284 Ryan Mews Suite 015','Apt. 431','Sarahshire','Oregon','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('steven37@black-buck.com','Donald','Young','+1-602-013-6939x54364','285 Ramsey Pike','Apt. 756','South Michael','Oklahoma','46351');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('randall54@stark.com','Rebecca','Barajas','2341311637','65792 Guzman Glen','Apt. 059','West Robert','Maine','37921');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('qpatel@taylor.com','Jesse','Gentry','001-510-578-7861x37481','797 Sabrina Turnpike','Suite 867','East Judy','South Carolina','87627');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jim46@sawyer-jacobs.biz','Virginia','Patterson','+1-105-225-5960x6253','105 Parks Ridges Apt. 794','Suite 909','South Danielmouth','Texas','56448');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mccoygabrielle@yahoo.com','Kimberly','Bennett','924.115.6172','247 John Stream Apt. 285','Suite 280','West Ericaport','Minnesota','25505');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('amanda63@carr-spencer.org','Anne','Hardy','(826)847-4994x678','052 Hart Greens Apt. 112','Suite 711','South Dariusmouth','South Dakota','45082');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nathan14@hotmail.com','Brian','Hudson','(960)619-7209x2265','0215 Jennifer Shore Suite 865','Apt. 683','Port Samantha','Maryland','80596');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rpotter@morgan.info','Grace','Williams','(496)508-3770x062','827 Hawkins Fords','Suite 124','Bethfurt','Mississippi','19762');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('andrea10@walsh.biz','Maria','Villarreal','001-314-297-8894x894','797 Thompson Glen','Apt. 415','Lake Kennethshire','New York','82914');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('eweaver@yahoo.com','Ann','Richardson','005-203-5577x0416','0324 Strickland Extension Suite 316','Suite 601','Port Ashley','Georgia','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('morganleah@yahoo.com','Daniel','Benson','001-615-997-7113','2451 Gomez Fields Suite 164','Suite 900','Garciafort','Ohio','29399');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('reedjustin@gmail.com','Ethan','Baker','001-213-132-6801','0025 David Radial','Suite 466','Garciaport','Colorado','85969');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('david13@santiago.com','Paul','Perry','365.379.7558x6304','6123 Hess Prairie','Apt. 181','Lake Alexanderborough','Indiana','40790');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('destinyshepard@collins-white.com','Mary','Robinson','001-015-647-5028x55461','307 Deborah Summit','Apt. 841','Hollandville','Arizona','19855');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wyattthomas@yu.com','Brian','Olson','001-034-409-2939x05809','463 Lauren Stravenue','Suite 206','New Christopher','Michigan','53976');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ashleyfox@yahoo.com','James','Rojas','001-504-640-5001x1774','813 Andrew Dale','Suite 730','Myersland','New York','89001');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kevinlee@nash.com','Clarence','Berry','001-702-411-1762x8877','939 Contreras Village Suite 405','Apt. 241','North Lauren','Vermont','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('steven72@hudson.biz','Johnathan','Mcfarland','580-293-5021x18480','903 Allen Parkway Suite 670','Apt. 532','New Ryan','California','05215');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jbaker@hotmail.com','Kelly','Spencer','+1-372-631-6745','356 Lowe Road Apt. 113','Apt. 558','Jacksonport','California','35985');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hvalencia@olsen.org','Carol','Martinez','405-122-8888x858','62858 Perez Islands','Suite 711','Jennamouth','New Mexico','58096');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('anna12@park.net','Cindy','Simpson','+1-343-408-4090x0652','872 Frye Trail Apt. 276','Suite 649','Reedfurt','Ohio','89042');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nrosales@yahoo.com','Theresa','Jones','+1-509-839-6309x194','81122 White Forest Apt. 269','Suite 148','Johnside','Hawaii','63797');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gomezelizabeth@anderson-barrera.com','Mary','Smith','+1-341-058-5279x59117','68102 Suzanne Branch Suite 231','Suite 260','Hooverbury','New Jersey','97610');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wmendez@strong-chandler.com','Mitchell','King','7172728553','9350 Hale Shoal Apt. 079','Suite 857','South Paigeberg','Maine','82094');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nbenson@molina-davidson.com','Eric','Mendoza','+1-635-668-3826x54161','47492 Guzman Crossroad Suite 981','Suite 484','West Robert','Iowa','98398');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('bryanduran@gmail.com','David','Vance','(322)156-0598x13298','8095 Lindsey Canyon','Apt. 724','Samanthafort','Nebraska','01506');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kristine96@hotmail.com','Clarence','Williams','+1-640-967-1267x8397','048 Jeremy Center Suite 576','Suite 837','North Kevin','Washington','20023');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('watsonbrianna@turner.net','Karen','Johnson','0246332574','0230 Conner Heights Apt. 290','Suite 030','West Michael','Utah','99095');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wlee@graham.com','John','Estes','+1-985-012-4217x582','6553 Craig Rapid','Apt. 207','South Kenneth','Rhode Island','47118');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cmullen@gmail.com','Erin','Pope','(401)268-4809x41001','615 Perez Groves','Suite 988','Lake Katherineborough','Connecticut','38552');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('nroberts@rubio-roth.com','Shannon','Reeves','(134)703-2329x817','0919 Rose Bridge Apt. 872','Apt. 027','West James','Pennsylvania','19728');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('gonzalezjustin@hotmail.com','Maria','Rice','001-253-457-4408x460','25337 Leach Drive','Suite 643','Nataliechester','New Mexico','54829');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('wtyler@taylor.com','Robert','Burgess','349.096.3770','956 Garrett Key','Suite 885','New Laurafurt','Washington','62704');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stephaniewalker@logan-fitzpatrick.com','Lisa','Rowland','505-273-7665x456','35805 Brown Alley Apt. 377','Suite 261','North Williamton','Michigan','52217');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jnguyen@miranda-ward.com','Jon','Wood','7251306345','58168 Steven Spring','Suite 696','Jenniferborough','Rhode Island','05343');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('laurenmckinney@hotmail.com','Melissa','Williams','8939956683','031 Maria Port Apt. 694','Suite 228','Port Danny','Utah','32777');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('duncancraig@sellers-davis.info','Crystal','Wallace','(252)216-4186x01671','005 Robert Crest','Apt. 837','Edwardbury','South Carolina','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ramirezbruce@hotmail.com','David','Cantrell','4579104564','92226 Tony Ridge','Apt. 036','East Pamelaport','Wisconsin','65074');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rcastro@brown-robinson.com','Joshua','Jones','001-392-547-6815x1507','81569 Burch Spurs','Apt. 042','Lake David','Maine','96044');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rebecca00@lopez.info','Ronald','Walker','(560)642-7506','932 Nelson Row Apt. 280','Apt. 000','Allenmouth','New Jersey','60794');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jaimewilson@gmail.com','Victor','Wells','+1-843-871-7479x4340','226 Michael Cove','Apt. 400','New Eric','Utah','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnrivas@yahoo.com','Tiffany','Nguyen','369.571.9831','15731 Victoria Island Apt. 331','Suite 512','North Timothyland','Wisconsin','81048');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rayholly@raymond-mcdaniel.info','Samantha','West','(617)661-0163','160 Tabitha View','Apt. 318','New Coryport','Minnesota','62316');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('christine72@hotmail.com','Joann','Mccullough','+1-563-795-0019x77213','392 Kendra Locks Suite 077','Suite 119','East Dawn','Wyoming','45718');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sharontaylor@hotmail.com','Charles','Walker','577-684-8920x592','4752 Parker Lights Suite 237','Suite 676','Penamouth','Arizona','82576');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('adecker@yahoo.com','Nicholas','Osborne','784-196-8842','9045 Michelle Centers Suite 528','Apt. 906','Leeburgh','New Hampshire','15381');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('stephenharris@west-smith.com','Krista','Duncan','377-349-4595','84240 Linda Fall','Suite 960','Mitchellburgh','Massachusetts','53669');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rogersmelinda@gmail.com','Amy','Delgado','+1-698-665-7629','748 Herring Rest Apt. 435','Suite 030','Pittmanmouth','Iowa','20041');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('pamela08@martinez.com','Luke','Finley','626-666-5340x63460','095 Flynn Harbor','Apt. 443','East Christina','New Jersey','07955');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lhill@navarro.com','Daniel','White','+1-088-398-6739','06951 Garrett Dale Apt. 504','Suite 810','East Laurenburgh','Connecticut','70938');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kjensen@ochoa-williamson.com','Taylor','Maxwell','+1-882-675-4714x45308','92631 Fleming Circle Suite 809','Apt. 274','Andersonshire','New Jersey','66706');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('thomas06@hotmail.com','Andrew','Cunningham','(886)196-5998','1498 Rhonda Island Suite 306','Apt. 951','Adkinsstad','Georgia','01805');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('elizabeth88@yahoo.com','Travis','Alexander','7947508137','978 Brown Avenue Apt. 774','Apt. 379','East Victoriafurt','Virginia','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('sean95@yahoo.com','Frank','Porter','831.315.0544','9842 Stacey Street','Suite 849','Christopherview','Ohio','20040');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('briana22@gmail.com','Russell','Sanford','+1-260-579-9829x979','10150 Haynes Loop','Apt. 098','South John','Connecticut','73099');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hjohnson@gmail.com','Erin','Thompson','888.685.1183x220','8542 Hall Spring','Apt. 729','Anthonymouth','New Mexico','97049');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rachelarcher@mitchell-bryant.info','Tiffany','Davidson','018.855.7530','442 Powers Groves Apt. 931','Apt. 070','Wolfeborough','Illinois','50723');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kscott@cobb.com','Yvette','Thomas','(504)650-8893x7088','2847 Charles Unions','Suite 503','Robertmouth','Oregon','81522');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rzimmerman@hotmail.com','Alexander','Holland','(919)541-3269x2713','640 Michelle Rapid Apt. 559','Apt. 540','Port Michael','North Carolina','81135');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jaredcarroll@gmail.com','William','Reynolds','+1-096-690-5469x7197','0237 Larson Station','Apt. 779','Jenniferfort','Indiana','83515');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hailey21@vega.com','Brandy','Peck','+1-277-397-0469x788','84573 Evans Garden','Apt. 534','Angelafort','Rhode Island','40795');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ronaldschneider@hotmail.com','Ryan','Robinson','(638)039-9934x63365','55839 Jesse Crossing','Apt. 637','Lopezfurt','Pennsylvania','19804');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('myersapril@young.com','Kimberly','Lawson','736-515-4947','69116 Allison Grove Apt. 012','Apt. 319','East Kyle','Delaware','06213');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jenniferjimenez@gill.org','Chad','Nguyen','+1-389-972-8826x78761','96022 Anderson Turnpike','Suite 332','Gibbsport','New Mexico','01817');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('simmonsnicole@gmail.com','Veronica','Shannon','+1-590-075-3241x961','9490 John Grove','Apt. 118','West Dustin','Arkansas','81444');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jacobdavis@yahoo.com','Angela','Baker','(107)390-7695x966','1866 Hernandez Circle','Suite 688','South Eddiestad','Wyoming','42787');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lisarogers@hotmail.com','Marie','Ferrell','(183)017-5340x37473','2982 Hayes Overpass Apt. 332','Apt. 629','Riveramouth','Georgia','04630');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('xbridges@gmail.com','Linda','Montgomery','716.598.0590x895','1383 Kimberly Ridges Suite 699','Suite 584','West Gene','New Mexico','38100');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('acarter@cox.com','Charles','Harvey','001-113-652-1247x1295','5052 Powell Port Apt. 143','Apt. 470','North Andrea','Kentucky','42545');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('amanda22@perez-ross.info','Mia','Black','001-636-999-3948x428','61570 Thomas Walks Apt. 381','Apt. 925','Larryton','Georgia','32511');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('melissa51@gmail.com','Christopher','Payne','+1-200-941-0625','8612 Jones Vista','Apt. 408','North Tara','Massachusetts','08600');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('mckenziejesse@gmail.com','Brandon','Burton','301-488-5662x35208','30071 White Lakes','Apt. 498','Samanthaberg','New Jersey','99684');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('meyermichael@yahoo.com','Holly','Wright','1780602672','352 Gaines Oval','Suite 019','North Jonathon','South Dakota','06390');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('howardamy@jones.com','Michelle','Watkins','7940963781','0910 Miller Lodge','Suite 854','North Deborahburgh','Texas','57144');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('qmiller@powell.com','Maria','Phillips','6488243395','88496 Lopez Streets Suite 555','Suite 713','Brandyfurt','Hawaii','42423');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hendersontara@barker.info','Elizabeth','Chan','552-060-6765x17346','53247 Owen View','Suite 375','Torresberg','Michigan','20028');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('abigail50@gardner-novak.com','Daniel','Mendez','001-444-953-6569x12678','395 Wright Squares','Suite 730','Port Anthonytown','North Carolina','64304');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michelle70@richardson.net','Colleen','Smith','404-345-2789x331','75617 Yang Plain','Suite 991','South Thomasborough','Maine','90250');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jessica25@bautista-mccoy.com','Mary','Choi','001-589-891-5963x455','3830 Melissa Village Apt. 117','Apt. 813','East Michealmouth','Georgia','71178');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('freyjohn@bates.com','Eric','White','001-176-496-4211x775','34370 Davis Crossroad','Apt. 636','Stevenmouth','Idaho','02833');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('youngcharles@hotmail.com','James','Rodriguez','001-161-831-8939x391','68081 Antonio Villages Apt. 263','Suite 683','Richardsonhaven','Minnesota','19786');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('brandi15@yahoo.com','Christopher','Peck','+1-894-896-5340x4089','9874 Lisa Harbors Suite 041','Apt. 462','West Danielbury','Maine','38683');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('evansjeffrey@gmail.com','John','Jackson','0269185508','7743 Barr Hollow Suite 578','Apt. 266','Cristinabury','Colorado','17106');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('rebecca09@fischer.com','Stephanie','Chaney','(621)218-5388','75198 Yates Extensions','Suite 233','Beasleyborough','North Carolina','58468');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('tinalong@nichols.net','Karen','Murphy','813-652-2500','84936 Wu Knoll','Apt. 942','Lake Tylerfurt','Oregon','06256');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('troy10@hotmail.com','Danielle','Gonzalez','001-718-809-1696x21973','2565 Keith Cove','Suite 295','Davisbury','South Carolina','73056');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('fturner@davis-hahn.com','Brittany','Fritz','001-764-371-2137x893','918 Fowler Lake','Suite 926','West Victorview','Kentucky','80178');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lucas35@hotmail.com','Stephanie','Ayers','(433)063-1328','607 Joseph Plain','Apt. 704','Lake Robertborough','Wyoming','63414');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('hbishop@gmail.com','Kimberly','Walker','001-310-684-9478x0340','0442 Rodriguez Neck','Suite 185','South Robert','Ohio','80981');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('reesejoseph@welch-myers.com','Amber','Alvarado','585.657.9965x912','550 Jacobs Views','Suite 411','Jeffreymouth','Arkansas','48277');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('daniel95@pineda.com','Robert','Chan','399-683-6011','9983 Jennifer Falls','Suite 942','Andrewton','Louisiana','47960');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('leah11@hotmail.com','Guy','Hart','820-917-8516','9475 Kevin Stream','Suite 552','Brianbury','Delaware','72276');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('leemegan@wilson.com','Jose','Rodriguez','536-229-1284x080','172 Carmen Port','Apt. 762','Port Stacyside','Minnesota','99661');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vhorton@meadows-bond.com','Jennifer','Huff','(282)171-1068x873','9899 Conner Cape Suite 789','Apt. 229','Paulbury','Idaho','83812');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('claire74@howard.net','Linda','Pacheco','+1-943-494-6997x7174','7575 Gina Route','Apt. 087','Lake William','New Mexico','02934');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('johnny81@castillo.org','Timothy','Scott','990.078.5735x05220','908 Stacey Viaduct','Apt. 680','Clementsland','Connecticut','64897');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('adamsvictoria@gmail.com','Theresa','Chandler','001-306-620-1607','2328 Nunez Way','Suite 553','South Thomasstad','Wisconsin','39497');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ooconnor@hotmail.com','Kyle','Rogers','+1-160-300-5888','509 Frye Fields Apt. 786','Suite 028','Lake Jasonland','Wyoming','80595');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('kennethperry@patterson-jones.com','Lori','Reilly','+1-190-957-4867x262','1898 Gordon Tunnel Suite 727','Suite 382','Fitzgeraldport','Vermont','65611');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('vargasann@gill-reyes.com','Joshua','Fernandez','392.669.1242','683 Armstrong View Suite 990','Suite 143','Jordanview','Pennsylvania','66190');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('randerson@yahoo.com','Ruben','Wilson','001-491-001-3673x31714','95218 Medina Lodge Apt. 779','Suite 444','West Meredith','North Carolina','28019');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('emma35@hotmail.com','Michael','Hart','504.327.8845','2347 Zuniga Plain Suite 997','Suite 847','North Karen','Florida','99790');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('alecdunn@yahoo.com','Sean','Friedman','0530731470','7982 Hodges Crescent Suite 471','Apt. 567','Arroyoton','Florida','20031');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michael47@gmail.com','Jimmy','Hernandez','350-611-0805x70485','74393 Brooke Haven Suite 112','Apt. 351','New Gregorystad','Virginia','39594');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jenniferjones@villarreal.com','Joel','Reyes','929-314-3155','621 Hughes Path','Apt. 455','South Johnathanview','Alaska','59280');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('michael70@harris-young.com','Todd','King','(768)713-2984x54232','54892 Andrew Viaduct','Apt. 376','Sheltonburgh','Florida','70229');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ljohnson@hotmail.com','Sara','Scott','(963)283-5642','0912 Todd Trace Apt. 890','Apt. 228','East Mark','Vermont','39206');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('william06@acevedo.com','Stephen','Ward','(446)255-0289','3239 Christopher Village','Suite 857','South Eric','Colorado','01914');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('lvargas@hotmail.com','Gina','Johnson','650-556-8190','09770 Wade Place Suite 025','Suite 056','North Antonioport','Maryland','08970');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('awhite@yahoo.com','Erika','Navarro','909-225-3158','5968 Perez Forks Suite 711','Apt. 152','North Michele','Nebraska','39420');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('ccole@gmail.com','Elizabeth','Wilson','001-283-422-3111x60721','068 Kathy Trafficway Suite 892','Apt. 245','Heathermouth','Michigan','73301');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('cheyenne53@williams-day.org','Ashley','Murphy','+1-812-226-5875x38104','43948 Soto Burg Suite 627','Apt. 197','West Oscarfort','Alabama','81283');

INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('jennifer72@hotmail.com','Catherine','Hill','001-465-245-5992x4295','3528 Kevin Points','Apt. 914','Monicaburgh','South Carolina','85649');

