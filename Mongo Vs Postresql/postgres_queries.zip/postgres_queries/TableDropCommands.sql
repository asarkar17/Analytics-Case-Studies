drop function TakeOrders;
drop table CustomerAwardsProgram;
drop table Orders;
drop table RecipeNeeds;
drop table Recipe;
drop table Inventory;
drop table Customer;
drop table Users;