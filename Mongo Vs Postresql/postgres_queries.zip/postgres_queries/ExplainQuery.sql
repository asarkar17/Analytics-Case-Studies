EXPLAIN ANALYZE
SELECT RecipeName,TotalOrders FROM (
SELECT Name as RecipeName,COUNT(OrderKey) as TotalOrders,  
       ROW_NUMBER () OVER ( ORDER BY  COUNT(OrderKey) DESC ) as RNUM
FROM Orders O 
INNER JOIN Recipe R ON R.RecipeKey = O.RecipeKey
GROUP BY RecipeName
) AS TopOrders
WHERE RNUM <=10;