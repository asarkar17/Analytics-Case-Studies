
# coding: utf-8

# ## Initiating required libraries

# In[60]:


import pandas as pd
import os, codecs
from faker import Faker
fake = Faker()

#Chaning Working Directory
os.chdir("C:/Users/ayans/OneDrive/Desktop/nosql-db-ayansarkar/projects/project01/postgres")


# ## Generating data for table: Users

# In[61]:


for x in range(1000):
    print("INSERT INTO Users (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('"+fake.email()+"','"+fake.first_name()+"','"+fake.last_name()+"','"+fake.phone_number()+"','"+fake.street_address()+"','"+fake.secondary_address()+"','"+fake.city()+"','"+fake.state()+"','"+fake.zipcode_in_state(state_abbr=None)+"');\r\n",file=open('LoadUsers.sql', 'a+',encoding = 'latin1', errors='ignore'))


# ## Generating data for table: Customer

# In[62]:


for x in range(1000):
    print("INSERT INTO Customer (EmailAddress,FirstName,LastName,PhoneNumber,AddressLine1,AddressLine2,City,State,Zip) VALUES ('"+fake.email()+"','"+fake.first_name()+"','"+fake.last_name()+"','"+fake.phone_number()+"','"+fake.street_address()+"','"+fake.secondary_address()+"','"+fake.city()+"','"+fake.state()+"','"+fake.zipcode_in_state(state_abbr=None)+"');\r\n",file=open('LoadCustomer.sql', 'a+',encoding = 'latin1', errors='ignore'))


# ## Generating data for table: Inventory

# In[63]:



Ingredient_List = ['Dry Yeast','Bread Flour','Olive Oil','Salt','Sugar','Corn meal','Tomato sauce','Firm mozzarella cheese','Soft mozzarella cheese','Fontina cheese','Parmesan cheese','Feta cheese','Mushrooms','Bell peppers','Italian pepperoncini','Italian sausage','Basil','Baby arugula','Pesto','Pepperoni','Onions','Ham']
Ingredient_Description = ['1 package (2 1/4 teaspoons) of active dry yeast','3 3/4 cups (490 g) bread flour','2 Tbsp olive oil (omit if cooking pizza in a wood-fired pizza oven)','2 teaspoons salt','1 teaspoon sugar','Olive oil','Tomato sauce (smooth, or pured)','Firm mozzarella cheese, grated','Fresh soft mozzarella cheese, separated into small clumps','Fontina cheese, grated','Parmesan cheese, grated','Feta cheese, crumbled','Mushrooms, very thinly sliced if raw, otherwise first sauted','Bell peppers, stems and seeds removed, very thinly sliced','Italian pepperoncini, thinly sliced','Italian sausage, cooked ahead and crumbled','Chopped fresh basil','Baby arugula, tossed in a little olive oil, added as pizza comes out of the oven','Pesto','Pepperoni, thinly sliced','Onions, thinly sliced raw or caramelized','Ham, thinly sliced']
for x in range(22):
    print("INSERT INTO Inventory (Name,Description,Quantity,WeightInGrams) VALUES ('"+Ingredient_List[x]+"','"+Ingredient_Description[x]+"',"+str(75000)+","+str(500)+");",file=open('LoadInventory.sql', 'a+',encoding = 'latin1', errors='ignore'))


# ## Generating data for table: Recipe

# In[68]:


Recipe_List = ['Berry, Arugula and Prosciutto Pizza','Macaroni And Cheese Pizza','Butternut Squash and Crispy Sage Pizza','Buffalo Chicken Pizza Sticks','Cantaloupe And Sweet Ricotta Pizza','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Hummus And Grilled Zucchini Pizzas','Chicken Alfredo Pizza','Taco Quesadila Pizza','Wredes Grilled Pizza with Grapes and Soppressata','Cookie Dough Dessert Pizza','Turkish Ground-Lamb Pizzas','Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','Squid Pizza With Saffron Aioli','Savoy Cabbage And Sunchoke Pizza','Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','Loaded Baked Potato Pizza','Caramel Apple Pizza','Verde Chicken Enchilada Pizza','Spaghetti & Meatball Pizza','Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Charred Corn and Avocado Pizza','Beet Pesto Pizza with Kale and Goat Cheese','Zucchini, Anchovy, and Burrata Pizza','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Pizza Bianca with Scamorza and Shaved Celery Root','Sweet Peach and Corn Pizza','Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Brussels Sprout Pizza','Pistachio and Mortadella Pizza','Scrambled Egg Breakfast Pizza']
Recipe_Description = [
    'This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!',
    'Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!',
    'Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style',
    'Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.',
    'Cantaloupe And Sweet Ricotta Pizza',
    'Brown Butter Lobster and Spinach Pizza with Bacon + Fontina',
    'Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.',
    'There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.',
    'Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!',
    'In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.',
    'This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!',
    'At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.',
    'BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS',
    'Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.',
    'This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.',
    'A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ',
    'Loaded baked potato pizza combines the worlds best flavors – potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ',
    'Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats',
    'Verde Chicken Enchilada Pizza',
    'Spaghetti & Meatball Pizza',
    'Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.',
    'This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.',
    'Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!',
    'Zucchini, Anchovy, and Burrata Pizza',
    'Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans',
    'With slices of celery root and chefs’ new favorite cheese, scamorza, pizza night just got a lot more fun.',
    'Sweet Peach and Corn Pizza',
    'Asian-style toppings—shredded snow crab, spicy shishito peppers, ginger-wasabi aoli—adorn a Western-style pizza at Park Hyatt Tokyos New York Bar.',
    'Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.',
    'A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ',
    'Back-to-School Breakfast Pizza'
]

for x in range(31):
    print("INSERT INTO Recipe (Name,Description) VALUES ('"+Recipe_List[x]+"','"+Recipe_Description[x]+"');\r\n",file=open('LoadRecipe.sql', 'a+',encoding = 'latin1', errors='ignore'))
  


# ## Generating data for table: RecipeNeeds

# In[65]:


for x in range(31):
    for y in range(22):
        print("INSERT INTO RecipeNeeds (RecipeKey,InventoryKey) VALUES ("+str(x+1)+","+str(y+1)+");\r\n",file=open('LoadRecipeNeeds.sql', 'a+',encoding = 'latin1', errors='ignore'))


# ## Generating data for table: Orders

# In[66]:


for x in range(50):
    for y in range(50):
        for z in range(31):
            print("INSERT INTO Orders (UserKey,CustKey,RecipeKey,ExpectedCompletionTime,TotalCost) VALUES ("+str(x+1)+","+str(y+1)+","+str(z+1)+","+str(30)+","+str(10)+");\r\n",file=open('LoadOrders.sql', 'a+',encoding = 'latin1', errors='ignore'))


# ## Generating data for table: CustomerAwardsProgram

# In[67]:


for x in range(100):
    print("INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES ("+str(x+1)+","+str(10)+");\r\n",file=open('LoadCustomerAwardsProgram.sql', 'a+',encoding = 'latin1', errors='ignore'))

