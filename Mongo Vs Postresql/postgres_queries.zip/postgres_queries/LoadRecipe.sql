INSERT INTO Recipe (Name,Description) VALUES ('Berry, Arugula and Prosciutto Pizza','This light and easy-to-make pizza is topped with salty prosciutto, juicy strawberries, and raspberries, creamy ricotta, and fresh arugula, and is perfect for warm spring or summer brunches or dinners!');

INSERT INTO Recipe (Name,Description) VALUES ('Macaroni And Cheese Pizza','Take pizza night to the next level with Macaroni and Cheese Pizza. This mac n cheese pizza recipe is easy to make for a fun family dinner!');

INSERT INTO Recipe (Name,Description) VALUES ('Butternut Squash and Crispy Sage Pizza','Butternut Squash and Crispy Sage Pizza, Five-Minutes-a-Day Style');

INSERT INTO Recipe (Name,Description) VALUES ('Buffalo Chicken Pizza Sticks','Thanks to store-bought (or homemade) pizza dough, you can make this easy buffalo chicken pizza with shredded chicken tossed in buffalo wing sauce and cheddar cheese.');

INSERT INTO Recipe (Name,Description) VALUES ('Cantaloupe And Sweet Ricotta Pizza','Cantaloupe And Sweet Ricotta Pizza');

INSERT INTO Recipe (Name,Description) VALUES ('Brown Butter Lobster and Spinach Pizza with Bacon + Fontina','Brown Butter Lobster and Spinach Pizza with Bacon + Fontina');

INSERT INTO Recipe (Name,Description) VALUES ('Hummus And Grilled Zucchini Pizzas','Prepared hummus that comes with a scoop of chopped garlic on top (like the kind sold by Sabra) is the secret here: The garlic gets mixed with oil to marinate the zucchini, while the remaining garlic and hummus flavor the whole pizza.');

INSERT INTO Recipe (Name,Description) VALUES ('Chicken Alfredo Pizza','There are a few options when making this pizza. You obviously can make your own crust, purchase one from the grocery store, or most of the time what I do is buy a large one or a few small ones from the local pizzeria. If you are making your own crust and dont have a good recipe, I really like the Cooks Illustrated recipe for pizza dough. Like I said though, most of the time its just easier for me to get a pre-made dough from the local Pizzeria, its always delicious with a perfect fluffy and chewy texture.');

INSERT INTO Recipe (Name,Description) VALUES ('Taco Quesadila Pizza','Taco meat and cheese stuffed quesadillas made pizza style topped with salsa and even more melted cheese!');

INSERT INTO Recipe (Name,Description) VALUES ('Wredes Grilled Pizza with Grapes and Soppressata','In a medium bowl, combine the water with the yeast and 1 teaspoon of the flour and let stand until dissolved. Add the sugar and a pinch of salt and stir in enough of the flour to form a stiff dough. Scrape the dough onto a lightly floured work surface and knead until smooth. Put the dough in a lightly oiled bowl, cover and let rise in a warm, draft-free place until doubled in bulk, 1 to 1 1/2 hours.');

INSERT INTO Recipe (Name,Description) VALUES ('Cookie Dough Dessert Pizza','This is a great dessert idea that is quick and easy to make and is a perfect dessert for any party you are throwing! Its a Cookie Dough Pizza topped with hot fudge, caramel and cream cheese frosting. Its melty, gooey and wonderful!');

INSERT INTO Recipe (Name,Description) VALUES ('Turkish Ground-Lamb Pizzas','At her takeout shop in Istanbul, Kantin Dkkan, Semsa Denizsel tops her pizzas with ground lamb (flavored with sweet sun-dried tomatoes and a little spicy red pepper), but you can substitute ground beef instead. To make the pizza even more substantial, bake it with an egg on top; the runny yolk is terrific with the whole-wheat crust.');

INSERT INTO Recipe (Name,Description) VALUES ('Blueberry Pizza with Whipped Ricotta + Caramelized Shallots','BLUEBERRY PIZZA WITH WHIPPED RICOTTA + CARAMELIZED SHALLOTS');

INSERT INTO Recipe (Name,Description) VALUES ('Squid Pizza With Saffron Aioli','Michael Emanuel (an alumnus of Berkeleys Chez Panisse) tops this pizza with an irresistible mix of Provenal flavors: salty-sweet roasted squid, creamy aioli and crushed red pepper (French piment dEspelette would also work well). The remaining aioli can be used as a dip for vegetables or a spread for sandwiches.');

INSERT INTO Recipe (Name,Description) VALUES ('Savoy Cabbage And Sunchoke Pizza','This incredible pizza is topped with buttery braised cabbage, pureed sunchokes, crisp pan-fried sunchokes and gooey Emmental cheese.');

INSERT INTO Recipe (Name,Description) VALUES ('Spring Pizza With Peas, Fava Beans, Asparagus, Prosciutto, And Eggs','A layer of Robiola bechamel tops the pizza dough (which was leftover from a spinach lasagna that I havent posted yet) and on top goes asparagus tips, fresh peas, fava beans and a pesto puree. I had three quail eggs who faced an uncertain future in my refrigerator so I found them a new purpose as pizza topping. They seem to be okay with it. I finished the spring pizza with a few thin slices of Coppa, an Italian cured meat from the top of the pork shoulder with bold taste and perfect fat-to-meat ratio. ');

INSERT INTO Recipe (Name,Description) VALUES ('Loaded Baked Potato Pizza','Loaded baked potato pizza combines the worlds best flavors  potato, cheese and bacon! Plus you ll love this crispy deep dish pizza because its made in a cast iron skillet! ');

INSERT INTO Recipe (Name,Description) VALUES ('Caramel Apple Pizza','Fall is here in earnest, and once again, a blessed wind has blown the countless leaves off our maple trees down the street into our neighbors yards.  And with the onset of autumn comes all sorts of seasonal treats');

INSERT INTO Recipe (Name,Description) VALUES ('Verde Chicken Enchilada Pizza','Verde Chicken Enchilada Pizza');

INSERT INTO Recipe (Name,Description) VALUES ('Spaghetti & Meatball Pizza','Spaghetti & Meatball Pizza');

INSERT INTO Recipe (Name,Description) VALUES ('Japanese Pizza with Sushi Rice, Tofu, Edamame, Shiitakes, and Manchego','Think fried rice meets pizza," says Chicago chef Grant Achatz, who makes this crazy-fun dish for dinner with his kids. You can pick your toppings, he says, but the most important one is the Manchego cheese, which has a flavor profile thats similar to miso.');

INSERT INTO Recipe (Name,Description) VALUES ('Charred Corn and Avocado Pizza','This pizza was inspired by my favorite Charred Corn & Avocado Quinoa Salad.');

INSERT INTO Recipe (Name,Description) VALUES ('Beet Pesto Pizza with Kale and Goat Cheese','Beet Pesto Pizza with Kale and Goat Cheese is a nutrient-dense healthier pizza recipe, packed with vitamins and flavor!');

INSERT INTO Recipe (Name,Description) VALUES ('Zucchini, Anchovy, and Burrata Pizza','Zucchini, Anchovy, and Burrata Pizza');

INSERT INTO Recipe (Name,Description) VALUES ('Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans','Raspberry Brie Dessert Pizza with Rosemary and Candied Pecans');

INSERT INTO Recipe (Name,Description) VALUES ('Pizza Bianca with Scamorza and Shaved Celery Root','With slices of celery root and chefs new favorite cheese, scamorza, pizza night just got a lot more fun.');

INSERT INTO Recipe (Name,Description) VALUES ('Sweet Peach and Corn Pizza','Sweet Peach and Corn Pizza');

INSERT INTO Recipe (Name,Description) VALUES ('Pizza with Snow Crab, Ricotta, Shishito Peppers, and Wasabi Aoli','Asian-style toppingsshredded snow crab, spicy shishito peppers, ginger-wasabi aoliadorn a Western-style pizza at Park Hyatt Tokyos New York Bar.');

INSERT INTO Recipe (Name,Description) VALUES ('Brussels Sprout Pizza','Serve this flatbread-style pizza as an appetizer for six, or with a few fried eggs as a main course for four.');

INSERT INTO Recipe (Name,Description) VALUES ('Pistachio and Mortadella Pizza','A buttery pistachio puree bolsters this mortadella and mozzarella pizza. ');

INSERT INTO Recipe (Name,Description) VALUES ('Scrambled Egg Breakfast Pizza','Back-to-School Breakfast Pizza');

