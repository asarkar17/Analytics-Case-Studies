SELECT 'Users' as Table,COUNT(*) as Total_Count FROM Users UNION
SELECT 'Customer' as Table,COUNT(*) as Total_Count FROM Customer UNION
SELECT 'Inventory' as Table,COUNT(*) as Total_Count FROM Inventory UNION
SELECT 'Recipe' as Table,COUNT(*) as Total_Count FROM Recipe UNION
SELECT 'RecipeNeeds' as Table,COUNT(*) as Total_Count FROM RecipeNeeds UNION
SELECT 'Orders' as Table,COUNT(*) as Total_Count FROM Orders UNION
SELECT 'CustomerAwardsProgram' as Table,COUNT(*) as Total_Count FROM CustomerAwardsProgram;