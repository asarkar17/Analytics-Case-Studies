

CREATE TABLE Users ( 
UserKey SERIAL PRIMARY KEY,
EmailAddress VARCHAR(150) NOT NULL,
FirstName VARCHAR(100)NOT NULL,
LastName VARCHAR(100) NOT NULL,
PhoneNumber VARCHAR(50) NOT NULL,
AddressLine1 VARCHAR(250) NOT NULL,
AddressLine2 VARCHAR(250),
City VARCHAR(50) NOT NULL,
State VARCHAR(50) NOT NULL,
Zip VARCHAR(9) NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp);

CREATE TABLE Customer
(
CustKey SERIAL PRIMARY KEY,
EmailAddress VARCHAR(150) NOT NULL,
FirstName VARCHAR(100)NOT NULL,
LastName VARCHAR(100) NOT NULL,
PhoneNumber VARCHAR(50) NOT NULL,
AddressLine1 VARCHAR(255) NOT NULL,
AddressLine2 VARCHAR(255),
City VARCHAR(50) NOT NULL,
State VARCHAR(50) NOT NULL,
Zip VARCHAR(9) NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE Inventory
(
InventoryKey SERIAL PRIMARY KEY,
Name VARCHAR(150) NOT NULL,
Description VARCHAR(255),
Quantity INTEGER NOT NULL,
WeightInGrams INTEGER,
CreatedAt TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE Recipe
(
RecipeKey SERIAL PRIMARY KEY,
Name VARCHAR(150) NOT NULL,
Description VARCHAR(1000),
CookingInstructions VARCHAR(1000),
CreatedAt TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE RecipeNeeds
(
RecipeKey INTEGER NOT NULL,
InventoryKey INTEGER NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp,
PRIMARY KEY (RecipeKey,InventoryKey),
FOREIGN KEY (RecipeKey) REFERENCES Recipe(RecipeKey) MATCH FULL,
FOREIGN KEY (InventoryKey) REFERENCES Inventory(InventoryKey) MATCH FULL
);

CREATE TABLE Orders
(
OrderKey SERIAL PRIMARY KEY,
UserKey INTEGER NOT NULL,
CustKey INTEGER NOT NULL,
RecipeKey INTEGER NOT NULL,
ExpectedCompletionTime INTEGER NOT NULL,
TotalCost DECIMAL(10,2) NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp,
FOREIGN KEY (UserKey) REFERENCES Users(UserKey) MATCH FULL,
FOREIGN KEY (CustKey) REFERENCES Customer(CustKey) MATCH FULL,
FOREIGN KEY (RecipeKey) REFERENCES Recipe(RecipeKey) MATCH FULL
);

CREATE TABLE CustomerAwardsProgram
(
CAKey SERIAL PRIMARY KEY,
CustKey INTEGER NOT NULL,
AwardPoints INTEGER NOT NULL,
CreatedAt TIMESTAMP DEFAULT current_timestamp,
FOREIGN KEY (CustKey) REFERENCES Customer(CustKey) MATCH FULL
);

CREATE FUNCTION TakeOrders( IN CKey INTEGER,IN UKey INTEGER, IN RKey INTEGER)
RETURNS VARCHAR(100) AS $OrderStatus$
DECLARE 
	OrderStatus VARCHAR(100);
	Count1 INTEGER;
	Count2 INTEGER;
BEGIN
   SELECT COUNT(*) into Count1
   FROM Inventory 
   WHERE InventoryKey IN 
	(
		SELECT DISTINCT InventoryKey FROM RecipeNeeds R 
		WHERE RecipeKey = RKey
	)
   AND Quantity >= 1;
   SELECT COUNT(DISTINCT InventoryKey) into Count2
   FROM RecipeNeeds R
   WHERE RecipeKey = RKey;
   IF Count1 = Count2
   THEN 
	INSERT INTO Orders (UserKey,CustKey,RecipeKey,ExpectedCompletionTime,TotalCost) 
	VALUES (UKey,CKey,RKey,30,10);
	UPDATE Inventory SET Quantity = Quantity-1 
	WHERE InventoryKey IN 
	(
	 SELECT DISTINCT InventoryKey FROM RecipeNeeds 
	 WHERE RecipeKey = RKey
	);
	INSERT INTO CustomerAwardsProgram (CustKey,AwardPoints) VALUES (CKey,10);
	OrderStatus = 'A new order has been created!';
   ELSE
	RAISE EXCEPTION 'There are not sufficients ingredients to compelte this order!';
   END IF;
 RETURN OrderStatus;
END;
$OrderStatus$ LANGUAGE plpgsql;